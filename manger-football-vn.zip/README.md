# Manger Football VN

Web game quản lý bóng đá chiến thuật (Football Manager) chạy trực tiếp trên trình duyệt, hỗ trợ 6 giải VĐQG cùng hệ thống giải hạng dưới 3 cấp để tự tạo CLB và leo hạng từ đáy lên đỉnh cao.

## Tính năng nổi bật

- **6 Giải VĐQG & Hệ thống hạng dưới 3 cấp**: Premier League, La Liga, Serie A, Bundesliga, Ligue 1, LPBank V.League 1 cùng đầy đủ các giải Hạng 2 & Hạng 3.
- **Chế độ Tạo CLB Riêng**: Tùy chỉnh tên, viết tắt, màu áo, huy hiệu, sân vận động và thi đấu từ hạng thấp nhất, cạnh tranh Top 2 thăng hạng qua từng mùa.
- **Chiến thuật & Chuyển nhượng chuẩn FM**: 7 sơ đồ chiến thuật, vai trò cầu thủ, đàm phán phí chuyển nhượng & hợp đồng 2 bước, kiểm soát quỹ lương và niềm tin ban lãnh đạo.
- **Match Engine 2D Trực Tiếp**: Mô phỏng 22 cầu thủ trên sân 2D theo thời gian thực, thay người chiến thuật và chỉ đạo giữa hiệp.
- **Hỗ trợ nhúng Google Sites**: Mở `?embed=1` để nhúng gọn vào Google Sites.

## Chạy ở máy cá nhân (Local)

```bash
npm install
npm run dev
```

Kiểm tra mã nguồn và chạy unit test:

```bash
npm run lint
npm test
npm run build
```

## Đưa lên GitHub Pages (Miễn phí)

Kho lưu trữ đã cấu hình sẵn workflow tại `.github/workflows/deploy-pages.yml`:

1. Đẩy mã nguồn lên GitHub (nhánh `main`).
2. Vào **Settings → Pages → Build and deployment → Source**, chọn **GitHub Actions**.
3. GitHub sẽ tự động chạy test, build và xuất bản trang web tại `https://<tên-tài-khoản>.github.io/<tên-repo>/`.
