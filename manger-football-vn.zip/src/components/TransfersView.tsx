import React, { useMemo, useState } from 'react';
import { Search, Star, X } from 'lucide-react';
import { getLeagueDef, getLeagueOrder } from '../engine/schedule';
import { evaluateContractOffer, evaluateTransferBid } from '../engine/transfers';
import { CareerState, LeagueId, Player, Position, SquadRole } from '../types/fm';

interface TransfersViewProps {
  career: CareerState;
  onToggleShortlist: (playerId: string) => void;
  onCompleteTransfer: (
    playerId: string,
    fee: number,
    newWage: number,
    contractYears: number,
    newRole: SquadRole
  ) => void;
}

export const TransfersView: React.FC<TransfersViewProps> = ({
  career,
  onToggleShortlist,
  onCompleteTransfer,
}) => {
  const [search, setSearch] = useState('');
  const [leagueFilter, setLeagueFilter] = useState<'ALL' | LeagueId>('ALL');
  const [posFilter, setPosFilter] = useState<'ALL' | Position>('ALL');
  const [maxPrice, setMaxPrice] = useState<number>(200);
  const [onlyShortlist, setOnlyShortlist] = useState(false);

  // Negotiation Modal State
  const [targetPlayer, setTargetPlayer] = useState<Player | null>(null);
  const [step, setStep] = useState<'bid' | 'contract'>('bid');
  const [bidFee, setBidFee] = useState<number>(20);
  const [bidMessage, setBidMessage] = useState<string | null>(null);
  const [wageOffer, setWageOffer] = useState<number>(80);
  const [contractYears, setContractYears] = useState<number>(4);
  const [roleOffer, setRoleOffer] = useState<SquadRole>('Đá chính');
  const [contractMessage, setContractMessage] = useState<string | null>(null);

  const userClub = career.clubs[career.userClubId];

  const marketPlayers = useMemo(() => {
    const q = search.trim().toLowerCase();
    return Object.values(career.players)
      .filter((p) => {
        if (p.clubId === career.userClubId) return false;
        if (onlyShortlist && !career.shortlistIds.includes(p.id)) return false;
        if (leagueFilter !== 'ALL' && career.clubs[p.clubId]?.leagueId !== leagueFilter) return false;
        if (posFilter !== 'ALL' && p.primaryPosition !== posFilter) return false;
        if (p.marketValue > maxPrice) return false;
        if (q && !p.name.toLowerCase().includes(q) && !career.clubs[p.clubId]?.name.toLowerCase().includes(q)) {
          return false;
        }
        return true;
      })
      .sort((a, b) => b.ovr - a.ovr)
      .slice(0, 60);
  }, [career.players, career.userClubId, career.shortlistIds, career.clubs, onlyShortlist, leagueFilter, posFilter, maxPrice, search]);

  const openNegotiation = (p: Player) => {
    setTargetPlayer(p);
    setStep('bid');
    setBidFee(Math.round(p.marketValue * 10) / 10);
    setBidMessage(null);
    setWageOffer(Math.round(p.weeklyWage * 1.15));
    setContractYears(4);
    setRoleOffer(p.ovr >= 84 ? 'Ngôi sao' : 'Đá chính');
    setContractMessage(null);
  };

  const handleSubmitBid = () => {
    if (!targetPlayer) return;
    if (bidFee > userClub.finances.transferBudget) {
      setBidMessage(`Không đủ ngân sách chuyển nhượng (Hiện có €${userClub.finances.transferBudget.toFixed(1)}M).`);
      return;
    }
    const sellingClub = career.clubs[targetPlayer.clubId];
    const evalRes = evaluateTransferBid(targetPlayer, sellingClub, bidFee);
    setBidMessage(evalRes.reason);
    if (evalRes.decision === 'accepted') {
      setStep('contract');
    } else if (evalRes.decision === 'countered' && evalRes.counterFee) {
      setBidFee(evalRes.counterFee);
    }
  };

  const handleSubmitContract = () => {
    if (!targetPlayer) return;
    const evalRes = evaluateContractOffer(targetPlayer, userClub, wageOffer, contractYears, roleOffer);
    setContractMessage(evalRes.reason);
    if (evalRes.accepted) {
      onCompleteTransfer(targetPlayer.id, bidFee, wageOffer, contractYears, roleOffer);
      setTargetPlayer(null);
    }
  };

  return (
    <div className="mx-auto max-w-[1320px] space-y-5">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="font-display text-3xl font-bold text-white">Thị Trường Chuyển Nhượng</h1>
          <p className="text-xs text-slate-400">
            Tìm kiếm cầu thủ từ 60 CLB trên 6 giải VĐQG · Ngân sách khả dụng:{' '}
            <strong className="font-mono text-emerald-400">€{userClub.finances.transferBudget.toFixed(1)}M</strong>
          </p>
        </div>
        <button
          type="button"
          onClick={() => setOnlyShortlist((s) => !s)}
          className={`flex items-center gap-1.5 rounded-md border px-3 py-2 text-xs font-semibold transition-colors whitespace-nowrap ${
            onlyShortlist
              ? 'border-amber-400 bg-amber-500/15 text-amber-300'
              : 'border-white/15 bg-[#121822] text-slate-300 hover:text-white'
          }`}
        >
          <Star className="h-3.5 w-3.5" />
          <span>Danh sách theo dõi ({career.shortlistIds.length})</span>
        </button>
      </div>

      {/* Filters */}
      <div className="grid grid-cols-1 gap-3 rounded-lg border border-white/10 bg-[#121822] p-4 sm:grid-cols-4">
        <div className="relative">
          <Search className="pointer-events-none absolute left-3 top-2.5 h-4 w-4 text-slate-500" />
          <input
            type="text"
            aria-label="Tìm tên cầu thủ hoặc CLB"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Tìm cầu thủ, CLB..."
            className="w-full rounded-md border border-white/15 bg-[#0B0F17] py-2 pl-9 pr-3 text-xs text-white placeholder-slate-500 focus:border-emerald-500 focus:outline-none"
          />
        </div>

        <select
          aria-label="Lọc theo giải đấu"
          value={leagueFilter}
          onChange={(e) => setLeagueFilter(e.target.value as 'ALL' | LeagueId)}
          className="rounded-md border border-white/15 bg-[#0B0F17] px-3 py-2 text-xs text-white focus:border-emerald-500 focus:outline-none"
        >
          <option value="ALL">Tất cả giải đấu</option>
          {getLeagueOrder(career).map((lid) => (
            <option key={lid} value={lid}>
              {getLeagueDef(career, lid).name}
            </option>
          ))}
        </select>

        <select
          aria-label="Lọc theo vị trí"
          value={posFilter}
          onChange={(e) => setPosFilter(e.target.value as 'ALL' | Position)}
          className="rounded-md border border-white/15 bg-[#0B0F17] px-3 py-2 text-xs text-white focus:border-emerald-500 focus:outline-none"
        >
          <option value="ALL">Tất cả vị trí</option>
          {(['GK', 'LB', 'CB', 'RB', 'DM', 'CM', 'AM', 'LW', 'RW', 'ST'] as Position[]).map((pos) => (
            <option key={pos} value={pos}>
              {pos}
            </option>
          ))}
        </select>

        <select
          aria-label="Lọc theo mức giá tối đa"
          value={maxPrice}
          onChange={(e) => setMaxPrice(Number(e.target.value))}
          className="rounded-md border border-white/15 bg-[#0B0F17] px-3 py-2 text-xs text-white focus:border-emerald-500 focus:outline-none"
        >
          <option value={200}>Giá tối đa: Không giới hạn</option>
          <option value={80}>Dưới €80M</option>
          <option value={40}>Dưới €40M</option>
          <option value={15}>Dưới €15M</option>
          <option value={5}>Dưới €5M</option>
        </select>
      </div>

      {/* Market Table */}
      <div className="overflow-x-auto rounded-lg border border-white/10 bg-[#121822]">
        <table className="w-full border-collapse text-left text-xs tabular-nums">
          <thead>
            <tr className="border-b border-white/10 bg-[#0F141D] text-slate-400">
              <th className="px-3 py-2.5 font-semibold">Cầu thủ</th>
              <th className="px-3 py-2.5 font-semibold">CLB & Giải</th>
              <th className="px-3 py-2.5 font-semibold">Vị trí</th>
              <th className="px-3 py-2.5 text-right font-semibold">Tuổi</th>
              <th className="px-3 py-2.5 text-right font-semibold">OVR</th>
              <th className="px-3 py-2.5 text-right font-semibold">Lương</th>
              <th className="px-3 py-2.5 text-right font-semibold">Giá trị</th>
              <th className="px-3 py-2.5 text-right font-semibold">Thao tác</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-white/5">
            {marketPlayers.length === 0 ? (
              <tr>
                <td colSpan={8} className="px-4 py-8 text-center text-slate-400">
                  Không tìm thấy cầu thủ phù hợp với bộ lọc hiện tại.
                </td>
              </tr>
            ) : (
              marketPlayers.map((p) => {
                const club = career.clubs[p.clubId];
                const league = club ? getLeagueDef(career, club.leagueId) : undefined;
                const shortlisted = career.shortlistIds.includes(p.id);
                return (
                  <tr key={p.id} className="hover:bg-white/[0.03]">
                    <td className="px-3 py-2.5">
                      <div className="font-semibold text-white">{p.name}</div>
                      <div className="text-[11px] text-slate-500">{p.nationality}</div>
                    </td>
                    <td className="px-3 py-2.5">
                      <div className="text-slate-200">{club?.name}</div>
                      <div className="text-[11px] text-slate-500">{league?.name}</div>
                    </td>
                    <td className="px-3 py-2.5 font-mono font-semibold text-slate-200">
                      {p.primaryPosition}
                    </td>
                    <td className="px-3 py-2.5 text-right font-mono text-slate-300">{p.age}</td>
                    <td className="px-3 py-2.5 text-right font-mono font-bold text-emerald-400">
                      {p.ovr}
                    </td>
                    <td className="px-3 py-2.5 text-right font-mono text-slate-300">€{p.weeklyWage}k</td>
                    <td className="px-3 py-2.5 text-right font-mono font-semibold text-white">
                      €{p.marketValue.toFixed(1)}M
                    </td>
                    <td className="px-3 py-2.5 text-right">
                      <div className="flex items-center justify-end gap-2">
                        <button
                          type="button"
                          aria-label={`Theo dõi ${p.name}`}
                          onClick={() => onToggleShortlist(p.id)}
                          className={`rounded p-1.5 transition-colors ${
                            shortlisted ? 'text-amber-400' : 'text-slate-500 hover:text-slate-300'
                          }`}
                        >
                          <Star className="h-3.5 w-3.5 fill-current" />
                        </button>
                        <button
                          type="button"
                          onClick={() => openNegotiation(p)}
                          className="rounded bg-emerald-600 px-3 py-1.5 text-xs font-semibold text-white transition-colors hover:bg-emerald-500 whitespace-nowrap"
                        >
                          Đàm phán
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })
            )}
          </tbody>
        </table>
      </div>

      {/* Negotiation Modal */}
      {targetPlayer && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4"
          role="dialog"
          aria-modal="true"
          aria-label={`Đàm phán chiêu mộ ${targetPlayer.name}`}
        >
          <div className="w-full max-w-lg rounded-lg border border-white/15 bg-[#121822] p-6">
            <div className="flex items-start justify-between border-b border-white/10 pb-3">
              <div>
                <div className="text-xs text-slate-400">
                  {career.clubs[targetPlayer.clubId]?.name} · {targetPlayer.primaryPosition} · OVR {targetPlayer.ovr}
                </div>
                <h2 className="mt-0.5 font-display text-2xl font-bold text-white">
                  Đàm phán: {targetPlayer.name}
                </h2>
              </div>
              <button
                type="button"
                aria-label="Đóng đàm phán"
                onClick={() => setTargetPlayer(null)}
                className="rounded p-1 text-slate-400 hover:text-white"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            {step === 'bid' ? (
              <div className="mt-4 space-y-4">
                <div className="flex justify-between text-xs text-slate-300 tabular-nums">
                  <span>Giá trị thị trường: <strong className="text-white">€{targetPlayer.marketValue.toFixed(1)}M</strong></span>
                  <span>Ngân sách CLB: <strong className="text-emerald-400">€{userClub.finances.transferBudget.toFixed(1)}M</strong></span>
                </div>

                <div>
                  <label htmlFor="bid-fee" className="mb-1 block text-xs font-semibold text-slate-300">
                    Mức phí đề nghị (€ Triệu)
                  </label>
                  <input
                    id="bid-fee"
                    type="number"
                    step="0.5"
                    min="0.5"
                    value={bidFee}
                    onChange={(e) => setBidFee(Number(e.target.value))}
                    className="w-full rounded-md border border-white/15 bg-[#0B0F17] px-3 py-2 font-mono text-sm text-white focus:border-emerald-500 focus:outline-none"
                  />
                </div>

                {bidMessage && (
                  <p className="rounded border border-white/10 bg-[#0B0F17] p-3 text-xs text-slate-200">
                    {bidMessage}
                  </p>
                )}

                <div className="flex justify-end gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setTargetPlayer(null)}
                    className="rounded-md border border-white/15 px-4 py-2 text-xs font-semibold text-slate-300 hover:text-white"
                  >
                    Hủy bỏ
                  </button>
                  <button
                    type="button"
                    onClick={handleSubmitBid}
                    className="rounded-md bg-emerald-600 px-4 py-2 text-xs font-bold text-white hover:bg-emerald-500"
                  >
                    Gửi đề nghị chuyển nhượng
                  </button>
                </div>
              </div>
            ) : (
              <div className="mt-4 space-y-4">
                <p className="rounded border border-emerald-500/30 bg-emerald-500/10 p-3 text-xs text-emerald-300">
                  CLB chủ quản đã đồng ý mức phí €{bidFee.toFixed(1)}M! Bây giờ hãy đàm phán điều khoản cá nhân với cầu thủ.
                </p>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label htmlFor="wage-offer" className="mb-1 block text-xs font-semibold text-slate-300">
                      Lương tuần (€k/tuần)
                    </label>
                    <input
                      id="wage-offer"
                      type="number"
                      min="4"
                      value={wageOffer}
                      onChange={(e) => setWageOffer(Number(e.target.value))}
                      className="w-full rounded-md border border-white/15 bg-[#0B0F17] px-3 py-2 font-mono text-sm text-white"
                    />
                  </div>
                  <div>
                    <label htmlFor="years-offer" className="mb-1 block text-xs font-semibold text-slate-300">
                      Thời hạn (năm)
                    </label>
                    <select
                      id="years-offer"
                      value={contractYears}
                      onChange={(e) => setContractYears(Number(e.target.value))}
                      className="w-full rounded-md border border-white/15 bg-[#0B0F17] px-3 py-2 text-sm text-white"
                    >
                      <option value={2}>2 năm</option>
                      <option value={3}>3 năm</option>
                      <option value={4}>4 năm</option>
                      <option value={5}>5 năm</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label htmlFor="role-offer" className="mb-1 block text-xs font-semibold text-slate-300">
                    Cam kết vai trò trong đội
                  </label>
                  <select
                    id="role-offer"
                    value={roleOffer}
                    onChange={(e) => setRoleOffer(e.target.value as SquadRole)}
                    className="w-full rounded-md border border-white/15 bg-[#0B0F17] px-3 py-2 text-sm text-white"
                  >
                    <option value="Ngôi sao">Ngôi sao</option>
                    <option value="Đá chính">Đá chính</option>
                    <option value="Xoay tua">Xoay tua</option>
                    <option value="Dự bị">Dự bị</option>
                  </select>
                </div>

                {contractMessage && (
                  <p className="rounded border border-white/10 bg-[#0B0F17] p-3 text-xs text-amber-300">
                    {contractMessage}
                  </p>
                )}

                <div className="flex justify-end gap-3 pt-2">
                  <button
                    type="button"
                    onClick={() => setTargetPlayer(null)}
                    className="rounded-md border border-white/15 px-4 py-2 text-xs font-semibold text-slate-300 hover:text-white"
                  >
                    Chấm dứt đàm phán
                  </button>
                  <button
                    type="button"
                    onClick={handleSubmitContract}
                    className="rounded-md bg-emerald-600 px-4 py-2 text-xs font-bold text-white hover:bg-emerald-500"
                  >
                    Ký hợp đồng chính thức
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
