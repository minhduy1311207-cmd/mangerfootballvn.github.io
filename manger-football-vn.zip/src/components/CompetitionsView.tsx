import React, { useMemo, useState } from 'react';
import { formatDateVN, getLeagueDef, getLeagueOrder } from '../engine/schedule';
import { CareerState, LeagueId } from '../types/fm';
import { ClubCrest } from './ClubCrest';

interface CompetitionsViewProps {
  career: CareerState;
}

export const CompetitionsView: React.FC<CompetitionsViewProps> = ({ career }) => {
  const leagueOrder = getLeagueOrder(career);
  const [selectedLeague, setSelectedLeague] = useState<LeagueId>(career.activeLeagueId);
  const [selectedRound, setSelectedRound] = useState<number>(() => {
    const nextUnplayed = (career.fixturesByLeague[career.activeLeagueId] ?? []).find((f) => !f.played);
    return nextUnplayed?.round ?? 1;
  });

  const league = getLeagueDef(career, selectedLeague);
  const standings = career.standingsByLeague[selectedLeague] ?? [];
  const fixtures = career.fixturesByLeague[selectedLeague] ?? [];
  const roundFixtures = fixtures.filter((f) => f.round === selectedRound);

  const totalRounds = useMemo(() => {
    return fixtures.reduce((max, f) => Math.max(max, f.round), 1);
  }, [fixtures]);

  const topScorers = useMemo(() => {
    const leagueClubIds = new Set(
      Object.values(career.clubs)
        .filter((c) => c.leagueId === selectedLeague)
        .map((c) => c.id)
    );
    return Object.values(career.players)
      .filter((p) => leagueClubIds.has(p.clubId) && p.stats.goals > 0)
      .sort((a, b) => b.stats.goals - a.stats.goals || b.stats.assists - a.stats.assists)
      .slice(0, 8);
  }, [career.clubs, career.players, selectedLeague]);

  const handleChangeLeague = (lid: LeagueId) => {
    setSelectedLeague(lid);
    const nextUnplayed = career.fixturesByLeague[lid]?.find((f) => !f.played);
    setSelectedRound(nextUnplayed?.round ?? 1);
  };

  return (
    <div className="mx-auto max-w-[1320px] space-y-5">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="font-display text-3xl font-bold text-white">Giải Đấu & Bảng Xếp Hạng</h1>
          <p className="text-xs text-slate-400">
            Hệ thống thăng hạng 3 cấp ({getLeagueDef(career, 'div_3').name} → {getLeagueDef(career, 'div_2').name} → {getLeagueDef(career, career.countryLeagueId ?? career.activeLeagueId).name}) và các giải VĐQG
          </p>
        </div>

        <div className="flex flex-wrap gap-1 rounded-md border border-white/10 bg-[#121822] p-1">
          {leagueOrder.map((lid) => {
            const lg = getLeagueDef(career, lid);
            const active = selectedLeague === lid;
            const isUserHere = career.activeLeagueId === lid;
            return (
              <button
                key={lid}
                type="button"
                onClick={() => handleChangeLeague(lid)}
                className={`rounded px-2.5 py-1.5 text-xs font-semibold transition-colors whitespace-nowrap ${
                  active ? 'bg-emerald-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                {lg.name}
                {isUserHere ? ' ★' : ''}
              </button>
            );
          })}
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        {/* Standings Table */}
        <section className="rounded-lg border border-white/10 bg-[#121822] lg:col-span-7">
          <div className="flex items-center justify-between border-b border-white/10 px-4 py-3">
            <div>
              <h2 className="font-display text-xl font-bold text-white">
                {league.name} ({league.country})
              </h2>
              <p className="text-[11px] text-slate-400">
                {league.tierLevel === 3
                  ? `Hạng thấp nhất · Top ${league.promotionSlots ?? 2} thăng hạng lên ${getLeagueDef(career, league.promotedToLeagueId ?? 'div_2').name} · Không xuống hạng`
                  : league.tierLevel === 2
                  ? `Hạng 2 · Top ${league.promotionSlots ?? 2} thăng hạng lên ${getLeagueDef(career, league.promotedToLeagueId ?? career.countryLeagueId).name} · ${league.relegationSlots} đội cuối xuống hạng`
                  : `Top ${league.championsSlots} dự Cúp châu lục · ${league.relegationSlots} đội cuối xuống hạng`}
              </p>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full border-collapse text-left text-xs tabular-nums">
              <thead>
                <tr className="border-b border-white/10 bg-[#0F141D] text-slate-400">
                  <th className="px-3 py-2.5 font-semibold">#</th>
                  <th className="px-3 py-2.5 font-semibold">Câu lạc bộ</th>
                  <th className="px-2.5 py-2.5 text-right font-semibold">Tr</th>
                  <th className="px-2.5 py-2.5 text-right font-semibold">T</th>
                  <th className="px-2.5 py-2.5 text-right font-semibold">H</th>
                  <th className="px-2.5 py-2.5 text-right font-semibold">B</th>
                  <th className="px-2.5 py-2.5 text-right font-semibold">HS</th>
                  <th className="px-3 py-2.5 text-right font-semibold">Điểm</th>
                  <th className="px-3 py-2.5 text-right font-semibold">Phong độ</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/5">
                {standings.map((row, idx) => {
                  const club = career.clubs[row.clubId];
                  if (!club) return null;
                  const isUser = club.id === career.userClubId;
                  const rank = idx + 1;
                  const topSlots =
                    league.tierLevel === 2 || league.tierLevel === 3
                      ? league.promotionSlots ?? 2
                      : league.championsSlots;
                  const zoneColor =
                    rank === 1
                      ? 'text-amber-400'
                      : rank <= topSlots
                      ? 'text-emerald-400'
                      : league.relegationSlots > 0 && rank > standings.length - league.relegationSlots
                      ? 'text-rose-400'
                      : 'text-slate-400';

                  return (
                    <tr
                      key={club.id}
                      className={isUser ? 'bg-emerald-500/12' : 'hover:bg-white/[0.03]'}
                    >
                      <td className={`px-3 py-2.5 font-mono font-bold ${zoneColor}`}>{rank}</td>
                      <td className="px-3 py-2.5">
                        <div className="flex items-center gap-2.5">
                          <ClubCrest
                            primaryColor={club.primaryColor}
                            secondaryColor={club.secondaryColor}
                            pattern={club.crestPattern}
                            shortName={club.shortName}
                            size={24}
                          />
                          <span className={`font-semibold ${isUser ? 'text-emerald-300' : 'text-white'}`}>
                            {club.name}
                          </span>
                        </div>
                      </td>
                      <td className="px-2.5 py-2.5 text-right font-mono text-slate-300">{row.played}</td>
                      <td className="px-2.5 py-2.5 text-right font-mono text-slate-300">{row.won}</td>
                      <td className="px-2.5 py-2.5 text-right font-mono text-slate-300">{row.drawn}</td>
                      <td className="px-2.5 py-2.5 text-right font-mono text-slate-300">{row.lost}</td>
                      <td className="px-2.5 py-2.5 text-right font-mono text-slate-300">
                        {row.gd > 0 ? `+${row.gd}` : row.gd}
                      </td>
                      <td className="px-3 py-2.5 text-right font-mono font-bold text-white">
                        {row.points}
                      </td>
                      <td className="px-3 py-2.5 text-right font-mono text-[11px] text-slate-300">
                        {row.form.length === 0 ? '—' : row.form.join(' ')}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </section>

        {/* Right: Round Fixtures & Top Scorers */}
        <div className="space-y-6 lg:col-span-5">
          <section className="rounded-lg border border-white/10 bg-[#121822] p-4">
            <div className="mb-3 flex items-center justify-between gap-3">
              <h2 className="font-display text-xl font-bold text-white">Lịch Thi Đấu</h2>
              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  disabled={selectedRound <= 1}
                  onClick={() => setSelectedRound((r) => Math.max(1, r - 1))}
                  className="rounded border border-white/15 px-2.5 py-1 text-xs text-slate-300 hover:bg-white/5 disabled:opacity-40"
                >
                  Trước
                </button>
                <span className="font-mono text-xs font-semibold text-white tabular-nums px-1">
                  Vòng {selectedRound}/{totalRounds}
                </span>
                <button
                  type="button"
                  disabled={selectedRound >= totalRounds}
                  onClick={() => setSelectedRound((r) => Math.min(totalRounds, r + 1))}
                  className="rounded border border-white/15 px-2.5 py-1 text-xs text-slate-300 hover:bg-white/5 disabled:opacity-40"
                >
                  Sau
                </button>
              </div>
            </div>

            <div className="space-y-2">
              {roundFixtures.map((f) => {
                const hc = career.clubs[f.homeClubId];
                const ac = career.clubs[f.awayClubId];
                if (!hc || !ac) return null;
                const involvesUser = hc.id === career.userClubId || ac.id === career.userClubId;
                return (
                  <div
                    key={f.id}
                    className={`flex items-center justify-between rounded border px-3 py-2 text-xs tabular-nums ${
                      involvesUser
                        ? 'border-emerald-500/40 bg-emerald-500/10'
                        : 'border-white/5 bg-[#0B0F17]'
                    }`}
                  >
                    <div className="flex min-w-0 flex-1 items-center justify-end gap-2 text-right">
                      <span className="truncate font-semibold text-white">{hc.shortName}</span>
                      <ClubCrest
                        primaryColor={hc.primaryColor}
                        secondaryColor={hc.secondaryColor}
                        pattern={hc.crestPattern}
                        shortName={hc.shortName}
                        size={20}
                      />
                    </div>
                    <div className="mx-3 w-16 text-center font-mono font-bold text-white">
                      {f.played ? `${f.homeGoals} - ${f.awayGoals}` : formatDateVN(f.dateISO).slice(0, 5)}
                    </div>
                    <div className="flex min-w-0 flex-1 items-center gap-2">
                      <ClubCrest
                        primaryColor={ac.primaryColor}
                        secondaryColor={ac.secondaryColor}
                        pattern={ac.crestPattern}
                        shortName={ac.shortName}
                        size={20}
                      />
                      <span className="truncate font-semibold text-white">{ac.shortName}</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </section>

          <section className="rounded-lg border border-white/10 bg-[#121822] p-4">
            <h2 className="mb-3 font-display text-xl font-bold text-white">Vua Phá Lưới</h2>
            {topScorers.length === 0 ? (
              <p className="text-xs text-slate-400">
                Chưa có bàn thắng nào được ghi tại {league.name}. Hãy tiến hành thi đấu vòng 1.
              </p>
            ) : (
              <div className="divide-y divide-white/5 text-xs tabular-nums">
                {topScorers.map((p, i) => (
                  <div key={p.id} className="flex items-center justify-between py-2">
                    <div>
                      <span className="font-mono text-slate-500 mr-2">{i + 1}.</span>
                      <span className="font-semibold text-white">{p.name}</span>
                      <span className="ml-2 text-slate-400">{career.clubs[p.clubId]?.shortName}</span>
                    </div>
                    <div className="font-mono font-bold text-emerald-400">
                      {p.stats.goals} bàn
                    </div>
                  </div>
                ))}
              </div>
            )}
          </section>
        </div>
      </div>
    </div>
  );
};
