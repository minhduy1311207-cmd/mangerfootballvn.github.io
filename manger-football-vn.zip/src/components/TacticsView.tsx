import React, { useMemo, useState } from 'react';
import { FORMATIONS, ROLES_BY_POSITION, autoPickBestLineup } from '../data/database';
import { calculateTeamRatings, getPositionFamiliarity, switchFormationTactics } from '../engine/tactics';
import {
  CareerState,
  DefensiveLine,
  FormationName,
  PassingStyle,
  PressingIntensity,
  TacticalMentality,
  TeamTactics,
  TempoStyle,
} from '../types/fm';

interface TacticsViewProps {
  career: CareerState;
  onUpdateTactics: (nextTactics: TeamTactics) => void;
}

const FORMATION_NAMES = Object.keys(FORMATIONS) as FormationName[];

export const TacticsView: React.FC<TacticsViewProps> = ({ career, onUpdateTactics }) => {
  const club = career.clubs[career.userClubId];
  const tactics = club.tactics;
  const slots = FORMATIONS[tactics.formation];

  const [selectedSlotIdx, setSelectedSlotIdx] = useState<number | null>(null);

  const clubPlayers = useMemo(
    () =>
      Object.values(career.players)
        .filter((p) => p.clubId === club.id)
        .sort((a, b) => b.ovr - a.ovr),
    [career.players, club.id]
  );

  const ratings = useMemo(() => calculateTeamRatings(club, career.players), [club, career.players]);

  const handleFormationChange = (nextFormation: FormationName) => {
    const next = switchFormationTactics(tactics, nextFormation, clubPlayers);
    setSelectedSlotIdx(null);
    onUpdateTactics(next);
  };

  const handleAutoPick = () => {
    const { lineupIds, benchIds } = autoPickBestLineup(clubPlayers, tactics.formation);
    setSelectedSlotIdx(null);
    onUpdateTactics({ ...tactics, lineupIds, benchIds });
  };

  const handleSwapWithPlayer = (targetPlayerId: string) => {
    if (selectedSlotIdx === null) return;
    const nextLineup = [...tactics.lineupIds];
    const nextBench = [...tactics.benchIds];

    const currentInSlot = nextLineup[selectedSlotIdx];
    const existingLineupIdx = nextLineup.indexOf(targetPlayerId);

    if (existingLineupIdx !== -1) {
      // Swap two starters
      nextLineup[selectedSlotIdx] = targetPlayerId;
      nextLineup[existingLineupIdx] = currentInSlot;
    } else {
      // Replace starter with bench/reserve player
      nextLineup[selectedSlotIdx] = targetPlayerId;
      const benchIdx = nextBench.indexOf(targetPlayerId);
      if (benchIdx !== -1 && currentInSlot) {
        nextBench[benchIdx] = currentInSlot;
      } else if (benchIdx !== -1) {
        nextBench.splice(benchIdx, 1);
      }
    }

    setSelectedSlotIdx(null);
    onUpdateTactics({ ...tactics, lineupIds: nextLineup, benchIds: nextBench });
  };

  const selectedSlot = selectedSlotIdx !== null ? slots[selectedSlotIdx] : null;
  const selectedSlotPlayerId = selectedSlotIdx !== null ? tactics.lineupIds[selectedSlotIdx] : null;
  const selectedSlotPlayer = selectedSlotPlayerId ? career.players[selectedSlotPlayerId] : null;

  return (
    <div className="mx-auto max-w-[1320px] space-y-5">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="font-display text-3xl font-bold text-white">Bảng Chiến Thuật</h1>
          <p className="text-xs text-slate-400">
            Chọn một vị trí trên sân rồi nhấn vào cầu thủ khác để hoán đổi · Điều chỉnh vai trò và chỉ đạo đội bóng
          </p>
        </div>
        <button
          type="button"
          onClick={handleAutoPick}
          className="rounded-md border border-emerald-500/40 bg-emerald-500/12 px-4 py-2 text-xs font-bold text-emerald-300 transition-colors hover:bg-emerald-500/20 whitespace-nowrap"
        >
          Tự động chọn đội hình tối ưu
        </button>
      </div>

      {/* Tactical Ratings Strip */}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-5 tabular-nums">
        <div className="rounded-md border border-white/10 bg-[#121822] px-4 py-2.5">
          <div className="text-[11px] text-slate-400">Tổng lực OVR</div>
          <div className="font-mono text-xl font-bold text-emerald-400">{ratings.overall}</div>
        </div>
        <div className="rounded-md border border-white/10 bg-[#121822] px-4 py-2.5">
          <div className="text-[11px] text-slate-400">Tấn công</div>
          <div className="font-mono text-xl font-bold text-white">{ratings.attack}</div>
        </div>
        <div className="rounded-md border border-white/10 bg-[#121822] px-4 py-2.5">
          <div className="text-[11px] text-slate-400">Tuyến giữa</div>
          <div className="font-mono text-xl font-bold text-white">{ratings.midfield}</div>
        </div>
        <div className="rounded-md border border-white/10 bg-[#121822] px-4 py-2.5">
          <div className="text-[11px] text-slate-400">Phòng ngự</div>
          <div className="font-mono text-xl font-bold text-white">{ratings.defense}</div>
        </div>
        <div className="rounded-md border border-white/10 bg-[#121822] px-4 py-2.5">
          <div className="text-[11px] text-slate-400">Ăn ý vị trí</div>
          <div className="font-mono text-xl font-bold text-sky-400">{ratings.tacticalFit}%</div>
        </div>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        {/* Left: Team Instructions + Interactive 2D Pitch */}
        <div className="space-y-4 lg:col-span-7">
          {/* Team Instructions Toolbar */}
          <div className="grid grid-cols-2 gap-3 rounded-lg border border-white/10 bg-[#121822] p-4 sm:grid-cols-3">
            <div>
              <label htmlFor="tac-formation" className="mb-1 block text-[11px] font-semibold text-slate-400">
                Sơ đồ chiến thuật
              </label>
              <select
                id="tac-formation"
                value={tactics.formation}
                onChange={(e) => handleFormationChange(e.target.value as FormationName)}
                className="w-full rounded border border-white/15 bg-[#0B0F17] px-2.5 py-1.5 text-xs font-semibold text-white focus:border-emerald-500 focus:outline-none"
              >
                {FORMATION_NAMES.map((f) => (
                  <option key={f} value={f}>
                    {f}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label htmlFor="tac-mentality" className="mb-1 block text-[11px] font-semibold text-slate-400">
                Tâm lý thi đấu
              </label>
              <select
                id="tac-mentality"
                value={tactics.mentality}
                onChange={(e) =>
                  onUpdateTactics({ ...tactics, mentality: e.target.value as TacticalMentality })
                }
                className="w-full rounded border border-white/15 bg-[#0B0F17] px-2.5 py-1.5 text-xs font-semibold text-white focus:border-emerald-500 focus:outline-none"
              >
                {(['Rất phòng ngự', 'Phòng ngự', 'Cân bằng', 'Tấn công', 'Tổng lực'] as TacticalMentality[]).map(
                  (m) => (
                    <option key={m} value={m}>
                      {m}
                    </option>
                  )
                )}
              </select>
            </div>

            <div>
              <label htmlFor="tac-passing" className="mb-1 block text-[11px] font-semibold text-slate-400">
                Cự ly chuyền bóng
              </label>
              <select
                id="tac-passing"
                value={tactics.passing}
                onChange={(e) =>
                  onUpdateTactics({ ...tactics, passing: e.target.value as PassingStyle })
                }
                className="w-full rounded border border-white/15 bg-[#0B0F17] px-2.5 py-1.5 text-xs font-semibold text-white focus:border-emerald-500 focus:outline-none"
              >
                <option value="Ngắn">Ngắn (Kiểm soát)</option>
                <option value="Kết hợp">Kết hợp</option>
                <option value="Dài">Dài (Phản công)</option>
              </select>
            </div>

            <div>
              <label htmlFor="tac-tempo" className="mb-1 block text-[11px] font-semibold text-slate-400">
                Nhịp độ triển khai
              </label>
              <select
                id="tac-tempo"
                value={tactics.tempo}
                onChange={(e) =>
                  onUpdateTactics({ ...tactics, tempo: e.target.value as TempoStyle })
                }
                className="w-full rounded border border-white/15 bg-[#0B0F17] px-2.5 py-1.5 text-xs font-semibold text-white focus:border-emerald-500 focus:outline-none"
              >
                <option value="Chậm">Chậm</option>
                <option value="Vừa">Vừa</option>
                <option value="Nhanh">Nhanh</option>
              </select>
            </div>

            <div>
              <label htmlFor="tac-pressing" className="mb-1 block text-[11px] font-semibold text-slate-400">
                Cường độ Pressing
              </label>
              <select
                id="tac-pressing"
                value={tactics.pressing}
                onChange={(e) =>
                  onUpdateTactics({ ...tactics, pressing: e.target.value as PressingIntensity })
                }
                className="w-full rounded border border-white/15 bg-[#0B0F17] px-2.5 py-1.5 text-xs font-semibold text-white focus:border-emerald-500 focus:outline-none"
              >
                <option value="Thấp">Thấp (Giữ sức)</option>
                <option value="Trung bình">Trung bình</option>
                <option value="Gegenpress">Gegenpress (Áp sát rát)</option>
              </select>
            </div>

            <div>
              <label htmlFor="tac-line" className="mb-1 block text-[11px] font-semibold text-slate-400">
                Đường phòng ngự
              </label>
              <select
                id="tac-line"
                value={tactics.defensiveLine}
                onChange={(e) =>
                  onUpdateTactics({ ...tactics, defensiveLine: e.target.value as DefensiveLine })
                }
                className="w-full rounded border border-white/15 bg-[#0B0F17] px-2.5 py-1.5 text-xs font-semibold text-white focus:border-emerald-500 focus:outline-none"
              >
                <option value="Thấp">Lùi sâu</option>
                <option value="Trung bình">Trung bình</option>
                <option value="Dâng cao">Dâng cao bẫy việt vị</option>
              </select>
            </div>
          </div>

          {/* 2D Interactive Pitch */}
          <div
            className="relative aspect-[5/4.4] w-full overflow-hidden rounded-lg border border-white/15 select-none"
            style={{
              background:
                'repeating-linear-gradient(180deg, #134E2E 0px, #134E2E 38px, #165935 38px, #165935 76px)',
            }}
          >
            {/* Pitch SVG Markings */}
            <svg
              viewBox="0 0 100 115"
              preserveAspectRatio="none"
              className="pointer-events-none absolute inset-0 h-full w-full"
              aria-hidden="true"
            >
              <rect x="4" y="4" width="92" height="107" fill="none" stroke="rgba(255,255,255,0.28)" strokeWidth="0.6" />
              <line x1="4" y1="57.5" x2="96" y2="57.5" stroke="rgba(255,255,255,0.28)" strokeWidth="0.6" />
              <circle cx="50" cy="57.5" r="10.5" fill="none" stroke="rgba(255,255,255,0.28)" strokeWidth="0.6" />
              <rect x="26" y="4" width="48" height="15" fill="none" stroke="rgba(255,255,255,0.28)" strokeWidth="0.6" />
              <rect x="26" y="96" width="48" height="15" fill="none" stroke="rgba(255,255,255,0.28)" strokeWidth="0.6" />
            </svg>

            {/* 11 Tactical Nodes */}
            {slots.map((slot, idx) => {
              const pid = tactics.lineupIds[idx];
              const p = pid ? career.players[pid] : undefined;
              const isSelected = selectedSlotIdx === idx;
              const fam = p ? getPositionFamiliarity(p, slot.position) : null;
              const lastName = p ? p.name.split(' ').slice(-1)[0] : 'Trống';

              return (
                <button
                  key={slot.slotIndex}
                  type="button"
                  onClick={() => {
                    if (selectedSlotIdx === null) {
                      setSelectedSlotIdx(idx);
                    } else if (selectedSlotIdx === idx) {
                      setSelectedSlotIdx(null);
                    } else if (p) {
                      handleSwapWithPlayer(p.id);
                    }
                  }}
                  style={{ left: `${slot.x}%`, top: `${slot.y}%` }}
                  className={`absolute -translate-x-1/2 -translate-y-1/2 flex flex-col items-center transition-transform ${
                    isSelected ? 'z-20 scale-110' : 'z-10 hover:scale-105'
                  }`}
                >
                  <div
                    className={`flex h-9 w-9 items-center justify-center rounded-full border-2 font-mono text-xs font-bold shadow-md ${
                      isSelected
                        ? 'border-amber-400 bg-amber-500 text-slate-950'
                        : fam?.multiplier === 1
                        ? 'border-white/90 bg-[#0B0F17]/90 text-white'
                        : fam && fam.multiplier >= 0.8
                        ? 'border-sky-400 bg-[#0B0F17]/90 text-sky-200'
                        : 'border-rose-400 bg-[#0B0F17]/90 text-rose-200'
                    }`}
                  >
                    {p?.shirtNumber ?? '?'}
                  </div>
                  <div className="mt-1 rounded bg-[#0B0F17]/88 px-1.5 py-0.5 text-[11px] font-semibold text-white whitespace-nowrap">
                    {lastName}
                  </div>
                  <div className="text-[10px] font-mono text-emerald-200/90 whitespace-nowrap">
                    {slot.label} · {p?.ovr ?? '-'}
                  </div>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right: Role Inspector & Squad Swap List */}
        <div className="space-y-4 lg:col-span-5">
          {selectedSlot && selectedSlotPlayer && (
            <div className="rounded-lg border border-amber-500/40 bg-[#121822] p-4">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-xs text-amber-400">
                    Đang chọn vị trí {selectedSlot.label} ({selectedSlot.position})
                  </div>
                  <div className="font-display text-xl font-bold text-white">
                    {selectedSlotPlayer.name} · OVR {selectedSlotPlayer.ovr}
                  </div>
                </div>
                <button
                  type="button"
                  onClick={() => setSelectedSlotIdx(null)}
                  className="text-xs text-slate-400 hover:text-white"
                >
                  Bỏ chọn
                </button>
              </div>

              <div className="mt-3 grid grid-cols-2 gap-3">
                <div>
                  <label htmlFor="slot-role" className="mb-1 block text-[11px] text-slate-400">
                    Vai trò cầu thủ
                  </label>
                  <select
                    id="slot-role"
                    value={tactics.slotRoles[selectedSlotIdx!] ?? selectedSlot.role}
                    onChange={(e) => {
                      const nextRoles = [...tactics.slotRoles];
                      nextRoles[selectedSlotIdx!] = e.target.value;
                      onUpdateTactics({ ...tactics, slotRoles: nextRoles });
                    }}
                    className="w-full rounded border border-white/15 bg-[#0B0F17] px-2 py-1.5 text-xs text-white"
                  >
                    {(ROLES_BY_POSITION[selectedSlot.position] ?? [selectedSlot.role]).map((r) => (
                      <option key={r} value={r}>
                        {r}
                      </option>
                    ))}
                  </select>
                </div>

                <div>
                  <label htmlFor="slot-duty" className="mb-1 block text-[11px] text-slate-400">
                    Nhiệm vụ
                  </label>
                  <select
                    id="slot-duty"
                    value={tactics.slotDuties[selectedSlotIdx!] ?? selectedSlot.duty}
                    onChange={(e) => {
                      const nextDuties = [...tactics.slotDuties];
                      nextDuties[selectedSlotIdx!] = e.target.value as 'Phòng ngự' | 'Hỗ trợ' | 'Tấn công';
                      onUpdateTactics({ ...tactics, slotDuties: nextDuties });
                    }}
                    className="w-full rounded border border-white/15 bg-[#0B0F17] px-2 py-1.5 text-xs text-white"
                  >
                    <option value="Phòng ngự">Phòng ngự</option>
                    <option value="Hỗ trợ">Hỗ trợ</option>
                    <option value="Tấn công">Tấn công</option>
                  </select>
                </div>
              </div>
              <p className="mt-2.5 text-[11px] text-slate-400">
                Nhấn vào một cầu thủ trong danh sách bên dưới hoặc trên sân để thay vào vị trí này.
              </p>
            </div>
          )}

          {/* Squad List for Swapping */}
          <div className="rounded-lg border border-white/10 bg-[#121822]">
            <div className="border-b border-white/10 px-4 py-3">
              <h2 className="font-display text-lg font-bold text-white">
                Danh sách Cầu thủ ({clubPlayers.length})
              </h2>
            </div>
            <div className="max-h-[540px] divide-y divide-white/5 overflow-y-auto tabular-nums">
              {clubPlayers.map((p) => {
                const startIdx = tactics.lineupIds.indexOf(p.id);
                const isStarter = startIdx !== -1;
                const isBench = tactics.benchIds.includes(p.id);
                return (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => {
                      if (selectedSlotIdx !== null) {
                        handleSwapWithPlayer(p.id);
                      } else if (isStarter) {
                        setSelectedSlotIdx(startIdx);
                      }
                    }}
                    className={`flex w-full items-center justify-between px-4 py-2.5 text-left text-xs transition-colors ${
                      selectedSlotIdx === startIdx && isStarter
                        ? 'bg-amber-500/15'
                        : 'hover:bg-white/[0.04]'
                    }`}
                  >
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-slate-400 w-6">#{p.shirtNumber}</span>
                        <span className="truncate font-semibold text-white">{p.name}</span>
                      </div>
                      <div className="pl-8 text-[11px] text-slate-500">
                        {p.primaryPosition} · {isStarter ? slots[startIdx]?.label : isBench ? 'Dự bị' : 'Đội B'} · Thể lực {p.condition}%
                      </div>
                    </div>
                    <div className="shrink-0 font-mono text-sm font-bold text-emerald-400">
                      {p.ovr}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
