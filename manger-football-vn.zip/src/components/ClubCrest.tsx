import React from 'react';
import { CrestPattern } from '../types/fm';

interface ClubCrestProps {
  primaryColor: string;
  secondaryColor: string;
  pattern: CrestPattern;
  shortName: string;
  size?: number;
}

export const ClubCrest: React.FC<ClubCrestProps> = ({
  primaryColor,
  secondaryColor,
  pattern,
  shortName,
  size = 36,
}) => {
  const uid = React.useId().replace(/:/g, '');
  const clipId = `crest_clip_${uid}`;

  // Determine readable text color based on primary fill luminance when solid
  const textColor =
    primaryColor.toUpperCase() === '#FFFFFF' || primaryColor.toUpperCase() === '#FFE667' || primaryColor.toUpperCase() === '#FDE100'
      ? '#0F172A'
      : '#FFFFFF';

  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 40 44"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className="shrink-0 select-none"
      aria-hidden="true"
    >
      <defs>
        <clipPath id={clipId}>
          <path d="M20 2L36 7.5V21C36 31.2 29.1 38.9 20 42C10.9 38.9 4 31.2 4 21V7.5L20 2Z" />
        </clipPath>
      </defs>

      <g clipPath={`url(#${clipId})`}>
        <rect x="0" y="0" width="40" height="44" fill={primaryColor} />
        {pattern === 'stripes' && (
          <>
            <rect x="7" y="0" width="6" height="44" fill={secondaryColor} />
            <rect x="17" y="0" width="6" height="44" fill={secondaryColor} />
            <rect x="27" y="0" width="6" height="44" fill={secondaryColor} />
          </>
        )}
        {pattern === 'halves' && <rect x="20" y="0" width="20" height="44" fill={secondaryColor} />}
        {pattern === 'sash' && (
          <polygon points="-4,34 34,-4 44,6 6,44" fill={secondaryColor} />
        )}
        {pattern === 'hoops' && (
          <>
            <rect x="0" y="9" width="40" height="6" fill={secondaryColor} />
            <rect x="0" y="21" width="40" height="6" fill={secondaryColor} />
            <rect x="0" y="33" width="40" height="6" fill={secondaryColor} />
          </>
        )}
        {pattern === 'chevron' && (
          <polygon points="0,14 20,27 40,14 40,22 20,35 0,22" fill={secondaryColor} />
        )}
        {/* Subtle top gloss */}
        <rect x="0" y="0" width="40" height="16" fill="rgba(255,255,255,0.08)" />
      </g>

      {/* Outer shield border */}
      <path
        d="M20 2L36 7.5V21C36 31.2 29.1 38.9 20 42C10.9 38.9 4 31.2 4 21V7.5L20 2Z"
        stroke="rgba(255,255,255,0.45)"
        strokeWidth="1.75"
      />

      {/* Center ribbon badge for crisp 3-letter code */}
      <rect x="6" y="15.5" width="28" height="11" rx="2" fill="rgba(11,15,23,0.82)" />
      <text
        x="20"
        y="23.5"
        textAnchor="middle"
        fill={pattern === 'solid' ? '#F8FAFC' : textColor === '#0F172A' ? '#F8FAFC' : '#F8FAFC'}
        fontSize="8.5"
        fontWeight="800"
        fontFamily="Barlow Condensed, sans-serif"
        letterSpacing="0.6"
      >
        {shortName.slice(0, 3)}
      </text>
    </svg>
  );
};
