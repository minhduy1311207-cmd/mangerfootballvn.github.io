import React from 'react';
import { CareerState, TrainingFocus, TrainingIntensity } from '../types/fm';

interface TrainingViewProps {
  career: CareerState;
  onUpdateTraining: (focus: TrainingFocus, intensity: TrainingIntensity) => void;
}

const FOCUSES: { id: TrainingFocus; desc: string }[] = [
  { id: 'Cân bằng tổng hợp', desc: 'Duy trì nền tảng thể lực, chiến thuật và kỹ năng đồng đều.' },
  { id: 'Chiến thuật & Kiểm soát bóng', desc: 'Tăng độ gắn kết sơ đồ, chuyền ngắn và nhận thức không gian.' },
  { id: 'Dứt điểm & Phối hợp tấn công', desc: 'Rèn luyện khâu dứt điểm, chạy chỗ và chọc khe 1/3 cuối sân.' },
  { id: 'Phòng ngự & Kèm người', desc: 'Cải thiện cự ly đội hình, xoạc bóng và chống bóng bổng.' },
  { id: 'Thể lực & Pressing', desc: 'Tối ưu sức bền cho lối đá Gegenpress nhưng tiêu hao thể lực tuần.' },
  { id: 'Hồi phục nhẹ', desc: 'Ưu tiên hồi phục thể lực tối đa giữa lịch thi đấu dày đặc.' },
];

export const TrainingView: React.FC<TrainingViewProps> = ({ career, onUpdateTraining }) => {
  const clubPlayers = Object.values(career.players)
    .filter((p) => p.clubId === career.userClubId)
    .sort((a, b) => a.age - b.age);

  const youthProspects = clubPlayers.filter((p) => p.age <= 23).slice(0, 6);

  return (
    <div className="mx-auto max-w-[1320px] space-y-6">
      <div>
        <h1 className="font-display text-3xl font-bold text-white">Giáo Án Tập Luyện</h1>
        <p className="text-xs text-slate-400">
          Điều chỉnh giáo án tuần và cường độ vận động để cân bằng giữa phát triển chỉ số và hồi phục thể lực
        </p>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        <section className="space-y-4 rounded-lg border border-white/10 bg-[#121822] p-5 lg:col-span-7">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-white/10 pb-4">
            <h2 className="font-display text-xl font-bold text-white">Trọng tâm tuần này</h2>
            <div className="flex items-center gap-1 rounded-md bg-[#0B0F17] p-1">
              {(['Nhẹ', 'Trung bình', 'Cao'] as TrainingIntensity[]).map((lvl) => (
                <button
                  key={lvl}
                  type="button"
                  onClick={() => onUpdateTraining(career.trainingFocus, lvl)}
                  className={`rounded px-3 py-1 text-xs font-semibold transition-colors ${
                    career.trainingIntensity === lvl
                      ? 'bg-emerald-600 text-white'
                      : 'text-slate-400 hover:text-white'
                  }`}
                >
                  Cường độ: {lvl}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
            {FOCUSES.map((item) => {
              const active = career.trainingFocus === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => onUpdateTraining(item.id, career.trainingIntensity)}
                  className={`rounded-md border p-4 text-left transition-colors ${
                    active
                      ? 'border-emerald-500 bg-emerald-500/12'
                      : 'border-white/10 bg-[#0B0F17] hover:border-white/25'
                  }`}
                >
                  <div className="text-sm font-bold text-white">{item.id}</div>
                  <div className="mt-1 text-xs leading-relaxed text-slate-400">{item.desc}</div>
                </button>
              );
            })}
          </div>
        </section>

        <section className="rounded-lg border border-white/10 bg-[#121822] p-5 lg:col-span-5">
          <h2 className="mb-1 font-display text-xl font-bold text-white">
            Tiềm năng cầu thủ trẻ (U23)
          </h2>
          <p className="mb-4 text-xs text-slate-400">
            Cầu thủ trẻ có tiềm năng PA cao sẽ tăng OVR qua các tuần tập luyện cường độ phù hợp
          </p>

          <div className="divide-y divide-white/5 text-xs tabular-nums">
            {youthProspects.length === 0 ? (
              <p className="py-4 text-slate-400">Không có cầu thủ U23 nào trong đội một.</p>
            ) : (
              youthProspects.map((p) => (
                <div key={p.id} className="flex items-center justify-between py-2.5">
                  <div>
                    <div className="font-semibold text-white">{p.name}</div>
                    <div className="text-[11px] text-slate-400">
                      {p.primaryPosition} · {p.age} tuổi · Cảm giác bóng {p.sharpness}%
                    </div>
                  </div>
                  <div className="text-right font-mono">
                    <span className="font-bold text-emerald-400">OVR {p.ovr}</span>
                    <div className="text-[11px] text-slate-500">Thể lực {p.condition}%</div>
                  </div>
                </div>
              ))
            )}
          </div>
        </section>
      </div>
    </div>
  );
};

interface BoardFinanceViewProps {
  career: CareerState;
  onShiftBudget: (deltaMillions: number) => void;
}

export const BoardFinanceView: React.FC<BoardFinanceViewProps> = ({ career, onShiftBudget }) => {
  const club = career.clubs[career.userClubId];
  const squad = Object.values(career.players).filter((p) => p.clubId === club.id);
  const currentWeeklyWages = squad.reduce((sum, p) => sum + p.weeklyWage, 0);

  return (
    <div className="mx-auto max-w-[1320px] space-y-6">
      <div>
        <h1 className="font-display text-3xl font-bold text-white">Ban Lãnh Đạo & Tài Chính</h1>
        <p className="text-xs text-slate-400">
          Quản lý cân đối ngân sách chuyển nhượng, quỹ lương và đánh giá của Hội đồng quản trị
        </p>
      </div>

      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        <section className="space-y-4 rounded-lg border border-white/10 bg-[#121822] p-5 tabular-nums">
          <h2 className="font-display text-xl font-bold text-white">Tài chính câu lạc bộ</h2>
          <div className="grid grid-cols-2 gap-4 rounded-md bg-[#0B0F17] p-4 text-xs">
            <div>
              <div className="text-slate-400">Số dư tiền mặt</div>
              <div className="mt-1 font-mono text-2xl font-bold text-white">
                €{club.finances.balance.toFixed(1)}M
              </div>
            </div>
            <div>
              <div className="text-slate-400">Ngân sách chuyển nhượng</div>
              <div className="mt-1 font-mono text-2xl font-bold text-emerald-400">
                €{club.finances.transferBudget.toFixed(1)}M
              </div>
            </div>
            <div>
              <div className="text-slate-400">Quỹ lương đang dùng / Trần</div>
              <div className="mt-1 font-mono text-base font-semibold text-white">
                €{currentWeeklyWages}k / €{club.finances.wageBudgetWeekly}k / tuần
              </div>
            </div>
            <div>
              <div className="text-slate-400">Doanh thu vé & tài trợ / tháng</div>
              <div className="mt-1 font-mono text-base font-semibold text-sky-300">
                +€{(club.finances.monthlyIncomeMatchday + club.finances.monthlyIncomeSponsor).toFixed(1)}M
              </div>
            </div>
          </div>

          <div className="border-t border-white/10 pt-4">
            <div className="mb-2 text-xs font-semibold text-slate-300">
              Điều chuyển ngân sách (Chuyển nhượng ↔ Quỹ lương)
            </div>
            <div className="flex flex-wrap gap-2">
              <button
                type="button"
                disabled={club.finances.transferBudget < 5}
                onClick={() => onShiftBudget(-5)}
                className="rounded border border-white/15 bg-[#0B0F17] px-3 py-2 text-xs font-semibold text-white hover:bg-white/5 disabled:opacity-40"
              >
                Chuyển €5M sang Quỹ lương (+€100k/tuần)
              </button>
              <button
                type="button"
                disabled={club.finances.wageBudgetWeekly < 300}
                onClick={() => onShiftBudget(5)}
                className="rounded border border-white/15 bg-[#0B0F17] px-3 py-2 text-xs font-semibold text-white hover:bg-white/5 disabled:opacity-40"
              >
                Chuyển €100k/tuần sang Chuyển nhượng (+€5M)
              </button>
            </div>
          </div>
        </section>

        <section className="space-y-4 rounded-lg border border-white/10 bg-[#121822] p-5 tabular-nums">
          <h2 className="font-display text-xl font-bold text-white">Đánh giá Ban Lãnh Đạo</h2>

          <div className="space-y-4">
            <div>
              <div className="mb-1 flex justify-between text-xs">
                <span className="text-slate-300">Niềm tin Ban Lãnh Đạo</span>
                <span className="font-mono font-bold text-emerald-400">{club.finances.boardConfidence}%</span>
              </div>
              <div className="h-2.5 w-full overflow-hidden rounded bg-[#0B0F17]">
                <div
                  className="h-full bg-emerald-500 transition-all"
                  style={{ width: `${club.finances.boardConfidence}%` }}
                />
              </div>
            </div>

            <div>
              <div className="mb-1 flex justify-between text-xs">
                <span className="text-slate-300">Ủng hộ từ Cổ động viên</span>
                <span className="font-mono font-bold text-sky-400">{club.finances.fanConfidence}%</span>
              </div>
              <div className="h-2.5 w-full overflow-hidden rounded bg-[#0B0F17]">
                <div
                  className="h-full bg-sky-500 transition-all"
                  style={{ width: `${club.finances.fanConfidence}%` }}
                />
              </div>
            </div>
          </div>

          <div className="rounded-md bg-[#0B0F17] p-4 text-xs space-y-2">
            <div className="flex justify-between">
              <span className="text-slate-400">Mục tiêu giải VĐQG</span>
              <span className="font-semibold text-white">{club.expectation}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Thành tích mùa này</span>
              <span className="font-mono text-white">
                {career.history.playedMatches} trận ({career.history.wins}T - {career.history.draws}H - {career.history.losses}B)
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-400">Sân nhà</span>
              <span className="text-white">
                {club.stadium} ({club.capacity.toLocaleString('vi-VN')} chỗ)
              </span>
            </div>
          </div>
        </section>
      </div>
    </div>
  );
};
