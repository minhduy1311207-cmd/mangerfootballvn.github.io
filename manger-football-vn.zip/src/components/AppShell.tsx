import React, { useState } from 'react';
import {
  Mail,
  Users,
  Crosshair,
  Trophy,
  ArrowLeftRight,
  Dumbbell,
  Landmark,
  Volume2,
  VolumeX,
  RotateCcw,
  Menu,
  X,
  Calendar,
  Play,
} from 'lucide-react';
import {
  formatDateVN,
  getLeagueDef,
  getNextUserFixture,
  isUserSeasonFinished,
} from '../engine/schedule';
import { CareerState, WorkspaceTab } from '../types/fm';
import { ClubCrest } from './ClubCrest';
import { DonateQrWidget } from './DonateQrWidget';

interface AppShellProps {
  career: CareerState;
  activeTab: WorkspaceTab;
  onSelectTab: (tab: WorkspaceTab) => void;
  onContinueDay: () => void;
  onStartMatch: () => void;
  onOpenSeasonSummary: () => void;
  onResetCareer: () => void;
  muted: boolean;
  onToggleMute: () => void;
  children: React.ReactNode;
}

const NAV_ITEMS: { id: WorkspaceTab; label: string; icon: React.ComponentType<{ className?: string }> }[] = [
  { id: 'inbox', label: 'Hộp thư đến', icon: Mail },
  { id: 'squad', label: 'Đội hình', icon: Users },
  { id: 'tactics', label: 'Chiến thuật', icon: Crosshair },
  { id: 'competitions', label: 'Giải đấu & BXH', icon: Trophy },
  { id: 'transfers', label: 'Chuyển nhượng', icon: ArrowLeftRight },
  { id: 'training', label: 'Tập luyện', icon: Dumbbell },
  { id: 'board', label: 'Tài chính & BLĐ', icon: Landmark },
];

export const AppShell: React.FC<AppShellProps> = ({
  career,
  activeTab,
  onSelectTab,
  onContinueDay,
  onStartMatch,
  onOpenSeasonSummary,
  onResetCareer,
  muted,
  onToggleMute,
  children,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const club = career.clubs[career.userClubId];
  const league = getLeagueDef(career, career.activeLeagueId);
  const nextFixture = getNextUserFixture(career);
  const unreadCount = career.inbox.filter((m) => !m.read).length;

  const seasonFinished = isUserSeasonFinished(career);
  const isMatchDay = Boolean(nextFixture && nextFixture.dateISO <= career.currentDateISO);
  const oppClub = nextFixture
    ? career.clubs[
        nextFixture.homeClubId === club.id ? nextFixture.awayClubId : nextFixture.homeClubId
      ]
    : undefined;

  return (
    <div className="flex min-h-screen bg-[#0B0F17] text-slate-100">
      {/* Desktop Left Sidebar */}
      <aside className="hidden w-60 shrink-0 flex-col border-r border-white/10 bg-[#10151F] lg:flex">
        <div className="flex items-center gap-3 border-b border-white/10 px-4 py-4">
          <ClubCrest
            primaryColor={club.primaryColor}
            secondaryColor={club.secondaryColor}
            pattern={club.crestPattern}
            shortName={club.shortName}
            size={38}
          />
          <div className="min-w-0">
            <div className="truncate font-display text-lg font-bold tracking-tight text-white">
              {club.name}
            </div>
            <div className="truncate text-xs text-slate-400">
              {career.managerName} · {league.shortName}
            </div>
          </div>
        </div>

        <nav aria-label="Điều hướng chính" className="flex-1 space-y-1 p-3">
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            const active = activeTab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => onSelectTab(item.id)}
                className={`flex w-full items-center justify-between rounded-md px-3 py-2.5 text-sm font-medium transition-colors whitespace-nowrap ${
                  active
                    ? 'bg-emerald-600/18 text-emerald-400'
                    : 'text-slate-300 hover:bg-white/5 hover:text-white'
                }`}
              >
                <span className="flex items-center gap-2.5">
                  <Icon className="h-4 w-4 shrink-0" />
                  <span>{item.label}</span>
                </span>
                {item.id === 'inbox' && unreadCount > 0 && (
                  <span className="font-mono text-xs font-bold text-emerald-400 tabular-nums">
                    {unreadCount}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        <div className="border-t border-white/10 p-3 text-xs">
          <div className="mb-3 space-y-1.5 rounded-md bg-[#0B0F17] p-3 tabular-nums">
            <div className="flex justify-between text-slate-400">
              <span>Ngân sách CN</span>
              <span className="font-mono font-semibold text-white">
                €{club.finances.transferBudget.toFixed(1)}M
              </span>
            </div>
            <div className="flex justify-between text-slate-400">
              <span>Niềm tin BLĐ</span>
              <span className="font-mono font-semibold text-emerald-400">
                {club.finances.boardConfidence}%
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={onToggleMute}
              aria-label={muted ? 'Bật âm thanh' : 'Tắt âm thanh'}
              className="flex flex-1 items-center justify-center gap-1.5 rounded border border-white/10 px-2.5 py-2 text-slate-300 transition-colors hover:bg-white/5 hover:text-white"
            >
              {muted ? <VolumeX className="h-3.5 w-3.5" /> : <Volume2 className="h-3.5 w-3.5" />}
              <span>{muted ? 'Im lặng' : 'Âm thanh'}</span>
            </button>
            <button
              type="button"
              onClick={onResetCareer}
              aria-label="Thoát ra màn hình chính"
              className="flex items-center justify-center rounded border border-white/10 px-2.5 py-2 text-slate-400 transition-colors hover:border-rose-500/40 hover:text-rose-400"
              title="Đổi CLB / Sự nghiệp mới"
            >
              <RotateCcw className="h-3.5 w-3.5" />
            </button>
          </div>

          <div className="mt-2.5">
            <DonateQrWidget compact />
          </div>
        </div>
      </aside>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 flex lg:hidden">
          <div
            className="fixed inset-0 bg-black/70"
            onClick={() => setMobileMenuOpen(false)}
          />
          <aside className="relative z-10 flex w-64 flex-col bg-[#10151F] border-r border-white/10">
            <div className="flex items-center justify-between border-b border-white/10 px-4 py-4">
              <span className="font-display text-lg font-bold text-white">{club.name}</span>
              <button
                type="button"
                aria-label="Đóng menu"
                onClick={() => setMobileMenuOpen(false)}
                className="rounded p-1.5 text-slate-400 hover:text-white"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            <nav className="flex-1 space-y-1 p-3">
              {NAV_ITEMS.map((item) => {
                const Icon = item.icon;
                const active = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    type="button"
                    onClick={() => {
                      onSelectTab(item.id);
                      setMobileMenuOpen(false);
                    }}
                    className={`flex w-full items-center gap-2.5 rounded-md px-3 py-2.5 text-sm font-medium ${
                      active
                        ? 'bg-emerald-600/20 text-emerald-400'
                        : 'text-slate-300 hover:bg-white/5'
                    }`}
                  >
                    <Icon className="h-4 w-4 shrink-0" />
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </nav>
            <div className="space-y-2.5 border-t border-white/10 p-3">
              <DonateQrWidget compact />
              <button
                type="button"
                onClick={onResetCareer}
                className="flex w-full items-center justify-center gap-2 rounded border border-white/10 py-2 text-xs text-slate-300 hover:text-white"
              >
                <RotateCcw className="h-3.5 w-3.5" />
                <span>Đổi CLB / Sự nghiệp mới</span>
              </button>
            </div>
          </aside>
        </div>
      )}

      {/* Main Content Area */}
      <div className="flex min-w-0 flex-1 flex-col">
        {/* Top Bar: 3 clean zones */}
        <header className="flex items-center justify-between gap-4 border-b border-white/10 bg-[#121822] px-4 py-3 lg:px-6">
          <div className="flex min-w-0 items-center gap-3">
            <button
              type="button"
              aria-label="Mở menu điều hướng"
              onClick={() => setMobileMenuOpen(true)}
              className="rounded p-2 text-slate-300 hover:bg-white/5 lg:hidden"
            >
              <Menu className="h-5 w-5" />
            </button>
            <div className="flex items-center gap-2 text-sm text-slate-300 tabular-nums">
              <Calendar className="h-4 w-4 text-emerald-400 shrink-0" />
              <span className="font-mono font-semibold text-white whitespace-nowrap">
                {formatDateVN(career.currentDateISO)}
              </span>
              <span className="hidden text-slate-500 sm:inline">·</span>
              <span className="hidden truncate text-xs text-slate-400 sm:inline">
                {league.name} · Mùa {career.seasonNumber}
              </span>
            </div>
          </div>

          <div className="hidden min-w-0 items-center gap-2 text-xs text-slate-300 md:flex">
            {nextFixture && oppClub ? (
              <span className="truncate">
                Trận kế: Vòng {nextFixture.round} vs{' '}
                <strong className="text-white">{oppClub.name}</strong> (
                {nextFixture.homeClubId === club.id ? 'Sân nhà' : 'Sân khách'} ·{' '}
                {formatDateVN(nextFixture.dateISO)})
              </span>
            ) : (
              <span>Mùa giải đã khép lại</span>
            )}
          </div>

          <div className="shrink-0">
            {seasonFinished ? (
              <button
                type="button"
                onClick={onOpenSeasonSummary}
                className="flex items-center gap-2 rounded-md bg-amber-500 px-4 py-2 text-sm font-bold text-slate-950 transition-colors hover:bg-amber-400 whitespace-nowrap"
              >
                <Trophy className="h-4 w-4" />
                <span>Tổng kết mùa giải</span>
              </button>
            ) : isMatchDay && nextFixture ? (
              <button
                type="button"
                onClick={onStartMatch}
                className="flex items-center gap-2 rounded-md bg-emerald-600 px-4 py-2 text-sm font-bold text-white transition-colors hover:bg-emerald-500 whitespace-nowrap"
              >
                <Play className="h-4 w-4 fill-current" />
                <span>Vào trận đấu</span>
              </button>
            ) : (
              <button
                type="button"
                onClick={onContinueDay}
                className="rounded-md bg-emerald-600 px-4 py-2 text-sm font-bold text-white transition-colors hover:bg-emerald-500 whitespace-nowrap"
              >
                Tiếp tục ngày
              </button>
            )}
          </div>
        </header>

        <main className="flex-1 overflow-y-auto p-4 lg:p-6">{children}</main>
      </div>
    </div>
  );
};
