import React, { useState } from 'react';
import {
  formatDateVN,
  getLeagueDef,
  getNextUserFixture,
  isUserSeasonFinished,
} from '../engine/schedule';
import { calculateTeamRatings } from '../engine/tactics';
import { CareerState, WorkspaceTab } from '../types/fm';
import { ClubCrest } from './ClubCrest';

interface InboxViewProps {
  career: CareerState;
  onMarkRead: (msgId: string) => void;
  onMarkAllRead: () => void;
  onNavigateTab: (tab: WorkspaceTab) => void;
  onStartMatch: () => void;
  onContinueToMatch: () => void;
  onOpenSeasonSummary: () => void;
}

export const InboxView: React.FC<InboxViewProps> = ({
  career,
  onMarkRead,
  onMarkAllRead,
  onNavigateTab,
  onStartMatch,
  onContinueToMatch,
  onOpenSeasonSummary,
}) => {
  const [selectedId, setSelectedId] = useState<string>(career.inbox[0]?.id ?? '');
  const selectedMsg = career.inbox.find((m) => m.id === selectedId) ?? career.inbox[0];

  const userClub = career.clubs[career.userClubId];
  const league = getLeagueDef(career, career.activeLeagueId);
  const standings = career.standingsByLeague[career.activeLeagueId] ?? [];
  const userRank = standings.findIndex((r) => r.clubId === userClub.id) + 1;
  const userRow = standings.find((r) => r.clubId === userClub.id);
  const nextFixture = getNextUserFixture(career);
  const seasonFinished = isUserSeasonFinished(career);
  const oppClub = nextFixture
    ? career.clubs[
        nextFixture.homeClubId === userClub.id ? nextFixture.awayClubId : nextFixture.homeClubId
      ]
    : undefined;

  const userRatings = calculateTeamRatings(userClub, career.players);
  const oppRatings = oppClub ? calculateTeamRatings(oppClub, career.players) : null;
  const isMatchDay = Boolean(nextFixture && nextFixture.dateISO <= career.currentDateISO);

  return (
    <div className="mx-auto max-w-[1320px] space-y-6">
      {/* Top Overview KPI Strip */}
      <section className="grid grid-cols-2 gap-3 sm:grid-cols-4">
        <div className="rounded-lg border border-white/10 bg-[#121822] p-4 tabular-nums">
          <div className="text-xs text-slate-400">Vị trí · {league.shortName}</div>
          <div className="mt-1 font-display text-3xl font-bold text-white">
            #{userRank} <span className="text-sm font-normal text-slate-400">/ {standings.length}</span>
          </div>
          <div className="mt-0.5 text-xs text-slate-400">
            {userRow?.points ?? 0} điểm · {userRow?.won ?? 0}T {userRow?.drawn ?? 0}H {userRow?.lost ?? 0}B
          </div>
        </div>

        <div className="rounded-lg border border-white/10 bg-[#121822] p-4 tabular-nums">
          <div className="text-xs text-slate-400">Sức mạnh đội hình</div>
          <div className="mt-1 font-display text-3xl font-bold text-emerald-400">
            {userRatings.overall} <span className="text-sm font-normal text-slate-400">OVR</span>
          </div>
          <div className="mt-0.5 text-xs text-slate-400">
            Công {userRatings.attack} · Giữa {userRatings.midfield} · Thủ {userRatings.defense}
          </div>
        </div>

        <div className="rounded-lg border border-white/10 bg-[#121822] p-4 tabular-nums">
          <div className="text-xs text-slate-400">Ngân sách chuyển nhượng</div>
          <div className="mt-1 font-display text-3xl font-bold text-white">
            €{userClub.finances.transferBudget.toFixed(1)}M
          </div>
          <div className="mt-0.5 text-xs text-slate-400">
            Số dư CLB: €{userClub.finances.balance.toFixed(1)}M
          </div>
        </div>

        <div className="rounded-lg border border-white/10 bg-[#121822] p-4 tabular-nums">
          <div className="text-xs text-slate-400">Tín nhiệm Ban lãnh đạo</div>
          <div className="mt-1 font-display text-3xl font-bold text-white">
            {userClub.finances.boardConfidence}%
          </div>
          <div className="mt-0.5 truncate text-xs text-slate-400">
            Mục tiêu: {userClub.expectation}
          </div>
        </div>
      </section>

      {/* Main Split: Inbox List + Message Reader & Next Match Briefing */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
        {/* Inbox Message List */}
        <section className="flex flex-col rounded-lg border border-white/10 bg-[#121822] lg:col-span-5">
          <div className="flex items-center justify-between border-b border-white/10 px-4 py-3">
            <h2 className="font-display text-xl font-bold text-white">Hộp thư đến</h2>
            <button
              type="button"
              onClick={onMarkAllRead}
              className="text-xs font-medium text-emerald-400 hover:text-emerald-300"
            >
              Đánh dấu đã đọc tất cả
            </button>
          </div>

          <div className="max-h-[460px] divide-y divide-white/5 overflow-y-auto">
            {career.inbox.length === 0 ? (
              <div className="p-6 text-center text-sm text-slate-400">Hộp thư hiện đang trống.</div>
            ) : (
              career.inbox.map((msg) => {
                const isSelected = selectedMsg?.id === msg.id;
                return (
                  <button
                    key={msg.id}
                    type="button"
                    onClick={() => {
                      setSelectedId(msg.id);
                      if (!msg.read) onMarkRead(msg.id);
                    }}
                    className={`flex w-full flex-col gap-1 px-4 py-3 text-left transition-colors ${
                      isSelected ? 'bg-emerald-500/12' : 'hover:bg-white/5'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2 text-xs text-slate-400">
                      <span>{msg.category} · {msg.sender}</span>
                      <span className="font-mono tabular-nums">{formatDateVN(msg.dateISO)}</span>
                    </div>
                    <div
                      className={`truncate text-sm ${
                        msg.read ? 'font-medium text-slate-300' : 'font-bold text-white'
                      }`}
                    >
                      {msg.subject}
                    </div>
                  </button>
                );
              })
            )}
          </div>
        </section>

        {/* Right Column: Message Detail + Next Match Preview */}
        <div className="space-y-6 lg:col-span-7">
          {selectedMsg && (
            <section className="rounded-lg border border-white/10 bg-[#121822] p-5">
              <div className="mb-3 flex flex-wrap items-center justify-between gap-2 border-b border-white/10 pb-3 text-xs text-slate-400">
                <span>
                  Từ: <strong className="text-slate-200">{selectedMsg.sender}</strong> · {selectedMsg.category}
                </span>
                <span className="font-mono tabular-nums">{formatDateVN(selectedMsg.dateISO)}</span>
              </div>
              <h3 className="font-display text-2xl font-bold text-white">{selectedMsg.subject}</h3>
              <p className="mt-3 text-sm leading-relaxed text-slate-300">{selectedMsg.body}</p>
              <div className="mt-5 flex flex-wrap gap-2.5">
                <button
                  type="button"
                  onClick={() => onNavigateTab('tactics')}
                  className="rounded-md border border-white/15 px-3.5 py-2 text-xs font-semibold text-white transition-colors hover:bg-white/5"
                >
                  Kiểm tra chiến thuật
                </button>
                <button
                  type="button"
                  onClick={() => onNavigateTab('squad')}
                  className="rounded-md border border-white/15 px-3.5 py-2 text-xs font-semibold text-white transition-colors hover:bg-white/5"
                >
                  Xem đội hình & Thể lực
                </button>
              </div>
            </section>
          )}

          {seasonFinished ? (
            <section className="rounded-lg border border-amber-500/35 bg-[#121822] p-5">
              <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                <div>
                  <h3 className="font-display text-xl font-bold text-white">
                    Mùa giải {career.seasonNumber} đã khép lại
                  </h3>
                  <p className="text-xs text-slate-400">
                    {league.name} · Vị trí hiện tại #{userRank}/{standings.length} ({userRow?.points ?? 0} điểm)
                  </p>
                </div>
                <button
                  type="button"
                  onClick={onOpenSeasonSummary}
                  className="rounded-md bg-amber-500 px-4 py-2 text-xs font-bold text-slate-950 transition-colors hover:bg-amber-400 whitespace-nowrap"
                >
                  Tổng kết & Sang mùa mới
                </button>
              </div>
            </section>
          ) : nextFixture && oppClub && oppRatings ? (
            <section className="rounded-lg border border-white/10 bg-[#121822] p-5">
              <div className="mb-4 flex items-center justify-between">
                <div>
                  <h3 className="font-display text-xl font-bold text-white">
                    Trận đấu tiếp theo · Vòng {nextFixture.round}
                  </h3>
                  <p className="text-xs text-slate-400">
                    {formatDateVN(nextFixture.dateISO)} ·{' '}
                    {nextFixture.homeClubId === userClub.id
                      ? `Sân nhà ${userClub.stadium}`
                      : `Sân khách ${oppClub.stadium}`}
                  </p>
                </div>
                {isMatchDay ? (
                  <button
                    type="button"
                    onClick={onStartMatch}
                    className="rounded-md bg-emerald-600 px-4 py-2 text-xs font-bold text-white transition-colors hover:bg-emerald-500"
                  >
                    Đá ngay
                  </button>
                ) : (
                  <button
                    type="button"
                    onClick={onContinueToMatch}
                    className="rounded-md border border-emerald-500/40 bg-emerald-500/10 px-4 py-2 text-xs font-bold text-emerald-300 transition-colors hover:bg-emerald-500/20"
                  >
                    Tới ngày thi đấu
                  </button>
                )}
              </div>

              <div className="grid grid-cols-3 items-center gap-4 rounded-md bg-[#0B0F17] p-4">
                <div className="flex flex-col items-center text-center">
                  <ClubCrest
                    primaryColor={userClub.primaryColor}
                    secondaryColor={userClub.secondaryColor}
                    pattern={userClub.crestPattern}
                    shortName={userClub.shortName}
                    size={44}
                  />
                  <div className="mt-2 text-sm font-bold text-white">{userClub.name}</div>
                  <div className="text-xs text-slate-400">
                    {userClub.tactics.formation} · OVR {userRatings.overall}
                  </div>
                </div>

                <div className="text-center">
                  <div className="font-display text-2xl font-bold text-slate-400">VS</div>
                  <div className="mt-1 text-xs text-slate-500">
                    Độ ăn ý: {userRatings.tacticalFit}%
                  </div>
                </div>

                <div className="flex flex-col items-center text-center">
                  <ClubCrest
                    primaryColor={oppClub.primaryColor}
                    secondaryColor={oppClub.secondaryColor}
                    pattern={oppClub.crestPattern}
                    shortName={oppClub.shortName}
                    size={44}
                  />
                  <div className="mt-2 text-sm font-bold text-white">{oppClub.name}</div>
                  <div className="text-xs text-slate-400">
                    {oppClub.tactics.formation} · OVR {oppRatings.overall}
                  </div>
                </div>
              </div>
            </section>
          ) : null}
        </div>
      </div>
    </div>
  );
};
