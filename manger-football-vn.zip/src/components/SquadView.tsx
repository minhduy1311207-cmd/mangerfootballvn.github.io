import React, { useMemo, useState } from 'react';
import { X } from 'lucide-react';
import { CareerState, Player, Position } from '../types/fm';

interface SquadViewProps {
  career: CareerState;
  onToggleTransferList: (playerId: string) => void;
  onRenewContract: (playerId: string, newWage: number, extraYears: number) => void;
}

type PosFilter = 'ALL' | 'GK' | 'DEF' | 'MID' | 'FWD';
type SortKey = 'ovr' | 'condition' | 'age' | 'value' | 'goals';

function getPosGroup(pos: Position): Exclude<PosFilter, 'ALL'> {
  if (pos === 'GK') return 'GK';
  if (pos === 'LB' || pos === 'CB' || pos === 'RB') return 'DEF';
  if (pos === 'DM' || pos === 'CM' || pos === 'AM') return 'MID';
  return 'FWD';
}

function attrColor(val: number): string {
  if (val >= 16) return 'text-emerald-400 font-bold';
  if (val >= 12) return 'text-sky-300 font-semibold';
  return 'text-slate-400';
}

export const SquadView: React.FC<SquadViewProps> = ({
  career,
  onToggleTransferList,
  onRenewContract,
}) => {
  const [filter, setFilter] = useState<PosFilter>('ALL');
  const [sortBy, setSortBy] = useState<SortKey>('ovr');
  const [selectedPlayerId, setSelectedPlayerId] = useState<string | null>(null);
  const [renewFeedback, setRenewFeedback] = useState<string | null>(null);

  const club = career.clubs[career.userClubId];
  const squadPlayers = useMemo(() => {
    const all = Object.values(career.players).filter((p) => p.clubId === career.userClubId);
    const filtered = filter === 'ALL' ? all : all.filter((p) => getPosGroup(p.primaryPosition) === filter);
    return filtered.sort((a, b) => {
      if (sortBy === 'ovr') return b.ovr - a.ovr;
      if (sortBy === 'condition') return b.condition - a.condition;
      if (sortBy === 'age') return a.age - b.age;
      if (sortBy === 'value') return b.marketValue - a.marketValue;
      return b.stats.goals - a.stats.goals;
    });
  }, [career.players, career.userClubId, filter, sortBy]);

  const selectedPlayer: Player | undefined = selectedPlayerId
    ? career.players[selectedPlayerId]
    : undefined;

  const starterSet = new Set(club.tactics.lineupIds.filter(Boolean));
  const benchSet = new Set(club.tactics.benchIds);

  const handleRenew = (p: Player) => {
    const newWage = Math.round(p.weeklyWage * 1.15);
    onRenewContract(p.id, newWage, 3);
    setRenewFeedback(`Đã gia hạn hợp đồng với ${p.name} tới năm ${p.contractUntilYear + 3} (€${newWage}k/tuần).`);
  };

  return (
    <div className="mx-auto max-w-[1320px] space-y-5">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="font-display text-3xl font-bold text-white">Đội Hình {club.name}</h1>
          <p className="text-xs text-slate-400">
            {squadPlayers.length} cầu thủ hiển thị · Nhấn vào tên cầu thủ để xem ma trận chỉ số 1–20 và hợp đồng
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <div className="flex items-center gap-1 rounded-md bg-[#121822] p-1 border border-white/10">
            {(
              [
                ['ALL', 'Tất cả'],
                ['GK', 'Thủ môn'],
                ['DEF', 'Hậu vệ'],
                ['MID', 'Tiền vệ'],
                ['FWD', 'Tiền đạo'],
              ] as const
            ).map(([key, label]) => (
              <button
                key={key}
                type="button"
                onClick={() => setFilter(key)}
                className={`rounded px-2.5 py-1 text-xs font-semibold transition-colors whitespace-nowrap ${
                  filter === key ? 'bg-emerald-600 text-white' : 'text-slate-400 hover:text-white'
                }`}
              >
                {label}
              </button>
            ))}
          </div>

          <select
            aria-label="Sắp xếp cầu thủ"
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as SortKey)}
            className="rounded-md border border-white/10 bg-[#121822] px-3 py-1.5 text-xs text-white focus:border-emerald-500 focus:outline-none"
          >
            <option value="ovr">Sắp xếp: OVR cao nhất</option>
            <option value="condition">Sắp xếp: Thể lực</option>
            <option value="value">Sắp xếp: Giá trị</option>
            <option value="age">Sắp xếp: Tuổi trẻ nhất</option>
            <option value="goals">Sắp xếp: Bàn thắng</option>
          </select>
        </div>
      </div>

      {/* Squad Table */}
      <div className="overflow-x-auto rounded-lg border border-white/10 bg-[#121822]">
        <table className="w-full border-collapse text-left text-xs">
          <thead>
            <tr className="border-b border-white/10 bg-[#0F141D] text-slate-400">
              <th className="px-3 py-2.5 font-semibold">Số</th>
              <th className="px-3 py-2.5 font-semibold">Cầu thủ</th>
              <th className="px-3 py-2.5 font-semibold">Vị trí</th>
              <th className="px-3 py-2.5 font-semibold">Vai trò</th>
              <th className="px-3 py-2.5 text-right font-semibold">Tuổi</th>
              <th className="px-3 py-2.5 text-right font-semibold">OVR</th>
              <th className="px-3 py-2.5 text-right font-semibold">Thể lực</th>
              <th className="px-3 py-2.5 text-right font-semibold">Tinh thần</th>
              <th className="px-3 py-2.5 text-right font-semibold">Lương/tuần</th>
              <th className="px-3 py-2.5 text-right font-semibold">Giá trị</th>
              <th className="px-3 py-2.5 text-right font-semibold">Trận · Bàn · KT</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-white/5 tabular-nums">
            {squadPlayers.map((p) => {
              const statusLabel = starterSet.has(p.id)
                ? 'Đá chính'
                : benchSet.has(p.id)
                ? 'Dự bị'
                : 'Đội B';
              return (
                <tr
                  key={p.id}
                  className="transition-colors hover:bg-white/[0.04]"
                >
                  <td className="px-3 py-2.5 font-mono text-slate-400">{p.shirtNumber}</td>
                  <td className="px-3 py-2.5">
                    <button
                      type="button"
                      onClick={() => {
                        setSelectedPlayerId(p.id);
                        setRenewFeedback(null);
                      }}
                      className="text-left font-semibold text-white hover:text-emerald-400"
                    >
                      {p.name}
                    </button>
                    <div className="text-[11px] text-slate-500">
                      {p.nationality} · {statusLabel}
                      {p.transferListed ? ' · Đang rao bán' : ''}
                    </div>
                  </td>
                  <td className="px-3 py-2.5 font-mono font-semibold text-slate-200">
                    {p.primaryPosition}
                    {p.secondaryPositions.length > 0 && (
                      <span className="ml-1 font-sans text-[11px] font-normal text-slate-500">
                        /{p.secondaryPositions.join(',')}
                      </span>
                    )}
                  </td>
                  <td className="px-3 py-2.5 text-slate-300">{p.squadRole}</td>
                  <td className="px-3 py-2.5 text-right font-mono text-slate-300">{p.age}</td>
                  <td className="px-3 py-2.5 text-right font-mono font-bold text-emerald-400">
                    {p.ovr}
                  </td>
                  <td className="px-3 py-2.5 text-right">
                    <span
                      className={`font-mono font-semibold ${
                        p.condition >= 85
                          ? 'text-emerald-400'
                          : p.condition >= 70
                          ? 'text-amber-400'
                          : 'text-rose-400'
                      }`}
                    >
                      {p.condition}%
                    </span>
                  </td>
                  <td className="px-3 py-2.5 text-right font-mono text-slate-300">{p.morale}%</td>
                  <td className="px-3 py-2.5 text-right font-mono text-slate-300">€{p.weeklyWage}k</td>
                  <td className="px-3 py-2.5 text-right font-mono text-white">€{p.marketValue.toFixed(1)}M</td>
                  <td className="px-3 py-2.5 text-right font-mono text-slate-300">
                    {p.stats.appearances} · {p.stats.goals} · {p.stats.assists}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {/* Player Profile Modal (FM 1-20 Attribute Matrix) */}
      {selectedPlayer && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4"
          role="dialog"
          aria-modal="true"
          aria-label={`Hồ sơ ${selectedPlayer.name}`}
        >
          <div className="max-h-[90vh] w-full max-w-3xl overflow-y-auto rounded-lg border border-white/15 bg-[#121822] p-6">
            <div className="flex items-start justify-between gap-4 border-b border-white/10 pb-4">
              <div>
                <div className="text-xs text-slate-400">
                  #{selectedPlayer.shirtNumber} · {selectedPlayer.primaryPosition} · {selectedPlayer.nationality} · {selectedPlayer.age} tuổi · {selectedPlayer.heightCm} cm · Chân {selectedPlayer.foot}
                </div>
                <h2 className="mt-1 font-display text-3xl font-bold text-white">
                  {selectedPlayer.name}
                </h2>
              </div>
              <div className="flex items-center gap-4">
                <div className="text-right tabular-nums">
                  <div className="text-xs text-slate-400">Đánh giá OVR</div>
                  <div className="font-mono text-2xl font-bold text-emerald-400">
                    {selectedPlayer.ovr}
                  </div>
                </div>
                <button
                  type="button"
                  aria-label="Đóng hồ sơ cầu thủ"
                  onClick={() => setSelectedPlayerId(null)}
                  className="rounded p-1.5 text-slate-400 hover:bg-white/5 hover:text-white"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>
            </div>

            {/* 3-Column FM Attribute Matrix */}
            <div className="mt-5 grid grid-cols-1 gap-5 sm:grid-cols-3 tabular-nums">
              <div className="rounded-md bg-[#0B0F17] p-4">
                <h3 className="mb-3 text-xs font-bold uppercase tracking-wider text-slate-400">
                  {selectedPlayer.primaryPosition === 'GK' ? 'Thủ môn' : 'Kỹ thuật'}
                </h3>
                <div className="space-y-1.5 text-xs">
                  {selectedPlayer.primaryPosition === 'GK' ? (
                    <>
                      <AttrRow label="Phản xạ" value={selectedPlayer.attributes.reflexes} />
                      <AttrRow label="Bắt bóng" value={selectedPlayer.attributes.handling} />
                      <AttrRow label="1 đối 1" value={selectedPlayer.attributes.oneOnOnes} />
                      <AttrRow label="Không chiến" value={selectedPlayer.attributes.aerialReach} />
                      <AttrRow label="Chuyền bóng" value={selectedPlayer.attributes.passing} />
                      <AttrRow label="Chạm bóng" value={selectedPlayer.attributes.firstTouch} />
                    </>
                  ) : (
                    <>
                      <AttrRow label="Dứt điểm" value={selectedPlayer.attributes.finishing} />
                      <AttrRow label="Chuyền bóng" value={selectedPlayer.attributes.passing} />
                      <AttrRow label="Rê bóng" value={selectedPlayer.attributes.dribbling} />
                      <AttrRow label="Đỡ bước một" value={selectedPlayer.attributes.firstTouch} />
                      <AttrRow label="Kỹ thuật" value={selectedPlayer.attributes.technique} />
                      <AttrRow label="Tạt bóng" value={selectedPlayer.attributes.crossing} />
                      <AttrRow label="Sút xa" value={selectedPlayer.attributes.longShots} />
                      <AttrRow label="Xoạc bóng" value={selectedPlayer.attributes.tackling} />
                      <AttrRow label="Kèm người" value={selectedPlayer.attributes.marking} />
                      <AttrRow label="Đánh đầu" value={selectedPlayer.attributes.heading} />
                    </>
                  )}
                </div>
              </div>

              <div className="rounded-md bg-[#0B0F17] p-4">
                <h3 className="mb-3 text-xs font-bold uppercase tracking-wider text-slate-400">
                  Tinh thần
                </h3>
                <div className="space-y-1.5 text-xs">
                  <AttrRow label="Tầm nhìn" value={selectedPlayer.attributes.vision} />
                  <AttrRow label="Quyết định" value={selectedPlayer.attributes.decisions} />
                  <AttrRow label="Bình tĩnh" value={selectedPlayer.attributes.composure} />
                  <AttrRow label="Chọn vị trí" value={selectedPlayer.attributes.positioning} />
                  <AttrRow label="Chạy chỗ" value={selectedPlayer.attributes.offTheBall} />
                  <AttrRow label="Nhiệt huyết" value={selectedPlayer.attributes.workRate} />
                  <AttrRow label="Quyết tâm" value={selectedPlayer.attributes.determination} />
                  <AttrRow label="Lãnh đạo" value={selectedPlayer.attributes.leadership} />
                </div>
              </div>

              <div className="rounded-md bg-[#0B0F17] p-4">
                <h3 className="mb-3 text-xs font-bold uppercase tracking-wider text-slate-400">
                  Thể chất & Hợp đồng
                </h3>
                <div className="space-y-1.5 text-xs">
                  <AttrRow label="Tốc độ" value={selectedPlayer.attributes.pace} />
                  <AttrRow label="Tăng tốc" value={selectedPlayer.attributes.acceleration} />
                  <AttrRow label="Thể lực" value={selectedPlayer.attributes.stamina} />
                  <AttrRow label="Sức mạnh" value={selectedPlayer.attributes.strength} />
                  <AttrRow label="Khéo léo" value={selectedPlayer.attributes.agility} />
                </div>
                <div className="mt-4 space-y-1.5 border-t border-white/10 pt-3 text-xs">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Lương tuần</span>
                    <span className="font-mono text-white">€{selectedPlayer.weeklyWage}k</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Hạn HĐ</span>
                    <span className="font-mono text-white">{selectedPlayer.contractUntilYear}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Giá trị</span>
                    <span className="font-mono text-emerald-400">€{selectedPlayer.marketValue.toFixed(1)}M</span>
                  </div>
                </div>
              </div>
            </div>

            {renewFeedback && (
              <p className="mt-4 text-xs font-medium text-emerald-400">{renewFeedback}</p>
            )}

            <div className="mt-5 flex flex-wrap items-center justify-end gap-3 border-t border-white/10 pt-4">
              <button
                type="button"
                onClick={() => onToggleTransferList(selectedPlayer.id)}
                className="rounded-md border border-white/15 px-4 py-2 text-xs font-semibold text-white transition-colors hover:bg-white/5"
              >
                {selectedPlayer.transferListed ? 'Gỡ khỏi danh sách bán' : 'Đưa vào danh sách chuyển nhượng'}
              </button>
              <button
                type="button"
                onClick={() => handleRenew(selectedPlayer)}
                className="rounded-md bg-emerald-600 px-4 py-2 text-xs font-bold text-white transition-colors hover:bg-emerald-500"
              >
                Gia hạn hợp đồng (+3 năm)
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

const AttrRow: React.FC<{ label: string; value: number }> = ({ label, value }) => (
  <div className="flex items-center justify-between">
    <span className="text-slate-300">{label}</span>
    <span className={`font-mono ${attrColor(value)}`}>{value}</span>
  </div>
);
