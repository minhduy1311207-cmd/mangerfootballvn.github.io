import React from 'react';
import { ArrowDownRight, ArrowUpRight, Award, Trophy, X } from 'lucide-react';
import { SeasonSummaryPreview } from '../engine/schedule';

interface SeasonSummaryModalProps {
  preview: SeasonSummaryPreview;
  clubName: string;
  onClose: () => void;
  onAdvanceSeason: () => void;
}

export const SeasonSummaryModal: React.FC<SeasonSummaryModalProps> = ({
  preview,
  clubName,
  onClose,
  onAdvanceSeason,
}) => {
  const promoted = preview.movements.filter((m) => m.type === 'promoted');
  const relegated = preview.movements.filter((m) => m.type === 'relegated');

  const outcomeTitle =
    preview.outcome === 'champion'
      ? preview.nextLeagueId !== preview.leagueId
        ? `Vô địch ${preview.leagueName} & Thăng hạng!`
        : `Vô địch ${preview.leagueName}!`
      : preview.outcome === 'promoted'
      ? `Thăng hạng lên ${preview.nextLeagueName}!`
      : preview.outcome === 'relegated'
      ? `Xuống hạng ${preview.nextLeagueName}`
      : `Hoàn thành mùa giải tại ${preview.leagueName}`;

  const outcomeColor =
    preview.outcome === 'champion'
      ? 'border-amber-500/40 bg-amber-500/10 text-amber-300'
      : preview.outcome === 'promoted'
      ? 'border-emerald-500/40 bg-emerald-500/10 text-emerald-300'
      : preview.outcome === 'relegated'
      ? 'border-rose-500/40 bg-rose-500/10 text-rose-300'
      : 'border-white/10 bg-[#0B0F17] text-slate-200';

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4"
      role="dialog"
      aria-modal="true"
      aria-label={`Tổng kết mùa giải ${preview.seasonNumber}`}
    >
      <div className="max-h-[90vh] w-full max-w-2xl overflow-y-auto rounded-lg border border-white/15 bg-[#121822] p-6">
        <div className="flex items-start justify-between gap-4 border-b border-white/10 pb-4">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-emerald-500/15 text-emerald-400">
              <Trophy className="h-5 w-5" />
            </div>
            <div>
              <h2 className="font-display text-2xl font-bold text-white">
                Tổng Kết Mùa Giải {preview.seasonNumber}
              </h2>
              <p className="text-xs text-slate-400">
                {clubName} · {preview.leagueName}
              </p>
            </div>
          </div>
          <button
            type="button"
            aria-label="Đóng tổng kết mùa giải"
            onClick={onClose}
            className="rounded p-1.5 text-slate-400 hover:bg-white/5 hover:text-white"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        {/* Outcome Banner */}
        <div className={`mt-4 rounded-lg border px-4 py-3 ${outcomeColor}`}>
          <div className="flex items-center gap-2 font-display text-xl font-bold">
            <Award className="h-5 w-5 shrink-0" />
            <span>{outcomeTitle}</span>
          </div>
          <p className="mt-1 text-xs opacity-90">
            Mùa giải tới ({preview.seasonNumber + 1}), {clubName} sẽ thi đấu tại{' '}
            <strong>{preview.nextLeagueName}</strong>.
          </p>
        </div>

        {/* Key Season Metrics */}
        <div className="mt-4 grid grid-cols-2 gap-3 sm:grid-cols-4 tabular-nums">
          <div className="rounded border border-white/10 bg-[#0B0F17] p-3">
            <div className="text-[11px] text-slate-400">Thứ hạng chung cuộc</div>
            <div className="mt-1 font-mono text-2xl font-bold text-white">
              #{preview.userPosition}
              <span className="text-xs font-normal text-slate-500">/{preview.totalTeams}</span>
            </div>
          </div>
          <div className="rounded border border-white/10 bg-[#0B0F17] p-3">
            <div className="text-[11px] text-slate-400">Điểm & Thành tích</div>
            <div className="mt-1 font-mono text-xl font-bold text-emerald-400">
              {preview.userRow.points} đ
            </div>
            <div className="text-[11px] text-slate-400">
              {preview.userRow.won}T · {preview.userRow.drawn}H · {preview.userRow.lost}B
            </div>
          </div>
          <div className="rounded border border-white/10 bg-[#0B0F17] p-3">
            <div className="text-[11px] text-slate-400">Tiền thưởng mùa</div>
            <div className="mt-1 font-mono text-2xl font-bold text-amber-400">
              +€{preview.prizeMoney.toFixed(1)}M
            </div>
          </div>
          <div className="rounded border border-white/10 bg-[#0B0F17] p-3">
            <div className="text-[11px] text-slate-400">Vô địch giải</div>
            <div className="mt-1 truncate text-sm font-bold text-white">
              {preview.championClubName}
            </div>
            {preview.topScorerName && (
              <div className="mt-0.5 truncate text-[11px] text-slate-400">
                VPL: {preview.topScorerName} ({preview.topScorerGoals})
              </div>
            )}
          </div>
        </div>

        {/* Promotion & Relegation Movements */}
        {preview.movements.length > 0 && (
          <div className="mt-5 grid grid-cols-1 gap-4 sm:grid-cols-2">
            <div className="rounded-lg border border-white/10 bg-[#0B0F17] p-3.5">
              <h3 className="mb-2 flex items-center gap-1.5 text-xs font-bold text-emerald-400">
                <ArrowUpRight className="h-4 w-4" />
                <span>Các đội Thăng hạng</span>
              </h3>
              <ul className="space-y-1.5 text-xs">
                {promoted.map((m) => (
                  <li key={`pro_${m.clubId}`} className="flex items-center justify-between gap-2">
                    <span className="truncate font-semibold text-white">{m.clubName}</span>
                    <span className="shrink-0 text-[11px] text-emerald-400">
                      → {m.toLeagueName}
                    </span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="rounded-lg border border-white/10 bg-[#0B0F17] p-3.5">
              <h3 className="mb-2 flex items-center gap-1.5 text-xs font-bold text-rose-400">
                <ArrowDownRight className="h-4 w-4" />
                <span>Các đội Xuống hạng</span>
              </h3>
              <ul className="space-y-1.5 text-xs">
                {relegated.map((m) => (
                  <li key={`rel_${m.clubId}`} className="flex items-center justify-between gap-2">
                    <span className="truncate font-semibold text-white">{m.clubName}</span>
                    <span className="shrink-0 text-[11px] text-rose-400">
                      → {m.toLeagueName}
                    </span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        )}

        <div className="mt-6 flex items-center justify-end gap-3 border-t border-white/10 pt-4">
          <button
            type="button"
            onClick={onClose}
            className="rounded-md border border-white/15 px-4 py-2 text-xs font-semibold text-slate-300 hover:bg-white/5"
          >
            Xem lại BXH
          </button>
          <button
            type="button"
            onClick={onAdvanceSeason}
            className="rounded-md bg-emerald-600 px-5 py-2.5 text-sm font-bold text-white transition-colors hover:bg-emerald-500"
          >
            Bước vào Mùa Giải {preview.seasonNumber + 1}
          </button>
        </div>
      </div>
    </div>
  );
};
