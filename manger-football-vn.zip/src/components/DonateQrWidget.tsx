import React, { useState } from 'react';
import { Heart, X, ZoomIn } from 'lucide-react';

interface DonateQrWidgetProps {
  compact?: boolean;
}

const QR_SRC = `${import.meta.env.BASE_URL}assets/aistudio/image_37d458fc.png`;

export const DonateQrWidget: React.FC<DonateQrWidgetProps> = ({ compact = false }) => {
  const [open, setOpen] = useState(false);

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(true)}
        aria-label="Mở mã QR donate ủng hộ phát triển thêm"
        className={`group flex w-full items-center gap-2.5 rounded-md border border-white/10 bg-[#0B0F17]/90 text-left transition-colors hover:border-emerald-500/40 hover:bg-[#101723] ${
          compact ? 'px-2.5 py-2' : 'px-3.5 py-2.5'
        }`}
      >
        <div
          className={`shrink-0 overflow-hidden rounded bg-[#EAF4EE] ${
            compact ? 'h-14 w-9' : 'h-16 w-10'
          }`}
        >
          <img
            src={QR_SRC}
            alt="Mã QR Vietcombank ủng hộ phát triển thêm"
            className="h-full w-full object-contain"
          />
        </div>
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-1 text-[11px] font-semibold text-emerald-400">
            <Heart className="h-3 w-3 shrink-0" />
            <span className="truncate">Donate ủng hộ phát triển thêm</span>
          </div>
          <div className="mt-0.5 truncate text-[11px] text-slate-300">
            Vietcombank · PHAM MINH DUY
          </div>
          <div className="mt-0.5 flex items-center justify-between text-[10px] text-slate-400">
            <span className="font-mono">9374566351</span>
            <span className="inline-flex items-center gap-0.5 text-slate-400 group-hover:text-emerald-300">
              <ZoomIn className="h-3 w-3" />
              <span>Phóng to</span>
            </span>
          </div>
        </div>
      </button>

      {open && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4"
          role="dialog"
          aria-modal="true"
          aria-label="Mã QR Donate ủng hộ phát triển thêm"
          onClick={() => setOpen(false)}
        >
          <div
            className="w-full max-w-xs rounded-lg border border-white/15 bg-[#121822] p-4 text-center"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="mb-3 flex items-center justify-between">
              <div className="flex items-center gap-1.5 text-sm font-bold text-white">
                <Heart className="h-4 w-4 text-emerald-400" />
                <span>Ủng hộ phát triển thêm</span>
              </div>
              <button
                type="button"
                aria-label="Đóng mã QR donate"
                onClick={() => setOpen(false)}
                className="rounded p-1 text-slate-400 hover:bg-white/5 hover:text-white"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <div className="mx-auto w-56 overflow-hidden rounded-md bg-white p-1">
              <img
                src={QR_SRC}
                alt="Mã QR Vietcombank PHAM MINH DUY 9374566351"
                className="h-auto w-full object-contain"
              />
            </div>

            <p className="mt-3 text-xs leading-relaxed text-slate-300">
              Cảm ơn bạn đã trải nghiệm <strong className="text-white">Manger Football VN</strong>! Mọi đóng góp giúp mình phát triển thêm tính năng và dữ liệu mới.
            </p>
          </div>
        </div>
      )}
    </>
  );
};
