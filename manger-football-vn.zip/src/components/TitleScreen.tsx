import React, { useMemo, useState } from 'react';
import { Check, Copy, ExternalLink, Globe, Share2, Shield, Trophy, Tv, X } from 'lucide-react';
import {
  LEAGUES,
  LEAGUE_ORDER,
  createInitialDatabase,
} from '../data/database';
import { COUNTRY_PYRAMIDS } from '../data/lowerLeagues';
import { ClubChoice } from '../engine/schedule';
import { calculateTeamRatings } from '../engine/tactics';
import {
  CrestPattern,
  CustomClubConfig,
  CustomClubTier,
  FormationName,
  LeagueId,
} from '../types/fm';
import { ClubCrest } from './ClubCrest';
import { DonateQrWidget } from './DonateQrWidget';

interface TitleScreenProps {
  hasSavedCareer: boolean;
  savedClubLabel?: string;
  onResumeCareer: () => void;
  onStartCareer: (managerName: string, choice: ClubChoice) => void;
}

const COLOR_PRESETS = [
  '#EF0107', '#004D98', '#6CABDD', '#10B981', '#F59E0B',
  '#7A263A', '#111827', '#FFFFFF', '#4B2884', '#0068A8',
];

const CREST_PATTERNS: { id: CrestPattern; label: string }[] = [
  { id: 'stripes', label: 'Sọc dọc' },
  { id: 'halves', label: 'Chia đôi' },
  { id: 'sash', label: 'Chéo vai' },
  { id: 'hoops', label: 'Sọc ngang' },
  { id: 'chevron', label: 'Chữ V' },
  { id: 'solid', label: 'Thuần sắc' },
];

const FORMATIONS_LIST: FormationName[] = [
  '4-3-3 DM',
  '4-2-3-1',
  '4-4-2',
  '3-5-2',
  '3-4-2-1',
  '4-1-4-1',
  '5-3-2',
];

export const TitleScreen: React.FC<TitleScreenProps> = ({
  hasSavedCareer,
  savedClubLabel,
  onResumeCareer,
  onStartCareer,
}) => {
  const db = useMemo(() => createInitialDatabase(), []);
  const [mode, setMode] = useState<'existing' | 'custom'>('existing');
  const [managerName, setManagerName] = useState('');
  const [selectedLeague, setSelectedLeague] = useState<LeagueId>('eng_pl');
  const [selectedClubId, setSelectedClubId] = useState<string>('ars');
  const [formError, setFormError] = useState<string | null>(null);
  const [copiedLink, setCopiedLink] = useState<boolean>(false);
  const [googleSitesOpen, setGoogleSitesOpen] = useState<boolean>(false);
  const [embedCompact, setEmbedCompact] = useState<boolean>(true);
  const [copiedType, setCopiedType] = useState<'url' | 'iframe' | null>(null);

  const isEmbedMode = useMemo(() => {
    if (typeof window === 'undefined') return false;
    return new URLSearchParams(window.location.search).get('embed') === '1';
  }, []);

  const publicSiteBaseUrl = useMemo(() => {
    const fallbackPublicUrl = 'https://ais-pre-mswzha63kmsjp3zyfjvidy-939171072800.asia-northeast1.run.app';
    if (typeof window === 'undefined') return fallbackPublicUrl;
    const host = window.location.hostname;
    if (host === 'localhost' || host === '127.0.0.1' || host.startsWith('ais-dev-')) {
      return fallbackPublicUrl;
    }
    return window.location.origin;
  }, []);

  const googleSitesEmbedUrl = embedCompact ? `${publicSiteBaseUrl}/?embed=1` : publicSiteBaseUrl;
  const googleSitesIframeCode = `<iframe src="${googleSitesEmbedUrl}" width="100%" height="900" style="border:0;border-radius:12px;overflow:hidden;" allowfullscreen loading="lazy" title="Manger Football VN"></iframe>`;

  const handleCopyWebsiteUrl = async () => {
    try {
      await navigator.clipboard.writeText(publicSiteBaseUrl);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2500);
    } catch {
      setCopiedLink(false);
    }
  };

  const handleCopyGoogleSitesSnippet = async (type: 'url' | 'iframe', text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedType(type);
      setTimeout(() => setCopiedType(null), 2500);
    } catch {
      setCopiedType(null);
    }
  };

  // Custom Club state (blank fields so users fill in their own details)
  const [customConfig, setCustomConfig] = useState<CustomClubConfig>({
    name: '',
    shortName: '',
    city: '',
    stadium: '',
    capacity: 15000,
    leagueId: 'vie_vleague',
    primaryColor: '#10B981',
    secondaryColor: '#0F172A',
    crestPattern: 'chevron',
    tier: 'midtable',
    formation: '4-3-3 DM',
    starPlayerName: '',
  });

  const customPyramid = COUNTRY_PYRAMIDS[customConfig.leagueId] ?? COUNTRY_PYRAMIDS.vie_vleague;

  const leagueClubs = useMemo(
    () =>
      Object.values(db.clubs)
        .filter((c) => c.leagueId === selectedLeague)
        .sort((a, b) => b.reputation - a.reputation),
    [db.clubs, selectedLeague]
  );

  const selectedClub = db.clubs[selectedClubId] ?? leagueClubs[0];
  const selectedRatings = useMemo(
    () => (selectedClub ? calculateTeamRatings(selectedClub, db.players) : null),
    [selectedClub, db.players]
  );
  const topStars = useMemo(() => {
    if (!selectedClub) return [];
    return Object.values(db.players)
      .filter((p) => p.clubId === selectedClub.id)
      .sort((a, b) => b.ovr - a.ovr)
      .slice(0, 3);
  }, [selectedClub, db.players]);

  const handleSelectLeague = (lid: LeagueId) => {
    setSelectedLeague(lid);
    const first = Object.values(db.clubs)
      .filter((c) => c.leagueId === lid)
      .sort((a, b) => b.reputation - a.reputation)[0];
    if (first) setSelectedClubId(first.id);
  };

  const handleStart = () => {
    if (!managerName.trim()) {
      setFormError('Vui lòng nhập tên Huấn luyện viên.');
      return;
    }
    if (mode === 'custom') {
      if (!customConfig.name.trim() || customConfig.name.trim().length < 3) {
        setFormError('Vui lòng nhập tên CLB riêng (tối thiểu 3 ký tự).');
        return;
      }
      if (!customConfig.shortName.trim()) {
        setFormError('Vui lòng nhập mã viết tắt CLB (1–3 ký tự).');
        return;
      }
      if (!customConfig.city.trim()) {
        setFormError('Vui lòng nhập thành phố của CLB.');
        return;
      }
      if (!customConfig.stadium.trim()) {
        setFormError('Vui lòng nhập tên sân vận động.');
        return;
      }
      setFormError(null);
      onStartCareer(managerName, { type: 'custom', config: customConfig });
    } else {
      setFormError(null);
      onStartCareer(managerName, { type: 'existing', clubId: selectedClub.id });
    }
  };

  return (
    <div className="relative min-h-screen w-full overflow-x-hidden bg-[#0B0F17] text-slate-100">
      {/* Background stadium photography with contrast scrim */}
      <div className="fixed inset-0 z-0">
        <img
          src={`${import.meta.env.BASE_URL}src/assets/images/title_stadium_bg_1795792081950.jpg`}
          alt="Sân vận động ban đêm"
          referrerPolicy="no-referrer"
          className="h-full w-full object-cover object-center opacity-45"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-[#0B0F17] via-[#0B0F17]/88 to-[#0B0F17]/75" />
      </div>

      {/* Website Navigation Header (hidden inside ?embed=1 for seamless Google Sites framing) */}
      {!isEmbedMode && (
        <header className="sticky top-0 z-30 border-b border-white/10 bg-[#0B0F17]/90 backdrop-blur-md">
          <div className="mx-auto flex max-w-[1380px] items-center justify-between gap-3 px-6 py-3 lg:px-10">
            <a href="#play" className="flex items-center gap-2.5 text-white">
              <svg
                width="32"
                height="32"
                viewBox="0 0 52 52"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
                aria-hidden="true"
                className="shrink-0"
              >
                <rect x="2" y="2" width="48" height="48" rx="10" fill="#121822" stroke="#10B981" strokeWidth="2" />
                <circle cx="26" cy="26" r="8" stroke="#10B981" strokeWidth="2" />
                <circle cx="26" cy="26" r="2.5" fill="#10B981" />
              </svg>
              <span className="font-display text-lg font-extrabold tracking-tight sm:text-xl">
                MANGER FOOTBALL VN
              </span>
            </a>

            <nav aria-label="Điều hướng trang web" className="hidden items-center gap-6 text-xs font-semibold text-slate-300 md:flex">
              <a href="#play" className="transition-colors hover:text-emerald-400">
                Vào game ngay
              </a>
              <a href="#features" className="transition-colors hover:text-emerald-400">
                Tính năng chính
              </a>
              <a href="#roadmap" className="transition-colors hover:text-emerald-400">
                Lộ trình leo hạng
              </a>
              <a href="#support" className="transition-colors hover:text-emerald-400">
                Ủng hộ phát triển
              </a>
            </nav>

            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setGoogleSitesOpen(true)}
                className="flex items-center gap-1.5 rounded-md border border-emerald-500/40 bg-emerald-600/15 px-3 py-1.5 text-xs font-semibold text-emerald-300 transition-colors hover:bg-emerald-600/25"
              >
                <Globe className="h-3.5 w-3.5" />
                <span>Google Sites</span>
              </button>
              <button
                type="button"
                onClick={handleCopyWebsiteUrl}
                className="flex items-center gap-1.5 rounded-md border border-white/15 bg-[#121822] px-3 py-1.5 text-xs font-semibold text-slate-200 transition-colors hover:border-emerald-500/40 hover:text-emerald-300"
              >
                {copiedLink ? <Check className="h-3.5 w-3.5 text-emerald-400" /> : <Share2 className="h-3.5 w-3.5" />}
                <span className="hidden sm:inline">{copiedLink ? 'Đã sao chép!' : 'Chia sẻ web'}</span>
              </button>
            </div>
          </div>
        </header>
      )}

      <main id="play" className="relative z-10 mx-auto flex max-w-[1380px] flex-col justify-center px-6 py-8 lg:px-10">
        <div className="grid grid-cols-1 items-start gap-8 lg:grid-cols-12">
          {/* Left Panel: Emblem, Manager Setup & Mode Switch */}
          <section className="flex flex-col gap-6 lg:col-span-5">
            <div className="flex items-center gap-4">
              {/* Custom inline SVG Tactical Crest Lockup */}
              <svg
                width="52"
                height="52"
                viewBox="0 0 52 52"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
                aria-hidden="true"
                className="shrink-0"
              >
                <rect x="2" y="2" width="48" height="48" rx="10" fill="#121822" stroke="#10B981" strokeWidth="1.5" />
                <line x1="26" y1="8" x2="26" y2="44" stroke="rgba(255,255,255,0.18)" strokeWidth="1.2" />
                <circle cx="26" cy="26" r="8" stroke="#10B981" strokeWidth="1.6" />
                <circle cx="26" cy="26" r="2.2" fill="#10B981" />
                <path d="M13 18L19 26L13 34" stroke="#F8FAFC" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
                <path d="M39 18L33 26L39 34" stroke="#F8FAFC" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
              <div>
                <h1 className="font-display text-4xl font-extrabold tracking-tight text-white sm:text-5xl">
                  MANGER FOOTBALL VN
                </h1>
                <p className="text-sm text-slate-400">
                  Quản lý bóng đá chiến thuật · 6 Giải VĐQG · Match Engine 2D
                </p>
              </div>
            </div>

            {hasSavedCareer && (
              <div className="flex items-center justify-between gap-4 rounded-lg border border-emerald-500/30 bg-[#121822]/90 px-4 py-3">
                <div className="min-w-0">
                  <div className="text-xs font-medium text-emerald-400">Sự nghiệp đang lưu</div>
                  <div className="truncate text-sm font-semibold text-white">
                    {savedClubLabel ?? 'Tiếp tục sự nghiệp hiện tại'}
                  </div>
                </div>
                <button
                  type="button"
                  onClick={onResumeCareer}
                  className="shrink-0 whitespace-nowrap rounded-md bg-emerald-600 px-4 py-2 text-sm font-semibold text-white transition-colors hover:bg-emerald-500"
                >
                  Tiếp tục chơi
                </button>
              </div>
            )}

            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleStart();
              }}
              className="flex flex-col gap-5 rounded-lg border border-white/10 bg-[#121822]/92 p-6"
            >
              <div>
                <label htmlFor="manager-name" className="mb-1.5 block text-xs font-semibold text-slate-300">
                  Tên Huấn Luyện Viên
                </label>
                <input
                  id="manager-name"
                  type="text"
                  value={managerName}
                  onChange={(e) => {
                    setManagerName(e.target.value);
                    if (formError) setFormError(null);
                  }}
                  placeholder="Nhập tên HLV của bạn..."
                  className="w-full rounded-md border border-white/15 bg-[#0B0F17] px-3.5 py-2.5 text-sm text-white placeholder-slate-500 focus:border-emerald-500 focus:outline-none"
                />
              </div>

              <div>
                <span className="mb-1.5 block text-xs font-semibold text-slate-300">
                  Chế độ khởi đầu
                </span>
                <div className="grid grid-cols-2 gap-1.5 rounded-md bg-[#0B0F17] p-1">
                  <button
                    type="button"
                    onClick={() => {
                      setMode('existing');
                      setFormError(null);
                    }}
                    className={`rounded px-3 py-2 text-sm font-semibold transition-colors whitespace-nowrap ${
                      mode === 'existing'
                        ? 'bg-emerald-600 text-white'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    Chọn CLB có sẵn
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setMode('custom');
                      setFormError(null);
                    }}
                    className={`rounded px-3 py-2 text-sm font-semibold transition-colors whitespace-nowrap ${
                      mode === 'custom'
                        ? 'bg-emerald-600 text-white'
                        : 'text-slate-400 hover:text-white'
                    }`}
                  >
                    Tạo CLB Riêng
                  </button>
                </div>
              </div>

              {mode === 'existing' && selectedClub && selectedRatings && (
                <div className="border-t border-white/10 pt-4">
                  <div className="flex items-center gap-3.5">
                    <ClubCrest
                      primaryColor={selectedClub.primaryColor}
                      secondaryColor={selectedClub.secondaryColor}
                      pattern={selectedClub.crestPattern}
                      shortName={selectedClub.shortName}
                      size={48}
                    />
                    <div className="min-w-0 flex-1">
                      <div className="truncate font-display text-2xl font-bold text-white">
                        {selectedClub.name}
                      </div>
                      <div className="text-xs text-slate-400">
                        {LEAGUES[selectedClub.leagueId].name} · {selectedClub.stadium} ({selectedClub.capacity.toLocaleString('vi-VN')} chỗ)
                      </div>
                    </div>
                    <div className="text-right tabular-nums">
                      <div className="text-xs text-slate-400">OVR</div>
                      <div className="font-mono text-xl font-bold text-emerald-400">
                        {selectedRatings.overall}
                      </div>
                    </div>
                  </div>

                  <div className="mt-4 grid grid-cols-3 gap-3 border-y border-white/10 py-3 text-xs tabular-nums">
                    <div>
                      <div className="text-slate-400">Ngân sách CN</div>
                      <div className="mt-0.5 font-mono text-sm font-semibold text-white">
                        €{selectedClub.finances.transferBudget.toFixed(1)}M
                      </div>
                    </div>
                    <div>
                      <div className="text-slate-400">Quỹ lương/tuần</div>
                      <div className="mt-0.5 font-mono text-sm font-semibold text-white">
                        €{selectedClub.finances.wageBudgetWeekly}k
                      </div>
                    </div>
                    <div>
                      <div className="text-slate-400">Sơ đồ mặc định</div>
                      <div className="mt-0.5 font-mono text-sm font-semibold text-white">
                        {selectedClub.tactics.formation}
                      </div>
                    </div>
                  </div>

                  <div className="mt-3 text-xs text-slate-300">
                    <span className="text-slate-400">Mục tiêu BLĐ: </span>
                    <span className="font-medium text-white">{selectedClub.expectation}</span>
                  </div>

                  <div className="mt-3">
                    <div className="mb-1.5 text-xs text-slate-400">Ngôi sao chủ chốt</div>
                    <div className="grid grid-cols-3 gap-2">
                      {topStars.map((st) => (
                        <div key={st.id} className="rounded border border-white/10 bg-[#0B0F17] px-2.5 py-2">
                          <div className="truncate text-xs font-semibold text-white">{st.name}</div>
                          <div className="mt-0.5 flex items-center justify-between text-[11px] text-slate-400 tabular-nums">
                            <span>{st.primaryPosition}</span>
                            <span className="font-mono font-bold text-emerald-400">{st.ovr}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {mode === 'custom' && (
                <div className="border-t border-white/10 pt-4">
                  <div className="flex items-center gap-4">
                    <ClubCrest
                      primaryColor={customConfig.primaryColor}
                      secondaryColor={customConfig.secondaryColor}
                      pattern={customConfig.crestPattern}
                      shortName={customConfig.shortName.trim() || '---'}
                      size={52}
                    />
                    <div className="min-w-0 flex-1">
                      <div className="truncate font-display text-2xl font-bold text-white">
                        {customConfig.name.trim() || 'Chưa đặt tên CLB'}
                      </div>
                      <div className="text-xs text-slate-400">
                        Khởi đầu: {customPyramid.tier3.name} ({customPyramid.country}) · {customConfig.formation}
                      </div>
                    </div>
                  </div>
                  <div className="mt-3 rounded border border-emerald-500/25 bg-[#0B0F17] px-3 py-2 text-[11px]">
                    <div className="font-semibold text-emerald-400">Lộ trình leo hạng (3 cấp)</div>
                    <div className="mt-1 flex flex-wrap items-center gap-1.5 text-slate-300">
                      <span className="font-semibold text-white">{customPyramid.tier3.name}</span>
                      <span className="text-slate-500">→</span>
                      <span>{customPyramid.tier2.name}</span>
                      <span className="text-slate-500">→</span>
                      <span className="text-amber-400">{LEAGUES[customConfig.leagueId].name}</span>
                    </div>
                  </div>
                  <p className="mt-2.5 text-xs leading-relaxed text-slate-400">
                    CLB của bạn sẽ thi đấu từ hạng thấp nhất ({customPyramid.tier3.name}), cạnh tranh Top 2 qua từng mùa giải để thăng hạng lên {LEAGUES[customConfig.leagueId].name}.
                  </p>
                </div>
              )}

              {formError && (
                <p role="alert" className="text-xs font-medium text-rose-400">
                  {formError}
                </p>
              )}

              <button
                type="submit"
                data-start="true"
                className="w-full rounded-md bg-emerald-600 px-5 py-3 text-base font-bold text-white transition-colors hover:bg-emerald-500 focus:outline-none focus-visible:ring-2 focus-visible:ring-emerald-400"
              >
                {mode === 'custom' ? 'Thành lập CLB & Nhậm chức HLV' : 'Nhậm chức HLV'}
              </button>
            </form>
          </section>

          {/* Right Panel: League & Club Browser OR Custom Club Builder */}
          <section className="rounded-lg border border-white/10 bg-[#121822]/92 p-6 lg:col-span-7">
            {mode === 'existing' ? (
              <div>
                <div className="mb-4 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                  <div>
                    <h2 className="font-display text-2xl font-bold text-white">
                      Chọn Giải Vô Địch Quốc Gia & CLB
                    </h2>
                    <p className="text-xs text-slate-400">
                      6 giải đấu hàng đầu · 60 CLB · Dữ liệu cầu thủ xuyên suốt các giải
                    </p>
                  </div>
                </div>

                {/* League Selector Tabs */}
                <div className="mb-5 flex flex-wrap gap-1.5 rounded-md bg-[#0B0F17] p-1.5">
                  {LEAGUE_ORDER.map((lid) => {
                    const lg = LEAGUES[lid];
                    const active = selectedLeague === lid;
                    return (
                      <button
                        key={lid}
                        type="button"
                        onClick={() => handleSelectLeague(lid)}
                        className={`rounded px-3 py-1.5 text-xs font-semibold transition-colors whitespace-nowrap shrink-0 ${
                          active
                            ? 'bg-emerald-600 text-white'
                            : 'text-slate-400 hover:bg-white/5 hover:text-white'
                        }`}
                      >
                        {lg.name} ({lg.country})
                      </button>
                    );
                  })}
                </div>

                {/* Club Grid */}
                <div className="grid max-h-[500px] grid-cols-1 gap-2.5 overflow-y-auto pr-1 sm:grid-cols-2">
                  {leagueClubs.map((club) => {
                    const isSelected = selectedClub?.id === club.id;
                    const ratings = calculateTeamRatings(club, db.players);
                    return (
                      <button
                        key={club.id}
                        type="button"
                        onClick={() => setSelectedClubId(club.id)}
                        className={`flex items-center gap-3 rounded-md border p-3 text-left transition-colors ${
                          isSelected
                            ? 'border-emerald-500 bg-emerald-500/10'
                            : 'border-white/10 bg-[#0B0F17]/80 hover:border-white/25'
                        }`}
                      >
                        <ClubCrest
                          primaryColor={club.primaryColor}
                          secondaryColor={club.secondaryColor}
                          pattern={club.crestPattern}
                          shortName={club.shortName}
                          size={38}
                        />
                        <div className="min-w-0 flex-1">
                          <div className="truncate text-sm font-bold text-white">{club.name}</div>
                          <div className="truncate text-xs text-slate-400">
                            {club.city} · €{club.finances.transferBudget.toFixed(0)}M CN
                          </div>
                        </div>
                        <div className="text-right tabular-nums">
                          <div className="font-mono text-sm font-bold text-emerald-400">
                            {ratings.overall}
                          </div>
                          <div className="text-[11px] text-slate-500">OVR</div>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>
            ) : (
              <div>
                <div className="mb-5">
                  <h2 className="font-display text-2xl font-bold text-white">
                    Thiết Kế CLB Của Riêng Bạn
                  </h2>
                  <p className="text-xs text-slate-400">
                    Tùy chỉnh bản sắc, màu áo, sân vận động, giải đấu và tiềm lực tài chính
                  </p>
                </div>

                <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                  <div>
                    <label htmlFor="custom-club-name" className="mb-1 block text-xs font-semibold text-slate-300">
                      Tên CLB
                    </label>
                    <input
                      id="custom-club-name"
                      type="text"
                      value={customConfig.name}
                      onChange={(e) => {
                        setCustomConfig({ ...customConfig, name: e.target.value });
                        if (formError) setFormError(null);
                      }}
                      placeholder="Nhập tên CLB của bạn..."
                      className="w-full rounded-md border border-white/15 bg-[#0B0F17] px-3 py-2 text-sm text-white placeholder-slate-500 focus:border-emerald-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label htmlFor="custom-club-short" className="mb-1 block text-xs font-semibold text-slate-300">
                      Mã viết tắt (3 ký tự)
                    </label>
                    <input
                      id="custom-club-short"
                      type="text"
                      maxLength={3}
                      value={customConfig.shortName}
                      onChange={(e) => {
                        setCustomConfig({ ...customConfig, shortName: e.target.value.toUpperCase() });
                        if (formError) setFormError(null);
                      }}
                      placeholder="VD: SGT"
                      className="w-full rounded-md border border-white/15 bg-[#0B0F17] px-3 py-2 font-mono text-sm uppercase text-white placeholder-slate-500 focus:border-emerald-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label htmlFor="custom-league" className="mb-1 block text-xs font-semibold text-slate-300">
                      Hệ thống giải quốc gia (Xuất phát từ Hạng thấp nhất)
                    </label>
                    <select
                      id="custom-league"
                      value={customConfig.leagueId}
                      onChange={(e) =>
                        setCustomConfig({ ...customConfig, leagueId: e.target.value as LeagueId })
                      }
                      className="w-full rounded-md border border-white/15 bg-[#0B0F17] px-3 py-2 text-sm text-white focus:border-emerald-500 focus:outline-none"
                    >
                      {LEAGUE_ORDER.map((lid) => {
                        const pyr = COUNTRY_PYRAMIDS[lid];
                        return (
                          <option key={lid} value={lid}>
                            {LEAGUES[lid].country}: từ {pyr.tier3.name} → {LEAGUES[lid].name}
                          </option>
                        );
                      })}
                    </select>
                  </div>

                  <div>
                    <label htmlFor="custom-tier" className="mb-1 block text-xs font-semibold text-slate-300">
                      Nền tảng khởi đầu tại Hạng thấp nhất
                    </label>
                    <select
                      id="custom-tier"
                      value={customConfig.tier}
                      onChange={(e) =>
                        setCustomConfig({ ...customConfig, tier: e.target.value as CustomClubTier })
                      }
                      className="w-full rounded-md border border-white/15 bg-[#0B0F17] px-3 py-2 text-sm text-white focus:border-emerald-500 focus:outline-none"
                    >
                      <option value="underdog">CLB Phong Trào (Khởi đầu gian khó · Ngân sách thấp)</option>
                      <option value="midtable">CLB Tham Vọng (Đội hình khá · Mục tiêu Top 2 thăng hạng)</option>
                      <option value="tycoon">Dự Án Đầu Tư Mạnh (Vẫn xuất phát từ Hạng thấp nhất)</option>
                    </select>
                  </div>

                  <div>
                    <label htmlFor="custom-city" className="mb-1 block text-xs font-semibold text-slate-300">
                      Thành phố
                    </label>
                    <input
                      id="custom-city"
                      type="text"
                      value={customConfig.city}
                      onChange={(e) => {
                        setCustomConfig({ ...customConfig, city: e.target.value });
                        if (formError) setFormError(null);
                      }}
                      placeholder="Nhập tên thành phố..."
                      className="w-full rounded-md border border-white/15 bg-[#0B0F17] px-3 py-2 text-sm text-white placeholder-slate-500 focus:border-emerald-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label htmlFor="custom-stadium" className="mb-1 block text-xs font-semibold text-slate-300">
                      Sân vận động
                    </label>
                    <input
                      id="custom-stadium"
                      type="text"
                      value={customConfig.stadium}
                      onChange={(e) => {
                        setCustomConfig({ ...customConfig, stadium: e.target.value });
                        if (formError) setFormError(null);
                      }}
                      placeholder="Nhập tên sân vận động..."
                      className="w-full rounded-md border border-white/15 bg-[#0B0F17] px-3 py-2 text-sm text-white placeholder-slate-500 focus:border-emerald-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label htmlFor="custom-star" className="mb-1 block text-xs font-semibold text-slate-300">
                      Tiền đạo Đội trưởng / Ngôi sao số 10
                    </label>
                    <input
                      id="custom-star"
                      type="text"
                      value={customConfig.starPlayerName ?? ''}
                      onChange={(e) =>
                        setCustomConfig({ ...customConfig, starPlayerName: e.target.value })
                      }
                      placeholder="Nhập tên ngôi sao (tùy chọn)..."
                      className="w-full rounded-md border border-white/15 bg-[#0B0F17] px-3 py-2 text-sm text-white placeholder-slate-500 focus:border-emerald-500 focus:outline-none"
                    />
                  </div>

                  <div>
                    <label htmlFor="custom-formation" className="mb-1 block text-xs font-semibold text-slate-300">
                      Sơ đồ chiến thuật khởi đầu
                    </label>
                    <select
                      id="custom-formation"
                      value={customConfig.formation}
                      onChange={(e) =>
                        setCustomConfig({
                          ...customConfig,
                          formation: e.target.value as FormationName,
                        })
                      }
                      className="w-full rounded-md border border-white/15 bg-[#0B0F17] px-3 py-2 text-sm text-white focus:border-emerald-500 focus:outline-none"
                    >
                      {FORMATIONS_LIST.map((f) => (
                        <option key={f} value={f}>
                          {f}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Jersey Colors & Crest Pattern */}
                <div className="mt-5 grid grid-cols-1 gap-4 border-t border-white/10 pt-4 sm:grid-cols-2">
                  <div>
                    <span className="mb-2 block text-xs font-semibold text-slate-300">
                      Màu áo chính
                    </span>
                    <div className="flex flex-wrap gap-2">
                      {COLOR_PRESETS.map((hex) => (
                        <button
                          key={`p_${hex}`}
                          type="button"
                          aria-label={`Chọn màu chính ${hex}`}
                          onClick={() => setCustomConfig({ ...customConfig, primaryColor: hex })}
                          className={`h-7 w-7 rounded border transition-transform ${
                            customConfig.primaryColor === hex
                              ? 'scale-110 border-emerald-400 ring-2 ring-emerald-400/50'
                              : 'border-white/25'
                          }`}
                          style={{ backgroundColor: hex }}
                        />
                      ))}
                    </div>
                  </div>

                  <div>
                    <span className="mb-2 block text-xs font-semibold text-slate-300">
                      Màu phối phụ
                    </span>
                    <div className="flex flex-wrap gap-2">
                      {COLOR_PRESETS.map((hex) => (
                        <button
                          key={`s_${hex}`}
                          type="button"
                          aria-label={`Chọn màu phụ ${hex}`}
                          onClick={() => setCustomConfig({ ...customConfig, secondaryColor: hex })}
                          className={`h-7 w-7 rounded border transition-transform ${
                            customConfig.secondaryColor === hex
                              ? 'scale-110 border-emerald-400 ring-2 ring-emerald-400/50'
                              : 'border-white/25'
                          }`}
                          style={{ backgroundColor: hex }}
                        />
                      ))}
                    </div>
                  </div>
                </div>

                <div className="mt-4">
                  <span className="mb-2 block text-xs font-semibold text-slate-300">
                    Họa tiết huy hiệu CLB
                  </span>
                  <div className="flex flex-wrap gap-1.5">
                    {CREST_PATTERNS.map((pt) => (
                      <button
                        key={pt.id}
                        type="button"
                        onClick={() => setCustomConfig({ ...customConfig, crestPattern: pt.id })}
                        className={`rounded px-3 py-1.5 text-xs font-semibold transition-colors whitespace-nowrap ${
                          customConfig.crestPattern === pt.id
                            ? 'bg-emerald-600 text-white'
                            : 'bg-[#0B0F17] text-slate-400 hover:text-white'
                        }`}
                      >
                        {pt.label}
                      </button>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </section>
        </div>

        <p className="mt-6 text-center text-xs text-slate-500">
          Nhấn Enter hoặc chọn Nhậm chức HLV để bắt đầu · Dữ liệu lưu tự động trên trình duyệt
        </p>

        {!isEmbedMode && (
          <>
            {/* Website Features Showcase */}
            <section id="features" className="mt-14 border-t border-white/10 pt-10">
              <div className="mb-6">
                <h2 className="font-display text-2xl font-bold text-white sm:text-3xl">
                  Trải Nghiệm Quản Lý Bóng Đá Chân Thực Trên Web
                </h2>
                <p className="mt-1 text-sm text-slate-400">
                  Chơi trực tiếp trên trình duyệt máy tính và điện thoại không cần cài đặt.
                </p>
              </div>
              <div className="grid grid-cols-1 gap-4 md:grid-cols-3">
                <div className="rounded-lg border border-white/10 bg-[#121822]/90 p-5">
                  <Trophy className="h-5 w-5 text-emerald-400" />
                  <h3 className="mt-3 font-display text-xl font-bold text-white">6 Giải VĐQG & Hạng Dưới</h3>
                  <p className="mt-1.5 text-xs leading-relaxed text-slate-400">
                    Dữ liệu cầu thủ xuyên suốt Premier League, La Liga, Serie A, Bundesliga, Ligue 1, LPBank V.League 1 cùng đầy đủ các giải Hạng 2 & Hạng 3.
                  </p>
                </div>
                <div className="rounded-lg border border-white/10 bg-[#121822]/90 p-5">
                  <Shield className="h-5 w-5 text-emerald-400" />
                  <h3 className="mt-3 font-display text-xl font-bold text-white">Chiến Thuật & Chuyển Nhượng</h3>
                  <p className="mt-1.5 text-xs leading-relaxed text-slate-400">
                    7 sơ đồ chiến thuật, vai trò vị trí chuẩn FM, đàm phán phí chuyển nhượng & hợp đồng 2 bước, kiểm soát quỹ lương và niềm tin ban lãnh đạo.
                  </p>
                </div>
                <div className="rounded-lg border border-white/10 bg-[#121822]/90 p-5">
                  <Tv className="h-5 w-5 text-emerald-400" />
                  <h3 className="mt-3 font-display text-xl font-bold text-white">Match Engine 2D Trực Tiếp</h3>
                  <p className="mt-1.5 text-xs leading-relaxed text-slate-400">
                    Theo dõi 22 cầu thủ di chuyển theo thời gian thực trên sân 2D, điều chỉnh lối đá, thay người chiến thuật và nói chuyện giờ nghỉ giữa hiệp.
                  </p>
                </div>
              </div>
            </section>

            {/* Road to Glory Pyramid Section */}
            <section id="roadmap" className="mt-10 rounded-lg border border-white/10 bg-[#121822]/90 p-6">
              <div className="flex flex-col justify-between gap-6 lg:flex-row lg:items-center">
                <div className="max-w-xl">
                  <h2 className="font-display text-2xl font-bold text-white">
                    Chế Độ Tạo CLB Riêng: Leo Hạng Từ Đáy Lên Đỉnh Cao
                  </h2>
                  <p className="mt-1.5 text-xs leading-relaxed text-slate-400">
                    Khi tự thiết kế CLB, bạn bắt đầu hành trình từ hạng đấu thấp nhất của quốc gia đã chọn. Cạnh tranh Top 2 qua từng mùa giải 18 vòng để thăng hạng liên tiếp, nhận tiền thưởng nâng cấp ngân sách và chinh phục chiếc cúp VĐQG danh giá.
                  </p>
                </div>
                <div className="grid grid-cols-3 gap-2.5 text-center text-xs">
                  <div className="rounded border border-white/10 bg-[#0B0F17] px-3 py-2.5">
                    <div className="font-mono text-[11px] text-slate-400">Mùa 1</div>
                    <div className="mt-0.5 font-bold text-white">Hạng Thấp Nhất</div>
                  </div>
                  <div className="rounded border border-emerald-500/30 bg-[#0B0F17] px-3 py-2.5">
                    <div className="font-mono text-[11px] text-emerald-400">Top 2 Thăng Hạng</div>
                    <div className="mt-0.5 font-bold text-white">Giải Hạng Nhì / Nhất</div>
                  </div>
                  <div className="rounded border border-amber-500/30 bg-[#0B0F17] px-3 py-2.5">
                    <div className="font-mono text-[11px] text-amber-400">Đỉnh Cao</div>
                    <div className="mt-0.5 font-bold text-white">Giải VĐQG</div>
                  </div>
                </div>
              </div>
            </section>
          </>
        )}
      </main>

      {!isEmbedMode && (
        <footer id="support" className="relative z-10 mt-6 border-t border-white/10 bg-[#0B0F17]/95">
          <div className="mx-auto flex max-w-[1380px] flex-col items-start justify-between gap-4 px-6 py-6 sm:flex-row sm:items-center lg:px-10">
            <div>
              <div className="font-display text-lg font-bold text-white">MANGER FOOTBALL VN</div>
              <p className="text-xs text-slate-400">
                Web game quản lý bóng đá chiến thuật · Hỗ trợ nhúng trực tiếp lên Google Sites.
              </p>
            </div>
            <div className="w-full sm:w-80">
              <DonateQrWidget compact />
            </div>
          </div>
        </footer>
      )}

      {/* Google Sites Embed Helper Modal */}
      {googleSitesOpen && (
        <div
          role="dialog"
          aria-modal="true"
          aria-labelledby="google-sites-modal-title"
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4 backdrop-blur-sm"
        >
          <div className="w-full max-w-xl rounded-xl border border-white/15 bg-[#121822] p-6 text-slate-100 shadow-2xl">
            <div className="flex items-start justify-between gap-4">
              <div>
                <h2 id="google-sites-modal-title" className="font-display text-2xl font-bold text-white">
                  Đưa Manger Football VN lên Google Sites
                </h2>
                <p className="mt-1 text-xs text-slate-400">
                  Nhúng toàn bộ game hoạt động mượt mà ngay trên trang Google Sites của bạn.
                </p>
              </div>
              <button
                type="button"
                aria-label="Đóng hướng dẫn Google Sites"
                onClick={() => setGoogleSitesOpen(false)}
                className="rounded-md p-1.5 text-slate-400 hover:bg-white/10 hover:text-white"
              >
                <X className="h-4 w-4" />
              </button>
            </div>

            <ol className="mt-4 space-y-2 rounded-lg border border-white/10 bg-[#0B0F17] p-4 text-xs text-slate-300">
              <li>
                <span className="font-bold text-emerald-400">Bước 1:</span> Mở{' '}
                <a
                  href="https://sites.google.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1 font-semibold text-emerald-400 underline hover:text-emerald-300"
                >
                  sites.google.com
                  <ExternalLink className="h-3 w-3" />
                </a>{' '}
                và mở trang web Google Sites của bạn.
              </li>
              <li>
                <span className="font-bold text-emerald-400">Bước 2:</span> Ở thanh công cụ bên phải, chọn{' '}
                <strong className="text-white">Chèn (Insert)</strong> → <strong className="text-white">Nhúng (Embed)</strong>.
              </li>
              <li>
                <span className="font-bold text-emerald-400">Bước 3:</span> Dán <strong className="text-white">Theo URL</strong> hoặc chọn tab <strong className="text-white">Mã nhúng</strong> để dán đoạn HTML bên dưới, sau đó kéo khung ra toàn chiều rộng.
              </li>
            </ol>

            <label className="mt-4 flex cursor-pointer items-center gap-2 text-xs text-slate-300">
              <input
                type="checkbox"
                checked={embedCompact}
                onChange={(e) => setEmbedCompact(e.target.checked)}
                className="h-4 w-4 accent-emerald-500"
              />
              <span>Chế độ gọn cho Google Sites (ẩn thanh header &amp; footer trùng lặp qua <code className="font-mono text-emerald-400">?embed=1</code>)</span>
            </label>

            <div className="mt-4 space-y-3">
              <div>
                <div className="mb-1 flex items-center justify-between text-xs font-semibold text-slate-300">
                  <span>Cách 1 · Dán Theo URL (khuyên dùng)</span>
                  <button
                    type="button"
                    onClick={() => handleCopyGoogleSitesSnippet('url', googleSitesEmbedUrl)}
                    className="inline-flex items-center gap-1 rounded bg-emerald-600/20 px-2.5 py-1 text-[11px] font-semibold text-emerald-300 hover:bg-emerald-600/30"
                  >
                    {copiedType === 'url' ? <Check className="h-3 w-3" /> : <Copy className="h-3 w-3" />}
                    <span>{copiedType === 'url' ? 'Đã chép URL!' : 'Chép URL'}</span>
                  </button>
                </div>
                <input
                  type="text"
                  readOnly
                  value={googleSitesEmbedUrl}
                  aria-label="URL nhúng Google Sites"
                  onClick={(e) => e.currentTarget.select()}
                  className="w-full rounded-md border border-white/10 bg-[#0B0F17] px-3 py-2 font-mono text-xs text-emerald-300 focus:outline-none"
                />
              </div>

              <div>
                <div className="mb-1 flex items-center justify-between text-xs font-semibold text-slate-300">
                  <span>Cách 2 · Dán Mã nhúng HTML (iframe)</span>
                  <button
                    type="button"
                    onClick={() => handleCopyGoogleSitesSnippet('iframe', googleSitesIframeCode)}
                    className="inline-flex items-center gap-1 rounded bg-white/10 px-2.5 py-1 text-[11px] font-semibold text-slate-200 hover:bg-white/15"
                  >
                    {copiedType === 'iframe' ? <Check className="h-3 w-3 text-emerald-400" /> : <Copy className="h-3 w-3" />}
                    <span>{copiedType === 'iframe' ? 'Đã chép mã HTML!' : 'Chép mã iframe'}</span>
                  </button>
                </div>
                <textarea
                  readOnly
                  rows={3}
                  value={googleSitesIframeCode}
                  aria-label="Mã nhúng iframe Google Sites"
                  onClick={(e) => e.currentTarget.select()}
                  className="w-full rounded-md border border-white/10 bg-[#0B0F17] px-3 py-2 font-mono text-[11px] text-slate-300 focus:outline-none"
                />
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
