import React, { useEffect, useRef, useState } from 'react';
import { FastForward, Pause, Play, RefreshCw } from 'lucide-react';
import {
  PITCH_HEIGHT,
  PITCH_WIDTH,
  applyHalfTimeTalk,
  applyMatchSubstitution,
  applyTouchlineShout,
  createLiveMatchState,
  stepMatchTick,
} from '../engine/matchEngine';
import {
  CareerState,
  Fixture,
  LiveMatchState,
  TacticalMentality,
} from '../types/fm';
import { soundFX } from '../utils/audio';
import { ClubCrest } from './ClubCrest';

interface MatchDayViewProps {
  career: CareerState;
  fixture: Fixture;
  onUpdateMentality: (clubId: string, mentality: TacticalMentality) => void;
  onFinishMatch: (finalState: LiveMatchState) => void;
}

export const MatchDayView: React.FC<MatchDayViewProps> = ({
  career,
  fixture,
  onUpdateMentality,
  onFinishMatch,
}) => {
  const homeClub = career.clubs[fixture.homeClubId];
  const awayClub = career.clubs[fixture.awayClubId];
  const userTeam: 'home' | 'away' = fixture.homeClubId === career.userClubId ? 'home' : 'away';
  const userClub = userTeam === 'home' ? homeClub : awayClub;

  const [matchState, setMatchState] = useState<LiveMatchState>(() =>
    createLiveMatchState(fixture, homeClub, awayClub, career.players)
  );
  const [speed, setSpeed] = useState<0 | 1 | 2 | 4>(2);
  const [selectedSubOutId, setSelectedSubOutId] = useState<string | null>(null);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const matchRef = useRef(matchState);
  matchRef.current = matchState;

  const clubsRef = useRef({ homeClub, awayClub, players: career.players });
  clubsRef.current = { homeClub, awayClub, players: career.players };

  const prevScoreRef = useRef({ h: 0, a: 0, phase: matchState.phase });

  useEffect(() => {
    soundFX.playWhistle();
  }, []);

  // Sound cues for goals and phase changes
  useEffect(() => {
    const prev = prevScoreRef.current;
    if (matchState.homeScore !== prev.h || matchState.awayScore !== prev.a) {
      soundFX.playGoal();
    }
    if (matchState.phase !== prev.phase && (matchState.phase === 'half_time' || matchState.phase === 'full_time')) {
      soundFX.playWhistle();
    }
    prevScoreRef.current = {
      h: matchState.homeScore,
      a: matchState.awayScore,
      phase: matchState.phase,
    };
  }, [matchState.homeScore, matchState.awayScore, matchState.phase]);

  // Simulation loop
  useEffect(() => {
    if (speed === 0) return;
    if (matchState.phase === 'half_time' || matchState.phase === 'full_time') return;

    const intervalMs = speed === 4 ? 42 : speed === 2 ? 85 : 165;
    const timer = window.setInterval(() => {
      setMatchState((curr) =>
        stepMatchTick(
          curr,
          clubsRef.current.homeClub,
          clubsRef.current.awayClub,
          clubsRef.current.players
        )
      );
    }, intervalMs);

    return () => window.clearInterval(timer);
  }, [speed, matchState.phase]);

  // Canvas Renderer with ResizeObserver
  useEffect(() => {
    const canvas = canvasRef.current;
    const container = containerRef.current;
    if (!canvas || !container) return;

    const draw = () => {
      const rect = container.getBoundingClientRect();
      if (rect.width === 0 || rect.height === 0) return;
      const dpr = Math.min(window.devicePixelRatio || 1, 2);
      const targetW = Math.round(rect.width * dpr);
      const targetH = Math.round(rect.height * dpr);
      if (canvas.width !== targetW || canvas.height !== targetH) {
        canvas.width = targetW;
        canvas.height = targetH;
      }

      const ctx = canvas.getContext('2d');
      if (!ctx) return;
      ctx.save();
      ctx.scale(dpr, dpr);

      const w = rect.width;
      const h = rect.height;
      const pad = 16;
      const pw = w - pad * 2;
      const ph = h - pad * 2;

      const toX = (mx: number) => pad + (mx / PITCH_WIDTH) * pw;
      const toY = (my: number) => pad + (my / PITCH_HEIGHT) * ph;

      // Outer turf
      ctx.fillStyle = '#0F3D24';
      ctx.fillRect(0, 0, w, h);

      // Mowed vertical pitch stripes
      const stripeCount = 12;
      const stripeW = pw / stripeCount;
      for (let i = 0; i < stripeCount; i++) {
        ctx.fillStyle = i % 2 === 0 ? '#145331' : '#175E38';
        ctx.fillRect(pad + i * stripeW, pad, stripeW + 0.5, ph);
      }

      // Crisp white pitch lines
      ctx.strokeStyle = 'rgba(255,255,255,0.45)';
      ctx.lineWidth = 1.4;
      ctx.strokeRect(pad, pad, pw, ph);

      // Halfway line & center circle
      ctx.beginPath();
      ctx.moveTo(toX(PITCH_WIDTH / 2), pad);
      ctx.lineTo(toX(PITCH_WIDTH / 2), pad + ph);
      ctx.stroke();

      ctx.beginPath();
      ctx.arc(toX(PITCH_WIDTH / 2), toY(PITCH_HEIGHT / 2), (9.15 / PITCH_WIDTH) * pw, 0, Math.PI * 2);
      ctx.stroke();

      ctx.beginPath();
      ctx.arc(toX(PITCH_WIDTH / 2), toY(PITCH_HEIGHT / 2), 2.5, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(255,255,255,0.6)';
      ctx.fill();

      // Penalty areas (16.5m x 40.3m)
      const boxW = (16.5 / PITCH_WIDTH) * pw;
      const boxH = (40.3 / PITCH_HEIGHT) * ph;
      const boxTop = toY((PITCH_HEIGHT - 40.3) / 2);
      ctx.strokeRect(pad, boxTop, boxW, boxH);
      ctx.strokeRect(pad + pw - boxW, boxTop, boxW, boxH);

      // 6-yard boxes
      const smallW = (5.5 / PITCH_WIDTH) * pw;
      const smallH = (18.3 / PITCH_HEIGHT) * ph;
      const smallTop = toY((PITCH_HEIGHT - 18.3) / 2);
      ctx.strokeRect(pad, smallTop, smallW, smallH);
      ctx.strokeRect(pad + pw - smallW, smallTop, smallW, smallH);

      // Goal nets
      ctx.fillStyle = 'rgba(255,255,255,0.18)';
      const goalH = (7.32 / PITCH_HEIGHT) * ph;
      const goalTop = toY((PITCH_HEIGHT - 7.32) / 2);
      ctx.fillRect(pad - 6, goalTop, 6, goalH);
      ctx.fillRect(pad + pw, goalTop, 6, goalH);

      const st = matchRef.current;

      // Ball trail
      if (st.ball.trail.length > 1) {
        ctx.beginPath();
        st.ball.trail.forEach((pt, idx) => {
          const px = toX(pt.x);
          const py = toY(pt.y);
          if (idx === 0) ctx.moveTo(px, py);
          else ctx.lineTo(px, py);
        });
        ctx.strokeStyle = 'rgba(255,255,255,0.35)';
        ctx.lineWidth = 2;
        ctx.stroke();
      }

      // Draw 22 players
      const radius = Math.max(7.5, Math.min(11.5, pw * 0.0145));
      for (const ag of st.agents) {
        if (ag.redCard) continue;
        const cx = toX(ag.x);
        const cy = toY(ag.y);
        const isHome = ag.team === 'home';
        const fillCol = isHome ? homeClub.primaryColor : awayClub.primaryColor;
        const borderCol = isHome ? homeClub.secondaryColor : awayClub.secondaryColor;

        // Carrier highlight ring
        if (st.ball.ownerId === ag.playerId) {
          ctx.beginPath();
          ctx.arc(cx, cy, radius + 4, 0, Math.PI * 2);
          ctx.strokeStyle = '#FACC15';
          ctx.lineWidth = 2;
          ctx.stroke();
        }

        // Player disc
        ctx.beginPath();
        ctx.arc(cx, cy, radius, 0, Math.PI * 2);
        ctx.fillStyle = fillCol;
        ctx.fill();
        ctx.lineWidth = 2;
        ctx.strokeStyle = borderCol === fillCol ? '#0B0F17' : borderCol;
        ctx.stroke();

        // Shirt number
        const isLightKit =
          fillCol.toUpperCase() === '#FFFFFF' ||
          fillCol.toUpperCase() === '#FDE100' ||
          fillCol.toUpperCase() === '#FFE667' ||
          fillCol.toUpperCase() === '#FFE100' ||
          fillCol.toUpperCase() === '#FFD100';
        ctx.fillStyle = isLightKit ? '#0F172A' : '#FFFFFF';
        ctx.font = `700 ${Math.round(radius * 0.95)}px JetBrains Mono, monospace`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(String(ag.shirtNumber), cx, cy + 0.5);

        // Name tag for ball carrier or scorers
        if (st.ball.ownerId === ag.playerId) {
          const shortN = ag.name.split(' ').slice(-1)[0];
          ctx.font = '600 10px Plus Jakarta Sans, sans-serif';
          ctx.fillStyle = 'rgba(11,15,23,0.85)';
          const tw = ctx.measureText(shortN).width + 8;
          ctx.fillRect(cx - tw / 2, cy + radius + 3, tw, 14);
          ctx.fillStyle = '#F8FAFC';
          ctx.fillText(shortN, cx, cy + radius + 10);
        }
      }

      // Draw Ball
      const bx = toX(st.ball.x);
      const by = toY(st.ball.y);
      ctx.beginPath();
      ctx.arc(bx, by, 4.8, 0, Math.PI * 2);
      ctx.fillStyle = '#FFFFFF';
      ctx.fill();
      ctx.lineWidth = 1.3;
      ctx.strokeStyle = '#0F172A';
      ctx.stroke();

      ctx.restore();
    };

    draw();
    const ro = new ResizeObserver(draw);
    ro.observe(container);
    return () => ro.disconnect();
  }, [matchState, homeClub, awayClub]);

  const handleFastFinish = () => {
    let curr = matchState;
    if (curr.phase === 'half_time') {
      curr = applyHalfTimeTalk(curr, userTeam, 'encourage');
    }
    let guard = 0;
    while (curr.phase !== 'full_time' && guard < 1500) {
      curr = stepMatchTick(curr, homeClub, awayClub, career.players);
      if (curr.phase === 'half_time') {
        curr = applyHalfTimeTalk(curr, userTeam, 'encourage');
      }
      guard++;
    }
    setMatchState(curr);
  };

  const totalPoss = Math.max(1, matchState.stats.homePossessionTicks + matchState.stats.awayPossessionTicks);
  const homePossPct = Math.round((matchState.stats.homePossessionTicks / totalPoss) * 100);
  const awayPossPct = 100 - homePossPct;

  const userAgents = matchState.agents.filter((a) => a.team === userTeam && !a.redCard);
  const userBenchIds = userTeam === 'home' ? matchState.homeBenchIds : matchState.awayBenchIds;
  const subsUsed = userTeam === 'home' ? matchState.homeSubsUsed : matchState.awaySubsUsed;

  return (
    <div className="min-h-screen bg-[#0B0F17] p-4 text-slate-100 lg:p-6">
      <div className="mx-auto max-w-[1380px] space-y-4">
        {/* Top Broadcast Scoreboard */}
        <header className="flex flex-wrap items-center justify-between gap-4 rounded-lg border border-white/10 bg-[#121822] px-5 py-3.5 tabular-nums">
          <div className="flex items-center gap-3">
            <ClubCrest
              primaryColor={homeClub.primaryColor}
              secondaryColor={homeClub.secondaryColor}
              pattern={homeClub.crestPattern}
              shortName={homeClub.shortName}
              size={38}
            />
            <div>
              <div className="font-display text-xl font-bold text-white">{homeClub.name}</div>
              <div className="text-[11px] text-slate-400">
                Chủ nhà · {homeClub.tactics.formation}
              </div>
            </div>
          </div>

          <div className="flex items-center gap-5">
            <div className="font-display text-4xl font-extrabold text-white">{matchState.homeScore}</div>
            <div className="flex flex-col items-center">
              <div className="rounded bg-emerald-600/20 px-3 py-1 font-mono text-base font-bold text-emerald-400">
                {matchState.minute}&apos;
              </div>
              <div className="mt-0.5 text-[11px] text-slate-400">
                {matchState.phase === 'first_half'
                  ? 'Hiệp 1'
                  : matchState.phase === 'half_time'
                  ? 'Nghỉ giữa hiệp'
                  : matchState.phase === 'second_half'
                  ? 'Hiệp 2'
                  : 'Hết giờ'}
              </div>
            </div>
            <div className="font-display text-4xl font-extrabold text-white">{matchState.awayScore}</div>
          </div>

          <div className="flex items-center gap-3">
            <div className="text-right">
              <div className="font-display text-xl font-bold text-white">{awayClub.name}</div>
              <div className="text-[11px] text-slate-400">
                Đội khách · {awayClub.tactics.formation}
              </div>
            </div>
            <ClubCrest
              primaryColor={awayClub.primaryColor}
              secondaryColor={awayClub.secondaryColor}
              pattern={awayClub.crestPattern}
              shortName={awayClub.shortName}
              size={38}
            />
          </div>
        </header>

        {/* Speed & Touchline Control Bar */}
        <div className="flex flex-wrap items-center justify-between gap-3 rounded-lg border border-white/10 bg-[#121822] px-4 py-2.5">
          <div className="flex items-center gap-1.5">
            <button
              type="button"
              onClick={() => setSpeed((s) => (s === 0 ? 2 : 0))}
              className="flex items-center gap-1.5 rounded bg-[#0B0F17] px-3 py-1.5 text-xs font-semibold text-white hover:bg-white/10"
            >
              {speed === 0 ? <Play className="h-3.5 w-3.5" /> : <Pause className="h-3.5 w-3.5" />}
              <span>{speed === 0 ? 'Tiếp tục' : 'Tạm dừng'}</span>
            </button>
            {([1, 2, 4] as const).map((spd) => (
              <button
                key={spd}
                type="button"
                onClick={() => setSpeed(spd)}
                className={`rounded px-2.5 py-1.5 font-mono text-xs font-bold transition-colors ${
                  speed === spd ? 'bg-emerald-600 text-white' : 'bg-[#0B0F17] text-slate-400 hover:text-white'
                }`}
              >
                {spd}x
              </button>
            ))}
            <button
              type="button"
              onClick={handleFastFinish}
              disabled={matchState.phase === 'full_time'}
              className="ml-1 flex items-center gap-1.5 rounded border border-white/15 px-3 py-1.5 text-xs font-semibold text-slate-200 hover:bg-white/5 disabled:opacity-40"
            >
              <FastForward className="h-3.5 w-3.5" />
              <span>Kết thúc nhanh</span>
            </button>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <label htmlFor="live-mentality" className="text-xs text-slate-400">
              Tâm lý:
            </label>
            <select
              id="live-mentality"
              value={userClub.tactics.mentality}
              onChange={(e) => onUpdateMentality(userClub.id, e.target.value as TacticalMentality)}
              className="rounded border border-white/15 bg-[#0B0F17] px-2.5 py-1 text-xs font-semibold text-white"
            >
              {(['Rất phòng ngự', 'Phòng ngự', 'Cân bằng', 'Tấn công', 'Tổng lực'] as TacticalMentality[]).map(
                (m) => (
                  <option key={m} value={m}>
                    {m}
                  </option>
                )
              )}
            </select>

            {(['Hét cổ vũ', 'Tập trung phòng ngự', 'Đẩy cao pressing'] as const).map((shout) => (
              <button
                key={shout}
                type="button"
                disabled={matchState.userShoutCooldown > 0 || matchState.phase === 'full_time'}
                onClick={() => setMatchState((s) => applyTouchlineShout(s, userTeam, shout))}
                className="rounded border border-emerald-500/35 bg-emerald-500/10 px-2.5 py-1 text-xs font-semibold text-emerald-300 hover:bg-emerald-500/20 disabled:opacity-40 whitespace-nowrap"
              >
                {shout}
              </button>
            ))}
          </div>
        </div>

        {/* Main Match Grid: 2D Canvas Pitch + Live Stats/Commentary + Substitutions */}
        <div className="grid grid-cols-1 gap-5 lg:grid-cols-12">
          {/* 2D Live Pitch Canvas */}
          <div className="space-y-4 lg:col-span-8">
            <div
              ref={containerRef}
              data-testid="match-pitch-canvas-container"
              className="relative aspect-[105/68] w-full overflow-hidden rounded-lg border border-white/15 bg-[#0F3D24]"
            >
              <canvas ref={canvasRef} className="block h-full w-full" />

              {matchState.goalBanner && (
                <div className="pointer-events-none absolute inset-x-0 top-6 flex justify-center">
                  <div className="rounded-md border border-amber-400 bg-[#0B0F17]/95 px-6 py-2.5 text-center shadow-lg">
                    <div className="font-display text-2xl font-extrabold tracking-wide text-amber-400">
                      VÀO!! {matchState.goalBanner.minute}&apos;
                    </div>
                    <div className="text-sm font-bold text-white">
                      {matchState.goalBanner.scorerName}
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Live Stats Strip */}
            <div className="grid grid-cols-3 gap-3 rounded-lg border border-white/10 bg-[#121822] p-4 text-xs tabular-nums sm:grid-cols-6">
              <StatPair label="Kiểm soát" left={`${homePossPct}%`} right={`${awayPossPct}%`} />
              <StatPair label="xG" left={matchState.stats.homeXg.toFixed(2)} right={matchState.stats.awayXg.toFixed(2)} />
              <StatPair label="Dứt điểm" left={matchState.stats.homeShots} right={matchState.stats.awayShots} />
              <StatPair label="Trúng đích" left={matchState.stats.homeShotsOnTarget} right={matchState.stats.awayShotsOnTarget} />
              <StatPair label="Phạt góc" left={matchState.stats.homeCorners} right={matchState.stats.awayCorners} />
              <StatPair label="Phạm lỗi" left={matchState.stats.homeFouls} right={matchState.stats.awayFouls} />
            </div>
          </div>

          {/* Right Panel: Commentary & Substitutions */}
          <div className="space-y-4 lg:col-span-4">
            <section className="rounded-lg border border-white/10 bg-[#121822]">
              <div className="border-b border-white/10 px-4 py-2.5">
                <h2 className="font-display text-lg font-bold text-white">Diễn biến trực tiếp</h2>
              </div>
              <div className="max-h-[250px] divide-y divide-white/5 overflow-y-auto p-3 text-xs">
                {matchState.events.map((ev) => (
                  <div key={ev.id} className="flex gap-2.5 py-2">
                    <span className="w-8 shrink-0 font-mono font-bold text-emerald-400 tabular-nums">
                      {ev.minute}&apos;
                    </span>
                    <span
                      className={
                        ev.type === 'goal'
                          ? 'font-bold text-amber-300'
                          : ev.type === 'red_card'
                          ? 'font-bold text-rose-400'
                          : 'text-slate-300'
                      }
                    >
                      {ev.text}
                    </span>
                  </div>
                ))}
              </div>
            </section>

            {/* Live Substitutions */}
            <section className="rounded-lg border border-white/10 bg-[#121822] p-4">
              <div className="mb-2.5 flex items-center justify-between">
                <h2 className="font-display text-lg font-bold text-white">
                  Thay người ({subsUsed}/5)
                </h2>
                {selectedSubOutId && (
                  <button
                    type="button"
                    onClick={() => setSelectedSubOutId(null)}
                    className="text-xs text-amber-400 hover:underline"
                  >
                    Hủy chọn
                  </button>
                )}
              </div>

              {!selectedSubOutId ? (
                <div className="max-h-[220px] space-y-1 overflow-y-auto pr-1 text-xs tabular-nums">
                  <div className="mb-1 text-[11px] text-slate-400">
                    Chọn cầu thủ đang trên sân cần rút ra:
                  </div>
                  {userAgents.map((ag) => (
                    <button
                      key={ag.playerId}
                      type="button"
                      disabled={subsUsed >= 5 || matchState.phase === 'full_time'}
                      onClick={() => setSelectedSubOutId(ag.playerId)}
                      className="flex w-full items-center justify-between rounded bg-[#0B0F17] px-2.5 py-1.5 text-left hover:bg-white/5 disabled:opacity-45"
                    >
                      <span className="truncate font-medium text-white">
                        {ag.position} · {ag.name}
                      </span>
                      <span
                        className={`font-mono font-semibold ${
                          ag.stamina >= 70 ? 'text-emerald-400' : ag.stamina >= 50 ? 'text-amber-400' : 'text-rose-400'
                        }`}
                      >
                        {Math.round(ag.stamina)}%
                      </span>
                    </button>
                  ))}
                </div>
              ) : (
                <div className="max-h-[220px] space-y-1 overflow-y-auto pr-1 text-xs tabular-nums">
                  <div className="mb-1 text-[11px] text-emerald-400">
                    Chọn cầu thủ dự bị vào sân:
                  </div>
                  {userBenchIds.length === 0 ? (
                    <p className="text-slate-400">Không còn cầu thủ dự bị khả dụng.</p>
                  ) : (
                    userBenchIds.map((bid) => {
                      const bp = career.players[bid];
                      if (!bp) return null;
                      return (
                        <button
                          key={bid}
                          type="button"
                          onClick={() => {
                            setMatchState((s) => applyMatchSubstitution(s, userTeam, selectedSubOutId, bp));
                            setSelectedSubOutId(null);
                          }}
                          className="flex w-full items-center justify-between rounded border border-emerald-500/30 bg-emerald-500/10 px-2.5 py-1.5 text-left hover:bg-emerald-500/20"
                        >
                          <span className="truncate font-semibold text-white">
                            {bp.primaryPosition} · {bp.name}
                          </span>
                          <span className="font-mono font-bold text-emerald-400">OVR {bp.ovr}</span>
                        </button>
                      );
                    })
                  )}
                </div>
              )}
            </section>
          </div>
        </div>
      </div>

      {/* Half-Time Team Talk Modal */}
      {matchState.phase === 'half_time' && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 p-4"
          role="dialog"
          aria-modal="true"
          aria-label="Chỉ đạo giờ nghỉ giữa hiệp"
        >
          <div className="w-full max-w-md rounded-lg border border-white/15 bg-[#121822] p-6">
            <h2 className="font-display text-2xl font-bold text-white">
              Nghỉ Giữa Hiệp · {homeClub.shortName} {matchState.homeScore} - {matchState.awayScore} {awayClub.shortName}
            </h2>
            <p className="mt-2 text-xs text-slate-400">
              Chọn thông điệp chỉ đạo trong phòng thay đồ trước khi bước vào hiệp 2:
            </p>
            <div className="mt-4 space-y-2.5">
              <button
                type="button"
                onClick={() => setMatchState((s) => applyHalfTimeTalk(s, userTeam, 'encourage'))}
                className="w-full rounded-md border border-white/15 bg-[#0B0F17] p-3 text-left text-xs font-semibold text-white hover:border-emerald-500"
              >
                Động viên tinh thần — &quot;Các bạn đang chơi tốt, hãy tiếp tục giữ nhịp độ!&quot;
              </button>
              <button
                type="button"
                onClick={() => setMatchState((s) => applyHalfTimeTalk(s, userTeam, 'demand'))}
                className="w-full rounded-md border border-white/15 bg-[#0B0F17] p-3 text-left text-xs font-semibold text-white hover:border-amber-500"
              >
                Yêu cầu quyết liệt hơn — &quot;Tôi muốn thấy nhiều khát khao hơn trong hiệp 2!&quot;
              </button>
              <button
                type="button"
                onClick={() => setMatchState((s) => applyHalfTimeTalk(s, userTeam, 'calm'))}
                className="w-full rounded-md border border-white/15 bg-[#0B0F17] p-3 text-left text-xs font-semibold text-white hover:border-sky-500"
              >
                Giữ cái đầu lạnh — &quot;Bình tĩnh kiểm soát bóng và hạn chế sai lầm cá nhân.&quot;
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Full-Time Match Report Modal */}
      {matchState.phase === 'full_time' && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4"
          role="dialog"
          aria-modal="true"
          aria-label="Kết quả chung cuộc"
        >
          <div className="w-full max-w-md rounded-lg border border-white/15 bg-[#121822] p-6 text-center">
            <div className="text-xs font-semibold uppercase tracking-wider text-emerald-400">
              Hết Giờ · Vòng {fixture.round}
            </div>
            <div className="mt-2 font-display text-4xl font-extrabold text-white tabular-nums">
              {homeClub.shortName} {matchState.homeScore} - {matchState.awayScore} {awayClub.shortName}
            </div>
            <div className="mt-4 grid grid-cols-3 gap-3 rounded-md bg-[#0B0F17] p-3 text-xs tabular-nums">
              <div>
                <div className="text-slate-400">xG</div>
                <div className="font-mono font-bold text-white">
                  {matchState.stats.homeXg.toFixed(2)} - {matchState.stats.awayXg.toFixed(2)}
                </div>
              </div>
              <div>
                <div className="text-slate-400">Kiểm soát</div>
                <div className="font-mono font-bold text-white">
                  {homePossPct}% - {awayPossPct}%
                </div>
              </div>
              <div>
                <div className="text-slate-400">Dứt điểm</div>
                <div className="font-mono font-bold text-white">
                  {matchState.stats.homeShots} - {matchState.stats.awayShots}
                </div>
              </div>
            </div>
            <button
              type="button"
              onClick={() => onFinishMatch(matchState)}
              className="mt-5 flex w-full items-center justify-center gap-2 rounded-md bg-emerald-600 px-5 py-3 text-sm font-bold text-white transition-colors hover:bg-emerald-500"
            >
              <RefreshCw className="h-4 w-4" />
              <span>Lưu kết quả & Quay về Văn phòng</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

const StatPair: React.FC<{ label: string; left: string | number; right: string | number }> = ({
  label,
  left,
  right,
}) => (
  <div className="text-center">
    <div className="text-[11px] text-slate-400">{label}</div>
    <div className="mt-0.5 font-mono text-sm font-bold text-white">
      {left} <span className="text-slate-500">/</span> {right}
    </div>
  </div>
);
