import { useEffect, useState } from 'react';
import { AppShell } from './components/AppShell';
import { CompetitionsView } from './components/CompetitionsView';
import { InboxView } from './components/InboxView';
import { MatchDayView } from './components/MatchDayView';
import { SeasonSummaryModal } from './components/SeasonSummaryModal';
import { SquadView } from './components/SquadView';
import { TacticsView } from './components/TacticsView';
import { TitleScreen } from './components/TitleScreen';
import { BoardFinanceView, TrainingView } from './components/TrainingBoardView';
import { TransfersView } from './components/TransfersView';
import { LEAGUES, LEAGUE_ORDER } from './data/database';
import {
  ClubChoice,
  advanceOneDay,
  advanceToNextSeason,
  commitUserMatchResult,
  computeSeasonSummary,
  createNewCareer,
  getNextUserFixture,
  isUserSeasonFinished,
} from './engine/schedule';
import { executeTransfer } from './engine/transfers';
import {
  CareerState,
  Fixture,
  GameScreen,
  LiveMatchState,
  SquadRole,
  TacticalMentality,
  TeamTactics,
  TrainingFocus,
  TrainingIntensity,
  WorkspaceTab,
} from './types/fm';
import { soundFX } from './utils/audio';

const STORAGE_KEY = 'touchline_fm_save_v2';

function loadSavedCareer(): CareerState | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as CareerState;
    if (parsed && parsed.userClubId && parsed.clubs?.[parsed.userClubId] && parsed.fixturesByLeague) {
      return {
        ...parsed,
        countryLeagueId: parsed.countryLeagueId ?? parsed.activeLeagueId,
        leagueOrder: parsed.leagueOrder?.length ? parsed.leagueOrder : LEAGUE_ORDER,
        leagues: parsed.leagues ?? LEAGUES,
        seasonHistory: parsed.seasonHistory ?? [],
      };
    }
    return null;
  } catch {
    return null;
  }
}

export default function App() {
  const [savedCareer, setSavedCareer] = useState<CareerState | null>(() => loadSavedCareer());
  const [career, setCareer] = useState<CareerState | null>(() => {
    if (typeof window !== 'undefined') {
      const params = new URLSearchParams(window.location.search);
      if (params.get('autostart') === '1') {
        return createNewCareer('HLV Minh Duy', { type: 'existing', clubId: 'ars' });
      }
    }
    return null;
  });

  const [screen, setScreen] = useState<GameScreen>(() => (career ? 'workspace' : 'title'));
  const [activeTab, setActiveTab] = useState<WorkspaceTab>('inbox');
  const [activeMatchFixture, setActiveMatchFixture] = useState<Fixture | null>(null);
  const [seasonSummaryOpen, setSeasonSummaryOpen] = useState<boolean>(false);
  const [muted, setMuted] = useState<boolean>(false);

  // Sync document.body.dataset.state for testability & game shell hygiene
  useEffect(() => {
    if (screen === 'title') document.body.dataset.state = 'title';
    else if (screen === 'match') document.body.dataset.state = 'match';
    else document.body.dataset.state = 'playing';
  }, [screen]);

  // Persist career automatically
  useEffect(() => {
    if (career) {
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(career));
        setSavedCareer(career);
      } catch {
        // Ignore storage quota errors
      }
    }
  }, [career]);

  const handleToggleMute = () => {
    setMuted((m) => {
      const next = !m;
      soundFX.muted = next;
      return next;
    });
  };

  const handleStartCareer = (managerName: string, choice: ClubChoice) => {
    soundFX.playClick();
    const fresh = createNewCareer(managerName, choice);
    setCareer(fresh);
    setActiveTab('inbox');
    setScreen('workspace');
  };

  const handleResumeCareer = () => {
    if (!savedCareer) return;
    soundFX.playClick();
    setCareer(savedCareer);
    setActiveTab('inbox');
    setScreen('workspace');
  };

  const handleResetCareer = () => {
    soundFX.playClick();
    setScreen('title');
  };

  const handleContinueDay = () => {
    if (!career) return;
    soundFX.playClick();
    const { nextState, matchReadyFixture } = advanceOneDay(career);
    setCareer(nextState);
    if (matchReadyFixture) {
      setActiveTab('inbox');
    }
  };

  const handleContinueToMatch = () => {
    if (!career) return;
    soundFX.playClick();
    let curr = career;
    let guard = 0;
    while (guard < 14) {
      const nextFix = getNextUserFixture(curr);
      if (!nextFix) break;
      if (nextFix.dateISO <= curr.currentDateISO) break;
      const { nextState, matchReadyFixture } = advanceOneDay(curr);
      curr = nextState;
      if (matchReadyFixture) break;
      guard++;
    }
    setCareer(curr);
  };

  const handleStartMatch = () => {
    if (!career) return;
    const nextFix = getNextUserFixture(career);
    if (!nextFix) return;
    soundFX.playClick();
    setActiveMatchFixture(nextFix);
    setScreen('match');
  };

  const handleFinishMatch = (finalState: LiveMatchState) => {
    if (!career) return;
    soundFX.playClick();
    const updated = commitUserMatchResult(career, finalState);
    setCareer(updated);
    setActiveMatchFixture(null);
    setActiveTab('inbox');
    setScreen('workspace');
    if (isUserSeasonFinished(updated)) {
      setSeasonSummaryOpen(true);
    }
  };

  const handleAdvanceSeason = () => {
    if (!career) return;
    soundFX.playClick();
    const { nextState } = advanceToNextSeason(career);
    setCareer(nextState);
    setSeasonSummaryOpen(false);
    setActiveTab('inbox');
  };

  const handleUpdateTactics = (nextTactics: TeamTactics) => {
    if (!career) return;
    const club = career.clubs[career.userClubId];
    setCareer({
      ...career,
      clubs: {
        ...career.clubs,
        [club.id]: {
          ...club,
          tactics: nextTactics,
        },
      },
    });
  };

  const handleUpdateMentality = (clubId: string, mentality: TacticalMentality) => {
    if (!career) return;
    const club = career.clubs[clubId];
    if (!club) return;
    setCareer({
      ...career,
      clubs: {
        ...career.clubs,
        [clubId]: {
          ...club,
          tactics: {
            ...club.tactics,
            mentality,
          },
        },
      },
    });
  };

  const handleToggleTransferList = (playerId: string) => {
    if (!career) return;
    const p = career.players[playerId];
    if (!p) return;
    setCareer({
      ...career,
      players: {
        ...career.players,
        [playerId]: { ...p, transferListed: !p.transferListed },
      },
    });
  };

  const handleRenewContract = (playerId: string, newWage: number, extraYears: number) => {
    if (!career) return;
    const p = career.players[playerId];
    if (!p) return;
    setCareer({
      ...career,
      players: {
        ...career.players,
        [playerId]: {
          ...p,
          weeklyWage: newWage,
          contractUntilYear: p.contractUntilYear + extraYears,
          morale: Math.min(100, p.morale + 8),
        },
      },
    });
  };

  const handleToggleShortlist = (playerId: string) => {
    if (!career) return;
    const exists = career.shortlistIds.includes(playerId);
    setCareer({
      ...career,
      shortlistIds: exists
        ? career.shortlistIds.filter((id) => id !== playerId)
        : [...career.shortlistIds, playerId],
    });
  };

  const handleCompleteTransfer = (
    playerId: string,
    fee: number,
    newWage: number,
    contractYears: number,
    newRole: SquadRole
  ) => {
    if (!career) return;
    soundFX.playClick();
    setCareer(executeTransfer(career, playerId, career.userClubId, fee, newWage, contractYears, newRole));
  };

  const handleUpdateTraining = (focus: TrainingFocus, intensity: TrainingIntensity) => {
    if (!career) return;
    setCareer({
      ...career,
      trainingFocus: focus,
      trainingIntensity: intensity,
    });
  };

  const handleShiftBudget = (deltaMillions: number) => {
    if (!career) return;
    const club = career.clubs[career.userClubId];
    const nextTransfer = Math.round((club.finances.transferBudget + deltaMillions) * 10) / 10;
    const nextWage = club.finances.wageBudgetWeekly - deltaMillions * 20;
    if (nextTransfer < 0 || nextWage < 100) return;

    setCareer({
      ...career,
      clubs: {
        ...career.clubs,
        [club.id]: {
          ...club,
          finances: {
            ...club.finances,
            transferBudget: nextTransfer,
            wageBudgetWeekly: nextWage,
          },
        },
      },
    });
  };

  const handleMarkRead = (msgId: string) => {
    if (!career) return;
    setCareer({
      ...career,
      inbox: career.inbox.map((m) => (m.id === msgId ? { ...m, read: true } : m)),
    });
  };

  const handleMarkAllRead = () => {
    if (!career) return;
    setCareer({
      ...career,
      inbox: career.inbox.map((m) => ({ ...m, read: true })),
    });
  };

  if (screen === 'title' || !career) {
    const savedClubLabel = savedCareer
      ? `${savedCareer.clubs[savedCareer.userClubId]?.name ?? ''} · ${savedCareer.managerName}`
      : undefined;
    return (
      <TitleScreen
        hasSavedCareer={Boolean(savedCareer)}
        savedClubLabel={savedClubLabel}
        onResumeCareer={handleResumeCareer}
        onStartCareer={handleStartCareer}
      />
    );
  }

  if (screen === 'match' && activeMatchFixture) {
    return (
      <MatchDayView
        career={career}
        fixture={activeMatchFixture}
        onUpdateMentality={handleUpdateMentality}
        onFinishMatch={handleFinishMatch}
      />
    );
  }

  const seasonPreview =
    seasonSummaryOpen && career ? computeSeasonSummary(career).preview : null;

  return (
    <AppShell
      career={career}
      activeTab={activeTab}
      onSelectTab={(t) => {
        soundFX.playClick();
        setActiveTab(t);
      }}
      onContinueDay={handleContinueDay}
      onStartMatch={handleStartMatch}
      onOpenSeasonSummary={() => setSeasonSummaryOpen(true)}
      onResetCareer={handleResetCareer}
      muted={muted}
      onToggleMute={handleToggleMute}
    >
      {activeTab === 'inbox' && (
        <InboxView
          career={career}
          onMarkRead={handleMarkRead}
          onMarkAllRead={handleMarkAllRead}
          onNavigateTab={setActiveTab}
          onStartMatch={handleStartMatch}
          onContinueToMatch={handleContinueToMatch}
          onOpenSeasonSummary={() => setSeasonSummaryOpen(true)}
        />
      )}
      {activeTab === 'squad' && (
        <SquadView
          career={career}
          onToggleTransferList={handleToggleTransferList}
          onRenewContract={handleRenewContract}
        />
      )}
      {activeTab === 'tactics' && (
        <TacticsView career={career} onUpdateTactics={handleUpdateTactics} />
      )}
      {activeTab === 'competitions' && <CompetitionsView career={career} />}
      {activeTab === 'transfers' && (
        <TransfersView
          career={career}
          onToggleShortlist={handleToggleShortlist}
          onCompleteTransfer={handleCompleteTransfer}
        />
      )}
      {activeTab === 'training' && (
        <TrainingView career={career} onUpdateTraining={handleUpdateTraining} />
      )}
      {activeTab === 'board' && (
        <BoardFinanceView career={career} onShiftBudget={handleShiftBudget} />
      )}

      {seasonPreview && (
        <SeasonSummaryModal
          preview={seasonPreview}
          clubName={career.clubs[career.userClubId]?.name ?? ''}
          onClose={() => setSeasonSummaryOpen(false)}
          onAdvanceSeason={handleAdvanceSeason}
        />
      )}
    </AppShell>
  );
}
