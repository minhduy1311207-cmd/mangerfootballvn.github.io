import {
  LEAGUES,
  LEAGUE_ORDER,
  createInitialDatabase,
} from '../data/database';
import { attachCountryPyramid } from '../data/lowerLeagues';
import {
  CareerState,
  Club,
  CustomClubConfig,
  Fixture,
  LeagueDefinition,
  LeagueId,
  LeagueStandingRow,
  LiveMatchState,
  Player,
  SeasonRecord,
} from '../types/fm';
import { resolveAIMatchFast } from './matchEngine';
import { calculateTeamRatings } from './tactics';

export function getLeagueDef(state: CareerState, leagueId: LeagueId): LeagueDefinition {
  return state.leagues?.[leagueId] ?? LEAGUES[leagueId];
}

export function getLeagueOrder(state: CareerState): LeagueId[] {
  return state.leagueOrder?.length ? state.leagueOrder : LEAGUE_ORDER;
}

export function isUserSeasonFinished(state: CareerState): boolean {
  const list = state.fixturesByLeague[state.activeLeagueId] ?? [];
  return list.length > 0 && !getNextUserFixture(state);
}

export function addDaysISO(dateISO: string, days: number): string {
  const [y, m, d] = dateISO.split('-').map(Number);
  const dt = new Date(Date.UTC(y, m - 1, d + days));
  return dt.toISOString().slice(0, 10);
}

export function formatDateVN(dateISO: string): string {
  const [y, m, d] = dateISO.split('-').map(Number);
  return `${String(d).padStart(2, '0')}/${String(m).padStart(2, '0')}/${y}`;
}

export function generateLeagueFixtures(
  clubIds: string[],
  leagueId: LeagueId,
  firstMatchDateISO = '2026-08-15'
): Fixture[] {
  const teams = [...clubIds];
  if (teams.length % 2 === 1) teams.push('BYE');
  const n = teams.length;
  const roundsFirstHalf = n - 1;
  const fixtures: Fixture[] = [];

  const rotating = teams.slice(1);
  const fixed = teams[0];

  // First half
  for (let r = 0; r < roundsFirstHalf; r++) {
    const roundNum = r + 1;
    const dateISO = addDaysISO(firstMatchDateISO, r * 7);
    const roundList = [fixed, ...rotating];
    for (let i = 0; i < n / 2; i++) {
      const a = roundList[i];
      const b = roundList[n - 1 - i];
      if (a === 'BYE' || b === 'BYE') continue;
      const swap = (r + i) % 2 === 1;
      const home = swap ? b : a;
      const away = swap ? a : b;
      fixtures.push({
        id: `${leagueId}_r${roundNum}_${home}_${away}`,
        leagueId,
        round: roundNum,
        dateISO,
        homeClubId: home,
        awayClubId: away,
        played: false,
        homeGoals: null,
        awayGoals: null,
      });
    }
    const last = rotating.pop()!;
    rotating.unshift(last);
  }

  // Second half (reversed home/away)
  const firstHalfCount = fixtures.length;
  for (let i = 0; i < firstHalfCount; i++) {
    const f = fixtures[i];
    const roundNum = f.round + roundsFirstHalf;
    const dateISO = addDaysISO(firstMatchDateISO, (roundNum - 1) * 7);
    fixtures.push({
      id: `${leagueId}_r${roundNum}_${f.awayClubId}_${f.homeClubId}`,
      leagueId,
      round: roundNum,
      dateISO,
      homeClubId: f.awayClubId,
      awayClubId: f.homeClubId,
      played: false,
      homeGoals: null,
      awayGoals: null,
    });
  }

  return fixtures;
}

export function createInitialStandings(clubIds: string[]): LeagueStandingRow[] {
  return clubIds.map((clubId) => ({
    clubId,
    played: 0,
    won: 0,
    drawn: 0,
    lost: 0,
    gf: 0,
    ga: 0,
    gd: 0,
    points: 0,
    form: [],
  }));
}

export function sortStandings(
  rows: LeagueStandingRow[],
  clubs: Record<string, Club>
): LeagueStandingRow[] {
  return [...rows].sort((a, b) => {
    if (b.points !== a.points) return b.points - a.points;
    if (b.gd !== a.gd) return b.gd - a.gd;
    if (b.gf !== a.gf) return b.gf - a.gf;
    return (clubs[a.clubId]?.name ?? '').localeCompare(clubs[b.clubId]?.name ?? '');
  });
}

function applyFixtureToStandings(
  rows: LeagueStandingRow[],
  fixture: Fixture,
  clubs: Record<string, Club>
): LeagueStandingRow[] {
  if (!fixture.played || fixture.homeGoals === null || fixture.awayGoals === null) return rows;
  const hg = fixture.homeGoals;
  const ag = fixture.awayGoals;

  const updated = rows.map((row) => {
    if (row.clubId !== fixture.homeClubId && row.clubId !== fixture.awayClubId) return row;
    const isHome = row.clubId === fixture.homeClubId;
    const gf = isHome ? hg : ag;
    const ga = isHome ? ag : hg;
    const won = gf > ga ? 1 : 0;
    const drawn = gf === ga ? 1 : 0;
    const lost = gf < ga ? 1 : 0;
    const pts = won * 3 + drawn;
    const res: 'W' | 'D' | 'L' = won ? 'W' : drawn ? 'D' : 'L';
    return {
      ...row,
      played: row.played + 1,
      won: row.won + won,
      drawn: row.drawn + drawn,
      lost: row.lost + lost,
      gf: row.gf + gf,
      ga: row.ga + ga,
      gd: row.gd + (gf - ga),
      points: row.points + pts,
      form: [...row.form, res].slice(-5),
    };
  });

  return sortStandings(updated, clubs);
}

export type ClubChoice =
  | { type: 'existing'; clubId: string }
  | { type: 'custom'; config: CustomClubConfig };

export function createNewCareer(managerName: string, choice: ClubChoice): CareerState {
  const baseDb = createInitialDatabase();
  const countryLeagueId: LeagueId =
    choice.type === 'custom'
      ? choice.config.leagueId
      : baseDb.clubs[choice.clubId]?.leagueId ?? 'eng_pl';

  const pyramid = attachCountryPyramid(
    baseDb,
    countryLeagueId,
    choice.type === 'custom' ? choice.config : undefined
  );

  const userClubId =
    choice.type === 'custom' ? pyramid.customClubId! : choice.clubId;
  const userClub = pyramid.clubs[userClubId];
  const activeLeagueId = userClub.leagueId;
  const league = pyramid.leagues[activeLeagueId] ?? LEAGUES[activeLeagueId];
  const topLeague = pyramid.leagues[countryLeagueId] ?? LEAGUES[countryLeagueId];

  const fixturesByLeague: Record<string, Fixture[]> = {};
  const standingsByLeague: Record<string, LeagueStandingRow[]> = {};

  for (const lid of pyramid.leagueOrder) {
    const clubIds = Object.values(pyramid.clubs)
      .filter((c) => c.leagueId === lid)
      .map((c) => c.id);
    fixturesByLeague[lid] = generateLeagueFixtures(clubIds, lid, '2026-08-15');
    standingsByLeague[lid] = sortStandings(createInitialStandings(clubIds), pyramid.clubs);
  }

  const firstMatch = fixturesByLeague[activeLeagueId].find(
    (f) => f.homeClubId === userClubId || f.awayClubId === userClubId
  );
  const firstOppId = firstMatch
    ? firstMatch.homeClubId === userClubId
      ? firstMatch.awayClubId
      : firstMatch.homeClubId
    : '';
  const firstOpp = firstOppId ? pyramid.clubs[firstOppId] : undefined;

  const welcomeBody =
    choice.type === 'custom'
      ? `Hành trình lịch sử của ${userClub.name} chính thức bắt đầu từ hạng đấu thấp nhất — ${league.name} (${league.country}). Hãy giành Top 2 để thăng hạng từng bước tiến tới đỉnh cao ${topLeague.name}! Ngân sách chuyển nhượng khởi đầu: €${userClub.finances.transferBudget.toFixed(1)}M.`
      : `Ban lãnh đạo tin tưởng giao trọng trách dẫn dắt ${userClub.name} tại ${league.name}. Mục tiêu mùa giải: "${userClub.expectation}". Ngân sách chuyển nhượng hiện tại là €${userClub.finances.transferBudget.toFixed(1)}M và quỹ lương €${userClub.finances.wageBudgetWeekly}k/tuần.`;

  return {
    managerName: managerName.trim() || 'HLV Trưởng',
    userClubId,
    activeLeagueId,
    countryLeagueId,
    leagueOrder: pyramid.leagueOrder,
    leagues: pyramid.leagues,
    seasonNumber: 1,
    currentDateISO: '2026-08-10',
    clubs: pyramid.clubs,
    players: pyramid.players,
    fixturesByLeague,
    standingsByLeague,
    inbox: [
      {
        id: 'msg_welcome',
        dateISO: '2026-08-10',
        category: 'Ban lãnh đạo',
        sender: `Chủ tịch CLB ${userClub.name}`,
        subject:
          choice.type === 'custom'
            ? `Khởi đầu hành trình thăng hạng cùng ${userClub.name}`
            : `Chào mừng ${managerName.trim() || 'HLV'} nhậm chức tại ${userClub.name}`,
        body: welcomeBody,
        read: false,
      },
      ...(firstMatch && firstOpp
        ? [
            {
              id: 'msg_r1_brief',
              dateISO: '2026-08-10',
              category: 'Trinh sát' as const,
              sender: 'Trưởng bộ phận Trinh sát',
              subject: `Phân tích đối thủ Vòng 1: ${firstOpp.name}`,
              body: `Trận mở màn diễn ra ngày ${formatDateVN(firstMatch.dateISO)} (${firstMatch.homeClubId === userClubId ? 'Sân nhà ' + userClub.stadium : 'Sân khách ' + firstOpp.stadium}). ${firstOpp.name} thường vận hành sơ đồ ${firstOpp.tactics.formation} với lối đá ${firstOpp.tactics.mentality.toLowerCase()} và pressing ${firstOpp.tactics.pressing.toLowerCase()}.`,
              read: false,
              actionType: 'next_match' as const,
              relatedFixtureId: firstMatch.id,
            },
          ]
        : []),
    ],
    bids: [],
    shortlistIds: [],
    trainingFocus: 'Cân bằng tổng hợp',
    trainingIntensity: 'Trung bình',
    seasonHistory: [],
    history: {
      playedMatches: 0,
      wins: 0,
      draws: 0,
      losses: 0,
    },
  };
}

export function getNextUserFixture(state: CareerState): Fixture | undefined {
  return state.fixturesByLeague[state.activeLeagueId].find(
    (f) => !f.played && (f.homeClubId === state.userClubId || f.awayClubId === state.userClubId)
  );
}

export function advanceOneDay(state: CareerState): {
  nextState: CareerState;
  matchReadyFixture: Fixture | null;
} {
  const nextDate = addDaysISO(state.currentDateISO, 1);
  const nextPlayers: Record<string, Player> = { ...state.players };
  const nextInbox = [...state.inbox];
  const nextClubs = { ...state.clubs };

  // 1. Daily recovery, injury healing & training development
  const recoveryBase =
    state.trainingIntensity === 'Nhẹ' ? 7 : state.trainingIntensity === 'Trung bình' ? 5 : 3;
  const sharpnessGain =
    state.trainingIntensity === 'Cao' ? 3 : state.trainingIntensity === 'Trung bình' ? 2 : 1;

  for (const pid of Object.keys(nextPlayers)) {
    const p = nextPlayers[pid];
    let updated = p;

    if (p.clubId === state.userClubId) {
      const cond = Math.min(100, p.condition + recoveryBase);
      const sharp = Math.min(100, p.sharpness + sharpnessGain);
      const injDays = Math.max(0, p.injuryDays - 1);
      let ovr = p.ovr;

      // Young player growth under focused training
      if (p.age <= 22 && p.ca < p.pa && Math.random() < (state.trainingIntensity === 'Cao' ? 0.045 : 0.025)) {
        ovr = Math.min(96, p.ovr + 1);
      }

      updated = {
        ...p,
        condition: cond,
        sharpness: sharp,
        injuryDays: injDays,
        injuryType: injDays === 0 ? null : p.injuryType,
        ovr,
      };
    } else {
      updated = {
        ...p,
        condition: Math.min(100, p.condition + 5),
        injuryDays: Math.max(0, p.injuryDays - 1),
      };
    }

    nextPlayers[pid] = updated;
  }

  // 2. Simulate AI-only league fixtures scheduled for nextDate
  const nextFixturesByLeague = { ...state.fixturesByLeague };
  const nextStandingsByLeague = { ...state.standingsByLeague };

  for (const lid of getLeagueOrder(state)) {
    const leagueFixtures = nextFixturesByLeague[lid] ?? [];
    let leagueStandings = nextStandingsByLeague[lid] ?? [];
    let changed = false;

    const updatedFixtures = leagueFixtures.map((f) => {
      if (!f.played && f.dateISO <= nextDate) {
        // Do NOT auto-resolve user's own match
        if (f.homeClubId === state.userClubId || f.awayClubId === state.userClubId) {
          return f;
        }
        const homeClub = nextClubs[f.homeClubId];
        const awayClub = nextClubs[f.awayClubId];
        if (!homeClub || !awayClub) return f;
        const resolved = resolveAIMatchFast(f, homeClub, awayClub, nextPlayers);
        leagueStandings = applyFixtureToStandings(leagueStandings, resolved, nextClubs);
        // Update AI player goals/assists
        for (const ge of resolved.goalEvents ?? []) {
          const gp = nextPlayers[ge.playerId];
          if (gp) {
            nextPlayers[ge.playerId] = {
              ...gp,
              stats: { ...gp.stats, goals: gp.stats.goals + 1, appearances: gp.stats.appearances + 1 },
            };
          }
        }
        changed = true;
        return resolved;
      }
      return f;
    });

    if (changed) {
      nextFixturesByLeague[lid] = updatedFixtures;
      nextStandingsByLeague[lid] = leagueStandings;
    }
  }

  // 3. Check if user has a match today
  const matchToday = nextFixturesByLeague[state.activeLeagueId].find(
    (f) =>
      !f.played &&
      f.dateISO <= nextDate &&
      (f.homeClubId === state.userClubId || f.awayClubId === state.userClubId)
  );

  // 4. Pre-match 1-day warning if match is tomorrow
  const tomorrow = addDaysISO(nextDate, 1);
  const matchTomorrow = nextFixturesByLeague[state.activeLeagueId].find(
    (f) =>
      !f.played &&
      f.dateISO === tomorrow &&
      (f.homeClubId === state.userClubId || f.awayClubId === state.userClubId)
  );
  if (matchTomorrow) {
    const oppId =
      matchTomorrow.homeClubId === state.userClubId
        ? matchTomorrow.awayClubId
        : matchTomorrow.homeClubId;
    const opp = nextClubs[oppId];
    const oppR = opp ? calculateTeamRatings(opp, nextPlayers) : null;
    if (opp && oppR && !nextInbox.some((m) => m.relatedFixtureId === matchTomorrow.id)) {
      nextInbox.unshift({
        id: `msg_pre_${matchTomorrow.id}`,
        dateISO: nextDate,
        category: 'Trận đấu',
        sender: 'Trợ lý HLV',
        subject: `Báo cáo trước trận: Gặp ${opp.name} (Vòng ${matchTomorrow.round})`,
        body: `Ngày mai chúng ta sẽ đối đầu ${opp.name} (OVR đội hình ${oppR.overall} · Công ${oppR.attack} / Thủ ${oppR.defense}). Hãy kiểm tra thể lực đội hình xuất phát và điều chỉnh chiến thuật trước giờ bóng lăn.`,
        read: false,
        actionType: 'next_match',
        relatedFixtureId: matchTomorrow.id,
      });
    }
  }

  // 5. Monthly financial income on the 1st of month
  if (nextDate.endsWith('-01')) {
    const uc = nextClubs[state.userClubId];
    if (uc) {
      const monthlyNet = Math.round(
        (uc.finances.monthlyIncomeMatchday + uc.finances.monthlyIncomeSponsor - uc.finances.wageBudgetWeekly * 0.004) *
          10
      ) / 10;
      nextClubs[uc.id] = {
        ...uc,
        finances: {
          ...uc.finances,
          balance: Math.round((uc.finances.balance + monthlyNet) * 10) / 10,
        },
      };
    }
  }

  return {
    nextState: {
      ...state,
      currentDateISO: nextDate,
      clubs: nextClubs,
      players: nextPlayers,
      fixturesByLeague: nextFixturesByLeague,
      standingsByLeague: nextStandingsByLeague,
      inbox: nextInbox.slice(0, 40),
    },
    matchReadyFixture: matchToday ?? null,
  };
}

export function commitUserMatchResult(
  state: CareerState,
  matchState: LiveMatchState
): CareerState {
  const lid = state.activeLeagueId;
  const nextClubs = { ...state.clubs };
  const nextPlayers = { ...state.players };
  let nextStandings = [...state.standingsByLeague[lid]];

  const goalEvents: NonNullable<Fixture['goalEvents']> = matchState.events
    .filter((e) => e.type === 'goal' && e.playerId)
    .map((e) => ({
      minute: e.minute,
      playerId: e.playerId!,
      playerName: nextPlayers[e.playerId!]?.name ?? 'Cầu thủ',
      clubId: e.team === 'home' ? matchState.homeClubId : matchState.awayClubId,
    }));

  // Update the user's fixture + any other same-round fixtures
  const playedFixture: Fixture = {
    ...(state.fixturesByLeague[lid].find((f) => f.id === matchState.fixtureId)!),
    played: true,
    homeGoals: matchState.homeScore,
    awayGoals: matchState.awayScore,
    homeXg: matchState.stats.homeXg,
    awayXg: matchState.stats.awayXg,
    goalEvents,
  };

  nextStandings = applyFixtureToStandings(nextStandings, playedFixture, nextClubs);

  const nextFixtures = state.fixturesByLeague[lid].map((f) => {
    if (f.id === playedFixture.id) return playedFixture;
    if (!f.played && f.round === playedFixture.round) {
      const hc = nextClubs[f.homeClubId];
      const ac = nextClubs[f.awayClubId];
      if (hc && ac) {
        const res = resolveAIMatchFast(f, hc, ac, nextPlayers);
        nextStandings = applyFixtureToStandings(nextStandings, res, nextClubs);
        return res;
      }
    }
    return f;
  });

  // Update player match stats & stamina
  const userIsHome = matchState.homeClubId === state.userClubId;
  const userGoals = userIsHome ? matchState.homeScore : matchState.awayScore;
  const oppGoals = userIsHome ? matchState.awayScore : matchState.homeScore;
  const resultChar: 'W' | 'D' | 'L' =
    userGoals > oppGoals ? 'W' : userGoals === oppGoals ? 'D' : 'L';

  for (const agent of matchState.agents) {
    const p = nextPlayers[agent.playerId];
    if (!p) continue;
    const isCleanSheet = agent.position === 'GK' && ((agent.team === 'home' ? matchState.awayScore : matchState.homeScore) === 0);
    const newCount = p.stats.ratingCount + 1;
    const newAvg =
      Math.round(((p.stats.avgRating * p.stats.ratingCount + agent.rating) / newCount) * 100) / 100;

    nextPlayers[p.id] = {
      ...p,
      condition: Math.max(40, Math.round(agent.stamina)),
      sharpness: Math.min(100, p.sharpness + 4),
      morale: Math.max(
        20,
        Math.min(100, p.morale + (resultChar === 'W' ? 4 : resultChar === 'D' ? 0 : -4))
      ),
      lastFiveRatings: [...p.lastFiveRatings, Math.round(agent.rating * 10) / 10].slice(-5),
      stats: {
        ...p.stats,
        appearances: p.stats.appearances + 1,
        goals: p.stats.goals + agent.goals,
        assists: p.stats.assists + agent.assists,
        cleanSheets: p.stats.cleanSheets + (isCleanSheet ? 1 : 0),
        yellowCards: p.stats.yellowCards + (agent.yellowCard ? 1 : 0),
        redCards: p.stats.redCards + (agent.redCard ? 1 : 0),
        avgRating: newAvg,
        ratingCount: newCount,
      },
    };
  }

  // Update user club finances (home gate receipts) & board confidence
  const uc = nextClubs[state.userClubId];
  const confidenceDelta = resultChar === 'W' ? 3 : resultChar === 'D' ? 0 : -4;
  const gateIncome = userIsHome ? Math.round((uc.capacity / 1000) * 0.045 * 10) / 10 : 0;

  nextClubs[uc.id] = {
    ...uc,
    finances: {
      ...uc.finances,
      balance: Math.round((uc.finances.balance + gateIncome) * 10) / 10,
      boardConfidence: Math.max(15, Math.min(100, uc.finances.boardConfidence + confidenceDelta)),
      fanConfidence: Math.max(15, Math.min(100, uc.finances.fanConfidence + confidenceDelta)),
    },
  };

  const homeName = nextClubs[matchState.homeClubId]?.name ?? 'Chủ nhà';
  const awayName = nextClubs[matchState.awayClubId]?.name ?? 'Đội khách';

  const allUserFixturesDone = !nextFixtures.some(
    (f) => !f.played && (f.homeClubId === state.userClubId || f.awayClubId === state.userClubId)
  );

  const extraSeasonEndMsg = allUserFixturesDone
    ? [
        {
          id: `msg_season_end_${state.seasonNumber}`,
          dateISO: state.currentDateISO,
          category: 'Ban lãnh đạo' as const,
          sender: `Ban tổ chức ${getLeagueDef(state, lid).name}`,
          subject: `Mùa giải ${state.seasonNumber} đã khép lại — Sẵn sàng Tổng kết`,
          body: `Tất cả 18 vòng đấu tại ${getLeagueDef(state, lid).name} đã hoàn tất. Hãy nhấn "Tổng kết mùa giải" ở thanh trên cùng để xác định thứ hạng chung cuộc, lên/xuống hạng và bước vào mùa giải mới.`,
          read: false,
        },
      ]
    : [];

  return {
    ...state,
    clubs: nextClubs,
    players: nextPlayers,
    fixturesByLeague: {
      ...state.fixturesByLeague,
      [lid]: nextFixtures,
    },
    standingsByLeague: {
      ...state.standingsByLeague,
      [lid]: nextStandings,
    },
    inbox: [
      ...extraSeasonEndMsg,
      {
        id: `msg_ft_${matchState.fixtureId}`,
        dateISO: state.currentDateISO,
        category: 'Trận đấu' as const,
        sender: 'Báo cáo sau trận',
        subject: `Kết quả Vòng ${playedFixture.round}: ${homeName} ${matchState.homeScore} - ${matchState.awayScore} ${awayName}`,
        body: `Trận đấu kết thúc với xG ${matchState.stats.homeXg.toFixed(2)} - ${matchState.stats.awayXg.toFixed(2)}. ${
          resultChar === 'W'
            ? 'Một chiến thắng xứng đáng giúp toàn đội lên tinh thần rất cao.'
            : resultChar === 'D'
            ? '1 điểm giành được giúp đội duy trì nhịp độ trên bảng xếp hạng.'
            : 'Trận thua này đòi hỏi ban huấn luyện cần phân tích lại khâu chiến thuật.'
        }`,
        read: false,
      },
      ...state.inbox,
    ].slice(0, 40),
    history: {
      playedMatches: state.history.playedMatches + 1,
      wins: state.history.wins + (resultChar === 'W' ? 1 : 0),
      draws: state.history.draws + (resultChar === 'D' ? 1 : 0),
      losses: state.history.losses + (resultChar === 'L' ? 1 : 0),
    },
  };
}

export interface SeasonMovement {
  clubId: string;
  clubName: string;
  fromLeagueId: LeagueId;
  toLeagueId: LeagueId;
  fromLeagueName: string;
  toLeagueName: string;
  type: 'promoted' | 'relegated';
}

export interface SeasonSummaryPreview {
  seasonNumber: number;
  leagueId: LeagueId;
  leagueName: string;
  championClubName: string;
  userPosition: number;
  totalTeams: number;
  userRow: LeagueStandingRow;
  outcome: SeasonRecord['outcome'];
  prizeMoney: number;
  nextLeagueId: LeagueId;
  nextLeagueName: string;
  movements: SeasonMovement[];
  topScorerName?: string;
  topScorerGoals?: number;
}

export function finalizeRemainingLeagueMatches(state: CareerState): CareerState {
  const nextPlayers = { ...state.players };
  const nextFixturesByLeague = { ...state.fixturesByLeague };
  const nextStandingsByLeague = { ...state.standingsByLeague };

  for (const lid of getLeagueOrder(state)) {
    let standings = [...(nextStandingsByLeague[lid] ?? [])];
    let changed = false;
    const fixtures = (nextFixturesByLeague[lid] ?? []).map((f) => {
      if (f.played) return f;
      const hc = state.clubs[f.homeClubId];
      const ac = state.clubs[f.awayClubId];
      if (!hc || !ac) return f;
      const resolved = resolveAIMatchFast(f, hc, ac, nextPlayers);
      standings = applyFixtureToStandings(standings, resolved, state.clubs);
      for (const ge of resolved.goalEvents ?? []) {
        const gp = nextPlayers[ge.playerId];
        if (gp) {
          nextPlayers[ge.playerId] = {
            ...gp,
            stats: { ...gp.stats, goals: gp.stats.goals + 1, appearances: gp.stats.appearances + 1 },
          };
        }
      }
      changed = true;
      return resolved;
    });

    if (changed) {
      nextFixturesByLeague[lid] = fixtures;
      nextStandingsByLeague[lid] = standings;
    }
  }

  return {
    ...state,
    players: nextPlayers,
    fixturesByLeague: nextFixturesByLeague,
    standingsByLeague: nextStandingsByLeague,
  };
}

export function computeSeasonSummary(state: CareerState): {
  finalizedState: CareerState;
  preview: SeasonSummaryPreview;
} {
  const finalized = finalizeRemainingLeagueMatches(state);
  const lid = finalized.activeLeagueId;
  const leagueDef = getLeagueDef(finalized, lid);
  const standings = finalized.standingsByLeague[lid] ?? [];
  const userIdx = standings.findIndex((r) => r.clubId === finalized.userClubId);
  const userPos = userIdx >= 0 ? userIdx + 1 : standings.length;
  const userRow = standings[userIdx >= 0 ? userIdx : 0] ?? {
    clubId: finalized.userClubId,
    played: 0,
    won: 0,
    drawn: 0,
    lost: 0,
    gf: 0,
    ga: 0,
    gd: 0,
    points: 0,
    form: [],
  };

  // Compute pyramid promotion/relegation movements (div_3 <-> div_2 <-> countryLeagueId)
  const movements: SeasonMovement[] = [];
  const countryLid = finalized.countryLeagueId ?? lid;
  const hasDiv3 = Boolean(finalized.standingsByLeague.div_3?.length);
  const hasDiv2 = Boolean(finalized.standingsByLeague.div_2?.length);

  if (hasDiv3 && hasDiv2) {
    const s3 = finalized.standingsByLeague.div_3;
    const s2 = finalized.standingsByLeague.div_2;
    const d3Name = getLeagueDef(finalized, 'div_3').name;
    const d2Name = getLeagueDef(finalized, 'div_2').name;
    const topName = getLeagueDef(finalized, countryLid).name;

    // Top 2 of div_3 promote to div_2
    s3.slice(0, 2).forEach((r) => {
      movements.push({
        clubId: r.clubId,
        clubName: finalized.clubs[r.clubId]?.name ?? r.clubId,
        fromLeagueId: 'div_3',
        toLeagueId: 'div_2',
        fromLeagueName: d3Name,
        toLeagueName: d2Name,
        type: 'promoted',
      });
    });

    // Bottom 2 of div_2 relegate to div_3
    s2.slice(-2).forEach((r) => {
      movements.push({
        clubId: r.clubId,
        clubName: finalized.clubs[r.clubId]?.name ?? r.clubId,
        fromLeagueId: 'div_2',
        toLeagueId: 'div_3',
        fromLeagueName: d2Name,
        toLeagueName: d3Name,
        type: 'relegated',
      });
    });

    // Top 2 of div_2 promote to countryLid
    s2.slice(0, 2).forEach((r) => {
      movements.push({
        clubId: r.clubId,
        clubName: finalized.clubs[r.clubId]?.name ?? r.clubId,
        fromLeagueId: 'div_2',
        toLeagueId: countryLid,
        fromLeagueName: d2Name,
        toLeagueName: topName,
        type: 'promoted',
      });
    });

    // Bottom 2 of countryLid relegate to div_2
    const s1 = finalized.standingsByLeague[countryLid] ?? [];
    s1.slice(-2).forEach((r) => {
      movements.push({
        clubId: r.clubId,
        clubName: finalized.clubs[r.clubId]?.name ?? r.clubId,
        fromLeagueId: countryLid,
        toLeagueId: 'div_2',
        fromLeagueName: topName,
        toLeagueName: d2Name,
        type: 'relegated',
      });
    });
  }

  const userMove = movements.find((m) => m.clubId === finalized.userClubId);
  const nextLeagueId = userMove ? userMove.toLeagueId : lid;
  const nextLeagueName = getLeagueDef(finalized, nextLeagueId).name;

  let outcome: SeasonRecord['outcome'] = 'stayed';
  if (userMove?.type === 'relegated') outcome = 'relegated';
  else if (userPos === 1 && userMove?.type === 'promoted') outcome = 'champion';
  else if (userMove?.type === 'promoted') outcome = 'promoted';
  else if (userPos === 1) outcome = 'champion';

  const basePrize = leagueDef.prizeMoneyFirst;
  const prizeMoney =
    Math.round(basePrize * Math.max(0.25, 1.08 - userPos * 0.085) * 10) / 10;

  const champId = standings[0]?.clubId;
  const championClubName = champId ? finalized.clubs[champId]?.name ?? 'N/A' : 'N/A';

  const leagueClubIds = new Set(standings.map((r) => r.clubId));
  const topScorer = Object.values(finalized.players)
    .filter((p) => leagueClubIds.has(p.clubId) && p.stats.goals > 0)
    .sort((a, b) => b.stats.goals - a.stats.goals)[0];

  return {
    finalizedState: finalized,
    preview: {
      seasonNumber: finalized.seasonNumber,
      leagueId: lid,
      leagueName: leagueDef.name,
      championClubName,
      userPosition: userPos,
      totalTeams: standings.length,
      userRow,
      outcome,
      prizeMoney,
      nextLeagueId,
      nextLeagueName,
      movements,
      topScorerName: topScorer?.name,
      topScorerGoals: topScorer?.stats.goals,
    },
  };
}

export function advanceToNextSeason(state: CareerState): {
  nextState: CareerState;
  preview: SeasonSummaryPreview;
} {
  const { finalizedState, preview } = computeSeasonSummary(state);
  const nextClubs = { ...finalizedState.clubs };
  const nextPlayers = { ...finalizedState.players };

  // 1. Apply promotion/relegation league transfers and club reputation/budget scaling
  for (const m of preview.movements) {
    const club = nextClubs[m.clubId];
    if (!club) continue;
    const targetLeague = getLeagueDef(finalizedState, m.toLeagueId);
    const isVN = club.country === 'Việt Nam';

    if (m.type === 'promoted') {
      const repBoost = m.toLeagueId === 'div_2' ? 6 : 7;
      const budgetFloor =
        m.toLeagueId === 'div_2' ? (isVN ? 2.8 : 11) : isVN ? 6.5 : 32;
      const wageFloor =
        m.toLeagueId === 'div_2' ? (isVN ? 110 : 480) : isVN ? 240 : 1200;

      nextClubs[m.clubId] = {
        ...club,
        leagueId: m.toLeagueId,
        reputation: Math.min(92, Math.max(club.reputation + repBoost, targetLeague.reputation - 4)),
        expectation: `Trụ hạng thành công tại ${targetLeague.name}`,
        targetPosition: 7,
        finances: {
          ...club.finances,
          transferBudget: Math.max(club.finances.transferBudget, budgetFloor),
          wageBudgetWeekly: Math.max(club.finances.wageBudgetWeekly, wageFloor),
          monthlyIncomeSponsor: Math.round(club.finances.monthlyIncomeSponsor * 1.65 * 10) / 10,
          boardConfidence: m.clubId === finalizedState.userClubId ? 88 : club.finances.boardConfidence,
        },
      };
    } else {
      nextClubs[m.clubId] = {
        ...club,
        leagueId: m.toLeagueId,
        reputation: Math.max(44, club.reputation - 4),
        expectation: `Cạnh tranh thăng hạng trở lại ${m.fromLeagueName}`,
        targetPosition: 2,
      };
    }
  }

  // 2. Award prize money to user club
  const uc = nextClubs[finalizedState.userClubId];
  if (uc) {
    const transferShare = Math.round(preview.prizeMoney * 0.45 * 10) / 10;
    nextClubs[uc.id] = {
      ...uc,
      finances: {
        ...uc.finances,
        balance: Math.round((uc.finances.balance + preview.prizeMoney) * 10) / 10,
        transferBudget: Math.round((uc.finances.transferBudget + transferShare) * 10) / 10,
      },
    };
  }

  // 3. Age players +1, develop young talent, reset season stats
  const nextSeasonYear = 2026 + finalizedState.seasonNumber;
  for (const pid of Object.keys(nextPlayers)) {
    const p = nextPlayers[pid];
    const nextAge = p.age + 1;
    let nextOvr = p.ovr;
    const maxOvrFromPa = Math.round(p.pa / 3.3 + 40);
    if (nextAge <= 23 && nextOvr < maxOvrFromPa) {
      nextOvr = Math.min(94, nextOvr + Math.min(3, Math.max(1, Math.floor((maxOvrFromPa - nextOvr) / 3))));
    } else if (nextAge >= 34) {
      nextOvr = Math.max(52, nextOvr - 1);
    }

    nextPlayers[pid] = {
      ...p,
      age: nextAge,
      ovr: nextOvr,
      ca: Math.round((nextOvr - 40) * 3.3),
      contractUntilYear: Math.max(nextSeasonYear + 1, p.contractUntilYear),
      condition: 100,
      sharpness: 78,
      injuryDays: 0,
      injuryType: null,
      suspendedMatches: 0,
      yellowCardAccumulation: 0,
      stats: {
        appearances: 0,
        goals: 0,
        assists: 0,
        cleanSheets: 0,
        yellowCards: 0,
        redCards: 0,
        avgRating: 0,
        ratingCount: 0,
        xg: 0,
      },
    };
  }

  // 4. Generate fresh fixtures and 0-pt standings for Season N+1
  const nextSeasonNum = finalizedState.seasonNumber + 1;
  const nextStartDateISO = `${nextSeasonYear}-08-10`;
  const firstMatchDateISO = `${nextSeasonYear}-08-15`;

  const nextFixturesByLeague: Record<string, Fixture[]> = {};
  const nextStandingsByLeague: Record<string, LeagueStandingRow[]> = {};

  for (const lid of getLeagueOrder(finalizedState)) {
    const clubIds = Object.values(nextClubs)
      .filter((c) => c.leagueId === lid)
      .map((c) => c.id);
    nextFixturesByLeague[lid] = generateLeagueFixtures(
      clubIds,
      lid,
      firstMatchDateISO
    ).map((f) => ({ ...f, id: `s${nextSeasonNum}_${f.id}` }));
    nextStandingsByLeague[lid] = sortStandings(createInitialStandings(clubIds), nextClubs);
  }

  const nextActiveLeagueId = nextClubs[finalizedState.userClubId].leagueId;
  const nextLeagueDef = getLeagueDef(finalizedState, nextActiveLeagueId);

  const seasonRecord: SeasonRecord = {
    seasonNumber: preview.seasonNumber,
    leagueId: preview.leagueId,
    leagueName: preview.leagueName,
    position: preview.userPosition,
    totalTeams: preview.totalTeams,
    played: preview.userRow.played,
    won: preview.userRow.won,
    drawn: preview.userRow.drawn,
    lost: preview.userRow.lost,
    gf: preview.userRow.gf,
    ga: preview.userRow.ga,
    points: preview.userRow.points,
    outcome: preview.outcome,
    prizeMoney: preview.prizeMoney,
  };

  const outcomeLine =
    preview.outcome === 'champion' || preview.outcome === 'promoted'
      ? `Chúc mừng thành tích thăng hạng lên ${nextLeagueDef.name}!`
      : preview.outcome === 'relegated'
      ? `Sau khi xuống ${nextLeagueDef.name}, ban lãnh đạo kỳ vọng đội bóng sớm trở lại đỉnh cao.`
      : `CLB chuẩn bị bước vào chiến dịch mới tại ${nextLeagueDef.name}.`;

  return {
    preview,
    nextState: {
      ...finalizedState,
      activeLeagueId: nextActiveLeagueId,
      seasonNumber: nextSeasonNum,
      currentDateISO: nextStartDateISO,
      clubs: nextClubs,
      players: nextPlayers,
      fixturesByLeague: nextFixturesByLeague,
      standingsByLeague: nextStandingsByLeague,
      seasonHistory: [...(finalizedState.seasonHistory ?? []), seasonRecord],
      inbox: [
        {
          id: `msg_new_season_${nextSeasonNum}`,
          dateISO: nextStartDateISO,
          category: 'Ban lãnh đạo' as const,
          sender: `Chủ tịch CLB ${uc?.name ?? ''}`,
          subject: `Khởi tranh Mùa giải ${nextSeasonNum} tại ${nextLeagueDef.name}`,
          body: `${outcomeLine} Tiền thưởng mùa trước: €${preview.prizeMoney.toFixed(1)}M. Ngân sách chuyển nhượng hiện tại: €${(nextClubs[finalizedState.userClubId]?.finances.transferBudget ?? 0).toFixed(1)}M.`,
          read: false,
        },
        ...finalizedState.inbox,
      ].slice(0, 40),
    },
  };
}
