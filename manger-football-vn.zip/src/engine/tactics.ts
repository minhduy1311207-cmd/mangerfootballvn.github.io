import { FORMATIONS, autoPickBestLineup } from '../data/database';
import { Club, FormationName, Player, Position, TeamTactics } from '../types/fm';

export interface FamiliarityResult {
  label: 'Sở trường' | 'Quen thuộc' | 'Trái sở trường';
  multiplier: number;
}

const ADJACENT_POSITIONS: Record<Position, Position[]> = {
  GK: [],
  LB: ['CB', 'LW'],
  RB: ['CB', 'RW'],
  CB: ['DM', 'LB', 'RB'],
  DM: ['CM', 'CB'],
  CM: ['DM', 'AM'],
  AM: ['CM', 'LW', 'RW', 'ST'],
  LW: ['AM', 'RW', 'ST', 'LB'],
  RW: ['AM', 'LW', 'ST', 'RB'],
  ST: ['AM', 'LW', 'RW'],
};

export function getPositionFamiliarity(player: Player, targetPosition: Position): FamiliarityResult {
  if (player.primaryPosition === targetPosition) {
    return { label: 'Sở trường', multiplier: 1.0 };
  }
  if (player.secondaryPositions.includes(targetPosition)) {
    return { label: 'Quen thuộc', multiplier: 0.91 };
  }
  if (
    targetPosition !== 'GK' &&
    player.primaryPosition !== 'GK' &&
    ADJACENT_POSITIONS[player.primaryPosition]?.includes(targetPosition)
  ) {
    return { label: 'Quen thuộc', multiplier: 0.82 };
  }
  if (targetPosition === 'GK' || player.primaryPosition === 'GK') {
    return { label: 'Trái sở trường', multiplier: 0.38 };
  }
  return { label: 'Trái sở trường', multiplier: 0.65 };
}

export interface TeamRatings {
  overall: number;
  attack: number;
  midfield: number;
  defense: number;
  tacticalFit: number; // 0-100
}

export function calculateTeamRatings(club: Club, players: Record<string, Player>): TeamRatings {
  const slots = FORMATIONS[club.tactics.formation];
  let defSum = 0;
  let defCount = 0;
  let midSum = 0;
  let midCount = 0;
  let attSum = 0;
  let attCount = 0;
  let fitSum = 0;

  slots.forEach((slot, idx) => {
    const pid = club.tactics.lineupIds[idx];
    const player = pid ? players[pid] : undefined;
    if (!player) return;

    const fam = getPositionFamiliarity(player, slot.position);
    fitSum += fam.multiplier * 100;

    const condFactor = 0.72 + 0.28 * (player.condition / 100);
    const moraleFactor = 0.9 + 0.1 * (player.morale / 100);
    const effOvr = player.ovr * fam.multiplier * condFactor * moraleFactor;

    if (slot.position === 'GK' || slot.position === 'CB' || slot.position === 'LB' || slot.position === 'RB') {
      defSum += effOvr;
      defCount++;
    } else if (slot.position === 'DM' || slot.position === 'CM' || slot.position === 'AM') {
      midSum += effOvr;
      midCount++;
    } else {
      attSum += effOvr;
      attCount++;
    }
  });

  const defense = defCount > 0 ? Math.round(defSum / defCount) : 65;
  const midfield = midCount > 0 ? Math.round(midSum / midCount) : 65;
  const attack = attCount > 0 ? Math.round(attSum / attCount) : 65;
  const overall = Math.round((defense + midfield + attack) / 3);
  const tacticalFit = Math.round(fitSum / Math.max(1, slots.length));

  return { overall, attack, midfield, defense, tacticalFit };
}

export function switchFormationTactics(
  current: TeamTactics,
  newFormation: FormationName,
  clubPlayers: Player[]
): TeamTactics {
  const slots = FORMATIONS[newFormation];
  const { lineupIds, benchIds } = autoPickBestLineup(clubPlayers, newFormation);
  return {
    ...current,
    formation: newFormation,
    lineupIds,
    benchIds,
    slotRoles: slots.map((s) => s.role),
    slotDuties: slots.map((s) => s.duty),
  };
}
