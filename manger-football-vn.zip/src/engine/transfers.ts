import { autoPickBestLineup } from '../data/database';
import { CareerState, Club, Player, SquadRole } from '../types/fm';

export interface BidEvaluation {
  decision: 'accepted' | 'countered' | 'rejected';
  counterFee?: number;
  reason: string;
}

export function evaluateTransferBid(
  player: Player,
  sellingClub: Club,
  offeredFee: number
): BidEvaluation {
  const baseVal = player.marketValue;
  const roleMultiplier =
    player.transferListed
      ? 0.85
      : player.squadRole === 'Ngôi sao'
      ? 1.32
      : player.squadRole === 'Đá chính'
      ? 1.15
      : 1.0;

  const contractFactor = player.contractUntilYear <= 2027 ? 0.9 : 1.08;
  const askingPrice = Math.max(0.5, Math.round(baseVal * roleMultiplier * contractFactor * 10) / 10);

  if (offeredFee >= askingPrice) {
    return {
      decision: 'accepted',
      reason: `${sellingClub.name} đã chấp nhận mức phí €${offeredFee.toFixed(1)}M cho ${player.name}.`,
    };
  }

  if (offeredFee >= askingPrice * 0.72) {
    const counter = Math.round(((askingPrice + offeredFee) / 2) * 1.08 * 10) / 10;
    return {
      decision: 'countered',
      counterFee: Math.max(offeredFee + 0.5, counter),
      reason: `${sellingClub.name} từ chối €${offeredFee.toFixed(1)}M nhưng sẵn sàng đàm phán ở mức €${Math.max(offeredFee + 0.5, counter).toFixed(1)}M.`,
    };
  }

  return {
    decision: 'rejected',
    reason: `${sellingClub.name} thẳng thừng từ chối lời đề nghị quá thấp (định giá tối thiểu ~€${askingPrice.toFixed(1)}M).`,
  };
}

export interface ContractEvaluation {
  accepted: boolean;
  minExpectedWage: number;
  reason: string;
}

export function evaluateContractOffer(
  player: Player,
  targetClub: Club,
  offeredWage: number,
  contractYears: number,
  offeredRole: SquadRole
): ContractEvaluation {
  const repGap = Math.max(0, 84 - targetClub.reputation);
  const roleBonus =
    offeredRole === 'Ngôi sao' ? 0.95 : offeredRole === 'Đá chính' ? 1.05 : 1.25;
  const minExpectedWage = Math.max(
    4,
    Math.round(player.weeklyWage * (1.06 + repGap * 0.015) * roleBonus)
  );

  if (targetClub.reputation + 16 < player.ovr && player.clubId !== targetClub.id) {
    return {
      accepted: false,
      minExpectedWage,
      reason: `${player.name} muốn thi đấu cho một CLB có danh tiếng cao hơn ở thời điểm hiện tại.`,
    };
  }

  if (offeredWage >= minExpectedWage && contractYears >= 2) {
    return {
      accepted: true,
      minExpectedWage,
      reason: `${player.name} hài lòng với đãi ngộ €${offeredWage}k/tuần và vai trò ${offeredRole}.`,
    };
  }

  return {
    accepted: false,
    minExpectedWage,
    reason: `Người đại diện của ${player.name} yêu cầu mức lương tối thiểu €${minExpectedWage}k/tuần (hợp đồng từ 2 năm).`,
  };
}

export function executeTransfer(
  state: CareerState,
  playerId: string,
  buyerClubId: string,
  fee: number,
  newWage: number,
  contractYears: number,
  newRole: SquadRole
): CareerState {
  const player = state.players[playerId];
  if (!player) return state;
  const sellerClub = state.clubs[player.clubId];
  const buyerClub = state.clubs[buyerClubId];
  if (!sellerClub || !buyerClub || sellerClub.id === buyerClub.id) return state;

  const updatedPlayer: Player = {
    ...player,
    clubId: buyerClubId,
    weeklyWage: newWage,
    contractUntilYear: 2026 + contractYears,
    squadRole: newRole,
    transferListed: false,
    morale: Math.min(100, player.morale + 10),
  };

  const nextPlayers = {
    ...state.players,
    [playerId]: updatedPlayer,
  };

  // Re-pick lineups for both seller and buyer cleanly
  const sellerPlayers = Object.values(nextPlayers).filter((p) => p.clubId === sellerClub.id);
  const buyerPlayers = Object.values(nextPlayers).filter((p) => p.clubId === buyerClub.id);

  const sellerPick = autoPickBestLineup(sellerPlayers, sellerClub.tactics.formation);
  const buyerPick = autoPickBestLineup(buyerPlayers, buyerClub.tactics.formation);

  const nextClubs = {
    ...state.clubs,
    [sellerClub.id]: {
      ...sellerClub,
      finances: {
        ...sellerClub.finances,
        balance: Math.round((sellerClub.finances.balance + fee) * 10) / 10,
        transferBudget: Math.round((sellerClub.finances.transferBudget + fee * 0.85) * 10) / 10,
      },
      tactics: {
        ...sellerClub.tactics,
        lineupIds: sellerPick.lineupIds,
        benchIds: sellerPick.benchIds,
      },
    },
    [buyerClub.id]: {
      ...buyerClub,
      finances: {
        ...buyerClub.finances,
        balance: Math.round((buyerClub.finances.balance - fee) * 10) / 10,
        transferBudget: Math.max(0, Math.round((buyerClub.finances.transferBudget - fee) * 10) / 10),
      },
      tactics: {
        ...buyerClub.tactics,
        lineupIds: buyerPick.lineupIds,
        benchIds: buyerPick.benchIds,
      },
    },
  };

  return {
    ...state,
    clubs: nextClubs,
    players: nextPlayers,
    shortlistIds: state.shortlistIds.filter((id) => id !== playerId),
    inbox: [
      {
        id: `msg_tr_${Date.now()}_${playerId}`,
        dateISO: state.currentDateISO,
        category: 'Chuyển nhượng',
        sender: 'Giám đốc Thể thao',
        subject: `Hoàn tất chuyển nhượng: ${player.name}`,
        body: `${player.name} đã chính thức chuyển từ ${sellerClub.name} sang ${buyerClub.name} với mức phí €${fee.toFixed(1)}M, lương €${newWage}k/tuần.`,
        read: false,
      },
      ...state.inbox,
    ],
  };
}
