import { FORMATIONS } from '../data/database';
import {
  Club,
  Fixture,
  LiveMatchState,
  MatchAgent,
  MatchEvent,
  Player,
  TacticalMentality,
} from '../types/fm';
import { calculateTeamRatings, getPositionFamiliarity } from './tactics';

export const PITCH_WIDTH = 105;
export const PITCH_HEIGHT = 68;
export const TICKS_PER_MINUTE = 10;

function clamp(v: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, v));
}

function dist(ax: number, ay: number, bx: number, by: number): number {
  return Math.hypot(ax - bx, ay - by);
}

function getSlotPitchMeters(
  slotX: number,
  slotY: number,
  team: 'home' | 'away'
): { x: number; y: number } {
  // slotY: 92 is own GK, 14 is ST; slotX: 0..100 left-to-right
  // Home defends x=0, attacks x=105
  if (team === 'home') {
    const x = ((100 - slotY) / 100) * (PITCH_WIDTH - 8) + 4;
    const y = (slotX / 100) * (PITCH_HEIGHT - 6) + 3;
    return { x, y };
  }
  // Away defends x=105, attacks x=0
  const x = (slotY / 100) * (PITCH_WIDTH - 8) + 4;
  const y = ((100 - slotX) / 100) * (PITCH_HEIGHT - 6) + 3;
  return { x, y };
}

function createAgent(
  player: Player,
  team: 'home' | 'away',
  slotIdx: number,
  club: Club
): MatchAgent {
  const slots = FORMATIONS[club.tactics.formation];
  const slot = slots[slotIdx] ?? slots[0];
  const pos = getSlotPitchMeters(slot.x, slot.y, team);
  const fam = getPositionFamiliarity(player, slot.position);

  return {
    playerId: player.id,
    name: player.name,
    shirtNumber: player.shirtNumber,
    team,
    position: slot.position,
    role: club.tactics.slotRoles[slotIdx] ?? slot.role,
    duty: club.tactics.slotDuties[slotIdx] ?? slot.duty,
    ovr: Math.round(player.ovr * fam.multiplier),
    x: team === 'home' ? Math.min(pos.x, 49) : Math.max(pos.x, 56),
    y: pos.y,
    vx: 0,
    vy: 0,
    baseX: pos.x,
    baseY: pos.y,
    stamina: player.condition,
    yellowCard: false,
    redCard: false,
    goals: 0,
    assists: 0,
    shots: 0,
    passesCompleted: 0,
    passesAttempted: 0,
    tackles: 0,
    rating: 6.5,
  };
}

export function createLiveMatchState(
  fixture: Fixture,
  homeClub: Club,
  awayClub: Club,
  players: Record<string, Player>
): LiveMatchState {
  const agents: MatchAgent[] = [];

  homeClub.tactics.lineupIds.forEach((pid, idx) => {
    const p = pid ? players[pid] : undefined;
    if (p) agents.push(createAgent(p, 'home', idx, homeClub));
  });

  awayClub.tactics.lineupIds.forEach((pid, idx) => {
    const p = pid ? players[pid] : undefined;
    if (p) agents.push(createAgent(p, 'away', idx, awayClub));
  });

  const kickoffCarrier =
    agents.find((a) => a.team === 'home' && a.position === 'ST') ??
    agents.find((a) => a.team === 'home' && a.position !== 'GK') ??
    agents[0];

  return {
    fixtureId: fixture.id,
    homeClubId: homeClub.id,
    awayClubId: awayClub.id,
    phase: 'first_half',
    minute: 1,
    tick: 0,
    addedTimeFirst: 2,
    addedTimeSecond: 4,
    homeScore: 0,
    awayScore: 0,
    homeSubsUsed: 0,
    awaySubsUsed: 0,
    homeBenchIds: [...homeClub.tactics.benchIds],
    awayBenchIds: [...awayClub.tactics.benchIds],
    agents,
    ball: {
      x: PITCH_WIDTH / 2,
      y: PITCH_HEIGHT / 2,
      z: 0,
      vx: 0,
      vy: 0,
      vz: 0,
      ownerId: kickoffCarrier?.playerId ?? null,
      lastTouchTeam: 'home',
      lastTouchPlayerId: kickoffCarrier?.playerId ?? null,
      assistCandidateId: null,
      trail: [],
    },
    stats: {
      homePossessionTicks: 1,
      awayPossessionTicks: 1,
      homeShots: 0,
      awayShots: 0,
      homeShotsOnTarget: 0,
      awayShotsOnTarget: 0,
      homeXg: 0,
      awayXg: 0,
      homeCorners: 0,
      awayCorners: 0,
      homeFouls: 0,
      awayFouls: 0,
      homePasses: 0,
      awayPasses: 0,
    },
    events: [
      {
        id: `ev_ko_${fixture.id}`,
        minute: 1,
        type: 'kickoff',
        team: 'neutral',
        text: `Trọng tài thổi còi khai cuộc! ${homeClub.name} giao bóng trước.`,
      },
    ],
    goalBanner: null,
    halfTimeTalkDone: false,
    userShoutCooldown: 0,
    activeShout: null,
  };
}

function getMentalityOffset(mentality: TacticalMentality): number {
  switch (mentality) {
    case 'Rất phòng ngự':
      return -10;
    case 'Phòng ngự':
      return -5;
    case 'Cân bằng':
      return 0;
    case 'Tấn công':
      return 6;
    case 'Tổng lực':
      return 12;
  }
}

function resetPositionsForKickoff(
  agents: MatchAgent[],
  kickoffTeam: 'home' | 'away'
): { ownerId: string | null } {
  for (const a of agents) {
    if (a.redCard) continue;
    a.x = a.team === 'home' ? Math.min(a.baseX, 49) : Math.max(a.baseX, 56);
    a.y = a.baseY;
    a.vx = 0;
    a.vy = 0;
  }
  const carrier =
    agents.find((a) => !a.redCard && a.team === kickoffTeam && a.position === 'ST') ??
    agents.find((a) => !a.redCard && a.team === kickoffTeam && a.position !== 'GK');
  if (carrier) {
    carrier.x = PITCH_WIDTH / 2 + (kickoffTeam === 'home' ? -1 : 1);
    carrier.y = PITCH_HEIGHT / 2;
  }
  return { ownerId: carrier?.playerId ?? null };
}

export function stepMatchTick(
  state: LiveMatchState,
  homeClub: Club,
  awayClub: Club,
  players: Record<string, Player>,
  rng: () => number = Math.random
): LiveMatchState {
  if (state.phase === 'half_time' || state.phase === 'full_time' || state.phase === 'pre_match') {
    return state;
  }

  const nextTick = state.tick + 1;
  const currentMinute = Math.min(90 + state.addedTimeSecond, Math.floor(nextTick / TICKS_PER_MINUTE) + 1);
  const agents = state.agents.map((a) => ({ ...a }));
  const ball = { ...state.ball, trail: [...state.ball.trail.slice(-10)] };
  const stats = { ...state.stats };
  const events = [...state.events];
  let homeScore = state.homeScore;
  let awayScore = state.awayScore;
  let phase: LiveMatchState['phase'] = state.phase;
  let goalBanner = state.goalBanner ? { ...state.goalBanner, ticksLeft: state.goalBanner.ticksLeft - 1 } : null;
  if (goalBanner && goalBanner.ticksLeft <= 0) goalBanner = null;

  // Check Half-Time transition at minute 45 + addedTimeFirst
  if (phase === 'first_half' && nextTick >= (45 + state.addedTimeFirst) * TICKS_PER_MINUTE) {
    events.unshift({
      id: `ev_ht_${nextTick}`,
      minute: 45,
      type: 'halftime',
      team: 'neutral',
      text: `Hết hiệp 1! Tỉ số tạm thời: ${homeClub.shortName} ${homeScore} - ${awayScore} ${awayClub.shortName}.`,
    });
    return {
      ...state,
      tick: 45 * TICKS_PER_MINUTE,
      minute: 45,
      phase: 'half_time',
      events,
      goalBanner: null,
    };
  }

  // Check Full-Time transition
  if (phase === 'second_half' && nextTick >= (90 + state.addedTimeSecond) * TICKS_PER_MINUTE) {
    events.unshift({
      id: `ev_ft_${nextTick}`,
      minute: 90,
      type: 'fulltime',
      team: 'neutral',
      text: `HẾT GIỜ! ${homeClub.name} ${homeScore} - ${awayScore} ${awayClub.name}.`,
    });
    return {
      ...state,
      tick: nextTick,
      minute: 90,
      phase: 'full_time',
      events,
      goalBanner: null,
    };
  }

  const activeAgents = agents.filter((a) => !a.redCard);
  const owner = ball.ownerId ? activeAgents.find((a) => a.playerId === ball.ownerId) ?? null : null;
  const possTeam = owner ? owner.team : ball.lastTouchTeam ?? 'home';

  if (possTeam === 'home') stats.homePossessionTicks += 1;
  else stats.awayPossessionTicks += 1;

  // Move ball freely if unowned
  if (!owner) {
    ball.x += ball.vx;
    ball.y += ball.vy;
    ball.vx *= 0.92;
    ball.vy *= 0.92;
    ball.trail.push({ x: ball.x, y: ball.y });

    // Check out of bounds
    if (ball.y < 1 || ball.y > PITCH_HEIGHT - 1) {
      ball.y = clamp(ball.y, 2, PITCH_HEIGHT - 2);
      ball.vy = 0;
      const receiverTeam = possTeam === 'home' ? 'away' : 'home';
      const closest = activeAgents
        .filter((a) => a.team === receiverTeam && a.position !== 'GK')
        .sort((a, b) => dist(a.x, a.y, ball.x, ball.y) - dist(b.x, b.y, ball.x, ball.y))[0];
      if (closest) {
        closest.x = ball.x;
        closest.y = ball.y;
        ball.ownerId = closest.playerId;
        ball.lastTouchTeam = receiverTeam;
      }
    }

    if (ball.x < 0.5 || ball.x > PITCH_WIDTH - 0.5) {
      // Goal kick or corner already handled on shot; fallback reset to GK
      const defTeam = ball.x < 0.5 ? 'home' : 'away';
      const gk = activeAgents.find((a) => a.team === defTeam && a.position === 'GK');
      if (gk) {
        ball.x = gk.x;
        ball.y = gk.y;
        ball.vx = 0;
        ball.vy = 0;
        ball.ownerId = gk.playerId;
        ball.lastTouchTeam = defTeam;
      }
    }

    // Nearest agent picks up loose ball
    if (!ball.ownerId) {
      let bestPick: MatchAgent | null = null;
      let bestDist = 2.6;
      for (const a of activeAgents) {
        const d = dist(a.x, a.y, ball.x, ball.y);
        if (d < bestDist && (a.playerId !== ball.lastTouchPlayerId || Math.hypot(ball.vx, ball.vy) < 1.2)) {
          bestDist = d;
          bestPick = a;
        }
      }
      if (bestPick) {
        ball.ownerId = bestPick.playerId;
        if (ball.lastTouchTeam === bestPick.team && ball.lastTouchPlayerId && ball.lastTouchPlayerId !== bestPick.playerId) {
          const passer = activeAgents.find((p) => p.playerId === ball.lastTouchPlayerId);
          if (passer) {
            passer.passesCompleted += 1;
            passer.rating = clamp(passer.rating + 0.02, 4.5, 10);
          }
          ball.assistCandidateId = ball.lastTouchPlayerId;
        } else {
          ball.assistCandidateId = null;
        }
        ball.lastTouchTeam = bestPick.team;
        ball.lastTouchPlayerId = bestPick.playerId;
      }
    }
  } else {
    // Ball moves with owner
    ball.x = owner.x + (owner.team === 'home' ? 0.6 : -0.6);
    ball.y = owner.y;
    ball.trail.push({ x: ball.x, y: ball.y });
  }

  // Update each player movement & stamina
  const homeMentalityShift = getMentalityOffset(homeClub.tactics.mentality);
  const awayMentalityShift = getMentalityOffset(awayClub.tactics.mentality);

  // Determine nearest defender to ball for pressing
  const oppTeam = possTeam === 'home' ? 'away' : 'home';
  const oppPressers = activeAgents
    .filter((a) => a.team === oppTeam && a.position !== 'GK')
    .sort((a, b) => dist(a.x, a.y, ball.x, ball.y) - dist(b.x, b.y, ball.x, ball.y))
    .slice(0, 2)
    .map((a) => a.playerId);

  for (const agent of activeAgents) {
    const club = agent.team === 'home' ? homeClub : awayClub;
    const pData = players[agent.playerId];
    const paceAttr = pData?.attributes.pace ?? 13;
    const staminaAttr = pData?.attributes.stamina ?? 13;

    // Drain stamina realistically
    const pressMult = club.tactics.pressing === 'Gegenpress' ? 1.35 : club.tactics.pressing === 'Trung bình' ? 1.0 : 0.78;
    const staminaDrain = (0.042 * pressMult) / (0.65 + (staminaAttr / 20) * 0.6);
    agent.stamina = clamp(agent.stamina - staminaDrain, 15, 100);

    const speed = (0.65 + (paceAttr / 20) * 0.55) * (0.68 + 0.32 * (agent.stamina / 100));

    let targetX = agent.baseX;
    let targetY = agent.baseY;

    if (agent.position === 'GK') {
      targetX = agent.team === 'home' ? 4.5 : PITCH_WIDTH - 4.5;
      targetY = clamp(PITCH_HEIGHT / 2 + (ball.y - PITCH_HEIGHT / 2) * 0.32, 24, 44);
    } else if (owner && agent.playerId === owner.playerId) {
      // Carrier advances toward goal
      const goalX = agent.team === 'home' ? PITCH_WIDTH - 6 : 6;
      const dx = goalX - agent.x;
      const dy = PITCH_HEIGHT / 2 - agent.y;
      const d = Math.hypot(dx, dy) || 1;
      targetX = agent.x + (dx / d) * 3.0;
      targetY = agent.y + (dy / d) * 1.4 + (rng() - 0.5) * 1.4;
    } else if (!owner && dist(agent.x, agent.y, ball.x, ball.y) < 15) {
      // Chase loose ball
      targetX = ball.x;
      targetY = ball.y;
    } else if (oppPressers.includes(agent.playerId)) {
      // Press ball carrier
      const pressAggression = club.tactics.pressing === 'Gegenpress' ? 1.0 : club.tactics.pressing === 'Trung bình' ? 0.85 : 0.65;
      targetX = agent.baseX + (ball.x - agent.baseX) * pressAggression;
      targetY = agent.baseY + (ball.y - agent.baseY) * pressAggression;
    } else {
      // Team shape shifts horizontally toward ball
      const dir = agent.team === 'home' ? 1 : -1;
      const hasBall = possTeam === agent.team;
      const mentalityShift = agent.team === 'home' ? homeMentalityShift : awayMentalityShift;
      const dutyShift = agent.duty === 'Tấn công' ? 7 : agent.duty === 'Phòng ngự' ? -5 : 1;
      const ballPull = (ball.x - PITCH_WIDTH / 2) * 0.36;
      const possShift = hasBall ? dir * (8 + mentalityShift * 0.6 + dutyShift) : dir * (-7 + mentalityShift * 0.3);

      targetX = clamp(agent.baseX + ballPull + possShift, 7, PITCH_WIDTH - 7);
      targetY = clamp(agent.baseY + (ball.y - PITCH_HEIGHT / 2) * 0.34, 4, PITCH_HEIGHT - 4);
    }

    const dx = targetX - agent.x;
    const dy = targetY - agent.y;
    const d = Math.hypot(dx, dy);
    if (d > 0.25) {
      const step = Math.min(d, speed);
      agent.vx = (dx / d) * step;
      agent.vy = (dy / d) * step;
      agent.x = clamp(agent.x + agent.vx, 2, PITCH_WIDTH - 2);
      agent.y = clamp(agent.y + agent.vy, 2, PITCH_HEIGHT - 2);
    }
  }

  // Ball carrier decisions: Shoot, Tackle Duel, or Pass
  if (owner) {
    const attackingClub = owner.team === 'home' ? homeClub : awayClub;
    const defendingClub = owner.team === 'home' ? awayClub : homeClub;
    const goalX = owner.team === 'home' ? PITCH_WIDTH : 0;
    const goalY = PITCH_HEIGHT / 2;
    const distToGoal = dist(owner.x, owner.y, goalX, goalY);
    const carrierData = players[owner.playerId];

    // Check close defender tackle
    const nearestDef = activeAgents
      .filter((a) => a.team !== owner.team && a.position !== 'GK')
      .sort((a, b) => dist(a.x, a.y, owner.x, owner.y) - dist(b.x, b.y, owner.x, owner.y))[0];

    const defDist = nearestDef ? dist(nearestDef.x, nearestDef.y, owner.x, owner.y) : 99;

    // 1. Shooting check
    const shootThreshold = attackingClub.tactics.mentality === 'Tổng lực' ? 30 : 25;
    const canShoot = owner.position !== 'GK' && distToGoal < shootThreshold;
    const shootChance = canShoot ? clamp((30 - distToGoal) / 38, 0.08, 0.55) : 0;

    if (canShoot && rng() < shootChance) {
      owner.shots += 1;
      if (owner.team === 'home') stats.homeShots += 1;
      else stats.awayShots += 1;

      const finishing = carrierData?.attributes.finishing ?? 12;
      const composure = carrierData?.attributes.composure ?? 12;
      const longShots = carrierData?.attributes.longShots ?? 11;

      const gk = activeAgents.find((a) => a.team !== owner.team && a.position === 'GK');
      const gkData = gk ? players[gk.playerId] : undefined;
      const gkSkill = gkData ? (gkData.attributes.reflexes + gkData.attributes.oneOnOnes) / 2 : 12;

      const anglePenalty = Math.abs(owner.y - PITCH_HEIGHT / 2) / 34;
      const rawXg =
        clamp(0.46 - distToGoal * 0.015 - anglePenalty * 0.14, 0.03, 0.58) *
        (0.72 + (finishing * 0.6 + composure * 0.4) / 28) *
        (distToGoal > 20 ? 0.65 + longShots / 45 : 1.0);
      const xg = Math.round(clamp(rawXg, 0.02, 0.68) * 100) / 100;

      if (owner.team === 'home') stats.homeXg = Math.round((stats.homeXg + xg) * 100) / 100;
      else stats.awayXg = Math.round((stats.awayXg + xg) * 100) / 100;

      const roll = rng();
      const goalProb = xg * (1.16 - (gkSkill - 10) * 0.028);

      if (roll < goalProb) {
        // GOAL!
        owner.goals += 1;
        owner.rating = clamp(owner.rating + 1.1, 5, 10);
        if (owner.team === 'home') {
          homeScore += 1;
          stats.homeShotsOnTarget += 1;
        } else {
          awayScore += 1;
          stats.awayShotsOnTarget += 1;
        }
        const assister =
          ball.assistCandidateId && ball.assistCandidateId !== owner.playerId
            ? activeAgents.find((a) => a.playerId === ball.assistCandidateId && a.team === owner.team)
            : null;
        if (assister) {
          assister.assists += 1;
          assister.rating = clamp(assister.rating + 0.6, 5, 10);
        }

        events.unshift({
          id: `ev_goal_${nextTick}_${owner.playerId}`,
          minute: currentMinute,
          type: 'goal',
          team: owner.team,
          playerId: owner.playerId,
          xg,
          text: `VÀO!! ${owner.name} dứt điểm tung lưới ${defendingClub.shortName}!${assister ? ` (Kiến tạo: ${assister.name})` : ''} · xG ${xg.toFixed(2)}`,
        });

        goalBanner = {
          team: owner.team,
          scorerName: owner.name,
          minute: currentMinute,
          ticksLeft: 24,
        };

        const kickoffTeam = owner.team === 'home' ? 'away' : 'home';
        const reset = resetPositionsForKickoff(agents, kickoffTeam);
        ball.x = PITCH_WIDTH / 2;
        ball.y = PITCH_HEIGHT / 2;
        ball.vx = 0;
        ball.vy = 0;
        ball.ownerId = reset.ownerId;
        ball.lastTouchTeam = kickoffTeam;
        ball.assistCandidateId = null;
      } else if (roll < goalProb + 0.36) {
        // Saved by GK
        if (owner.team === 'home') stats.homeShotsOnTarget += 1;
        else stats.awayShotsOnTarget += 1;

        if (gk) {
          gk.rating = clamp(gk.rating + 0.25, 5, 10);
          ball.ownerId = gk.playerId;
          ball.x = gk.x;
          ball.y = gk.y;
          ball.lastTouchTeam = gk.team;
          ball.lastTouchPlayerId = gk.playerId;
          ball.assistCandidateId = null;
        }

        if (xg >= 0.16) {
          events.unshift({
            id: `ev_save_${nextTick}`,
            minute: currentMinute,
            type: 'shot_saved',
            team: owner.team,
            xg,
            text: `Cứu thua xuất sắc! ${gk?.name ?? 'Thủ môn'} phản xạ cản phá cú sút của ${owner.name} (xG ${xg.toFixed(2)}).`,
          });
        }

        // Occasional corner kick
        if (rng() < 0.35) {
          if (owner.team === 'home') stats.homeCorners += 1;
          else stats.awayCorners += 1;
        }
      } else {
        // Shot off target -> GK restarts
        if (xg >= 0.2) {
          events.unshift({
            id: `ev_miss_${nextTick}`,
            minute: currentMinute,
            type: 'shot_missed',
            team: owner.team,
            xg,
            text: `Bỏ lỡ đáng tiếc! ${owner.name} dứt điểm chệch cột dọc trong gang tấc (xG ${xg.toFixed(2)}).`,
          });
        }
        if (gk) {
          ball.ownerId = gk.playerId;
          ball.x = gk.x;
          ball.y = gk.y;
          ball.lastTouchTeam = gk.team;
          ball.lastTouchPlayerId = gk.playerId;
          ball.assistCandidateId = null;
        }
      }
    } else if (nearestDef && defDist < 2.2) {
      // 2. Tackle duel!
      const defData = players[nearestDef.playerId];
      const defScore = (defData?.attributes.tackling ?? 12) + (defData?.attributes.strength ?? 12) * 0.5;
      const offScore = (carrierData?.attributes.dribbling ?? 12) + (carrierData?.attributes.agility ?? 12) * 0.5;
      const winProb = clamp(0.42 + (defScore - offScore) * 0.03, 0.2, 0.72);

      if (rng() < winProb) {
        // Foul chance
        if (rng() < 0.16) {
          if (nearestDef.team === 'home') stats.homeFouls += 1;
          else stats.awayFouls += 1;

          if (rng() < 0.22) {
            if (!nearestDef.yellowCard) {
              nearestDef.yellowCard = true;
              nearestDef.rating = clamp(nearestDef.rating - 0.3, 4.5, 10);
              events.unshift({
                id: `ev_yc_${nextTick}_${nearestDef.playerId}`,
                minute: currentMinute,
                type: 'yellow_card',
                team: nearestDef.team,
                playerId: nearestDef.playerId,
                text: `Thẻ vàng cho ${nearestDef.name} sau pha phạm lỗi ngăn cản ${owner.name}.`,
              });
            } else if (!nearestDef.redCard) {
              nearestDef.redCard = true;
              nearestDef.rating = clamp(nearestDef.rating - 1.5, 4, 10);
              events.unshift({
                id: `ev_rc_${nextTick}_${nearestDef.playerId}`,
                minute: currentMinute,
                type: 'red_card',
                team: nearestDef.team,
                playerId: nearestDef.playerId,
                text: `THẺ ĐỎ! ${nearestDef.name} nhận thẻ vàng thứ hai và phải rời sân!`,
              });
            }
          }
        } else {
          // Clean tackle
          nearestDef.tackles += 1;
          nearestDef.rating = clamp(nearestDef.rating + 0.15, 4.5, 10);
          ball.ownerId = nearestDef.playerId;
          ball.lastTouchTeam = nearestDef.team;
          ball.lastTouchPlayerId = nearestDef.playerId;
          ball.assistCandidateId = null;
        }
      }
    } else {
      // 3. Pass decision
      const tempoProb = attackingClub.tactics.tempo === 'Nhanh' ? 0.36 : attackingClub.tactics.tempo === 'Vừa' ? 0.26 : 0.18;
      if (rng() < tempoProb || owner.position === 'GK') {
        const teammates = activeAgents.filter((a) => a.team === owner.team && a.playerId !== owner.playerId);
        const dir = owner.team === 'home' ? 1 : -1;
        const passingStyle = attackingClub.tactics.passing;

        const scoredTargets = teammates.map((t) => {
          const d = dist(owner.x, owner.y, t.x, t.y);
          const forwardGain = (t.x - owner.x) * dir;
          const distPreference =
            passingStyle === 'Ngắn'
              ? -Math.abs(d - 16)
              : passingStyle === 'Dài'
              ? forwardGain * 1.4 - Math.abs(d - 36) * 0.4
              : forwardGain * 0.8 - Math.abs(d - 24) * 0.5;
          const gkPenalty = t.position === 'GK' ? -25 : 0;
          return { target: t, score: distPreference + gkPenalty + rng() * 8 };
        });
        scoredTargets.sort((a, b) => b.score - a.score);
        const chosen = scoredTargets[0]?.target;

        if (chosen) {
          owner.passesAttempted += 1;
          if (owner.team === 'home') stats.homePasses += 1;
          else stats.awayPasses += 1;

          const passDist = dist(owner.x, owner.y, chosen.x, chosen.y) || 1;
          const passSpeed = clamp(passDist * 0.14, 2.2, 4.8);
          const dx = chosen.x - owner.x;
          const dy = chosen.y - owner.y;
          const passSkill = (carrierData?.attributes.passing ?? 12) + (carrierData?.attributes.vision ?? 12);
          const errorAngle = (rng() - 0.5) * clamp(0.28 - passSkill * 0.006, 0.04, 0.25);
          const angle = Math.atan2(dy, dx) + errorAngle;

          ball.ownerId = null;
          ball.vx = Math.cos(angle) * passSpeed;
          ball.vy = Math.sin(angle) * passSpeed;
          ball.lastTouchTeam = owner.team;
          ball.lastTouchPlayerId = owner.playerId;
        }
      }
    }
  }

  return {
    ...state,
    tick: nextTick,
    minute: currentMinute,
    phase,
    homeScore,
    awayScore,
    agents,
    ball,
    stats,
    events: events.slice(0, 80),
    goalBanner,
    userShoutCooldown: Math.max(0, state.userShoutCooldown - 1),
  };
}

export function applyMatchSubstitution(
  state: LiveMatchState,
  team: 'home' | 'away',
  outPlayerId: string,
  inPlayer: Player
): LiveMatchState {
  const subsUsed = team === 'home' ? state.homeSubsUsed : state.awaySubsUsed;
  if (subsUsed >= 5) return state;

  const outIdx = state.agents.findIndex((a) => a.playerId === outPlayerId && a.team === team);
  if (outIdx === -1) return state;
  const outAgent = state.agents[outIdx];
  if (outAgent.redCard) return state;

  const newAgent: MatchAgent = {
    ...outAgent,
    playerId: inPlayer.id,
    name: inPlayer.name,
    shirtNumber: inPlayer.shirtNumber,
    ovr: inPlayer.ovr,
    stamina: Math.max(85, inPlayer.condition),
    yellowCard: false,
    redCard: false,
    goals: 0,
    assists: 0,
    shots: 0,
    passesCompleted: 0,
    passesAttempted: 0,
    tackles: 0,
    rating: 6.6,
  };

  const nextAgents = [...state.agents];
  nextAgents[outIdx] = newAgent;

  const nextBench = (team === 'home' ? state.homeBenchIds : state.awayBenchIds).filter(
    (id) => id !== inPlayer.id
  );

  const nextBall = { ...state.ball };
  if (nextBall.ownerId === outPlayerId) {
    nextBall.ownerId = inPlayer.id;
  }

  const nextEvents: MatchEvent[] = [
    {
      id: `ev_sub_${state.tick}_${inPlayer.id}`,
      minute: state.minute,
      type: 'substitution',
      team,
      text: `Thay người: ${inPlayer.name} vào sân thay cho ${outAgent.name}.`,
    },
    ...state.events,
  ];

  return {
    ...state,
    agents: nextAgents,
    ball: nextBall,
    homeSubsUsed: team === 'home' ? subsUsed + 1 : state.homeSubsUsed,
    awaySubsUsed: team === 'away' ? subsUsed + 1 : state.awaySubsUsed,
    homeBenchIds: team === 'home' ? nextBench : state.homeBenchIds,
    awayBenchIds: team === 'away' ? nextBench : state.awayBenchIds,
    events: nextEvents,
  };
}

export function applyHalfTimeTalk(
  state: LiveMatchState,
  userTeam: 'home' | 'away',
  tone: 'encourage' | 'demand' | 'calm'
): LiveMatchState {
  const boost = tone === 'demand' ? 0.35 : tone === 'encourage' ? 0.25 : 0.2;
  const staminaLift = tone === 'calm' ? 8 : 5;

  const nextAgents = state.agents.map((a) => {
    if (a.team !== userTeam || a.redCard) return a;
    return {
      ...a,
      stamina: clamp(a.stamina + staminaLift, 20, 100),
      rating: clamp(a.rating + boost, 5, 10),
    };
  });

  const label =
    tone === 'encourage'
      ? 'Động viên tinh thần toàn đội'
      : tone === 'demand'
      ? 'Yêu cầu các học trò chơi quyết liệt hơn'
      : 'Giữ cái đầu lạnh và kiểm soát thế trận';

  return {
    ...state,
    phase: 'second_half',
    minute: 46,
    tick: 45 * TICKS_PER_MINUTE,
    halfTimeTalkDone: true,
    agents: nextAgents,
    events: [
      {
        id: `ev_2h_${Date.now()}`,
        minute: 46,
        type: 'kickoff',
        team: 'neutral',
        text: `Hiệp 2 bắt đầu! HLV chỉ đạo trong giờ nghỉ: "${label}".`,
      },
      ...state.events,
    ],
  };
}

export function applyTouchlineShout(
  state: LiveMatchState,
  userTeam: 'home' | 'away',
  shout: 'Hét cổ vũ' | 'Tập trung phòng ngự' | 'Đẩy cao pressing'
): LiveMatchState {
  if (state.userShoutCooldown > 0) return state;
  const nextAgents = state.agents.map((a) =>
    a.team === userTeam && !a.redCard ? { ...a, rating: clamp(a.rating + 0.15, 5, 10) } : a
  );
  return {
    ...state,
    agents: nextAgents,
    userShoutCooldown: 80,
    activeShout: shout,
    events: [
      {
        id: `ev_shout_${state.tick}`,
        minute: state.minute,
        type: 'kickoff',
        team: userTeam,
        text: `Chỉ đạo đường biên: "${shout}" — Các cầu thủ phản ứng tích cực.`,
      },
      ...state.events,
    ],
  };
}

export function resolveAIMatchFast(
  fixture: Fixture,
  homeClub: Club,
  awayClub: Club,
  players: Record<string, Player>,
  rng: () => number = Math.random
): Fixture {
  const homeR = calculateTeamRatings(homeClub, players);
  const awayR = calculateTeamRatings(awayClub, players);

  const homeStrength = homeR.overall + 2.5 + (homeR.attack - awayR.defense) * 0.25;
  const awayStrength = awayR.overall + (awayR.attack - homeR.defense) * 0.25;

  const homeLambda = clamp(1.35 + (homeStrength - awayStrength) * 0.085, 0.35, 3.6);
  const awayLambda = clamp(1.15 + (awayStrength - homeStrength) * 0.085, 0.25, 3.3);

  const samplePoisson = (lambda: number) => {
    const L = Math.exp(-lambda);
    let k = 0;
    let p = 1;
    do {
      k++;
      p *= rng();
    } while (p > L && k < 8);
    return k - 1;
  };

  const homeGoals = samplePoisson(homeLambda);
  const awayGoals = samplePoisson(awayLambda);

  const pickScorers = (club: Club, count: number) => {
    const lineup = club.tactics.lineupIds
      .map((id) => (id ? players[id] : undefined))
      .filter((p): p is Player => Boolean(p && p.primaryPosition !== 'GK'));
    const weighted: Player[] = [];
    for (const p of lineup) {
      const w = p.primaryPosition === 'ST' ? 6 : p.primaryPosition === 'LW' || p.primaryPosition === 'RW' || p.primaryPosition === 'AM' ? 4 : 1;
      for (let i = 0; i < w; i++) weighted.push(p);
    }
    const events: NonNullable<Fixture['goalEvents']> = [];
    for (let i = 0; i < count; i++) {
      const scorer = weighted[Math.floor(rng() * weighted.length)] ?? lineup[0];
      const assister = weighted[Math.floor(rng() * weighted.length)];
      if (scorer) {
        events.push({
          minute: 1 + Math.floor(rng() * 89),
          playerId: scorer.id,
          playerName: scorer.name,
          assistPlayerName: assister && assister.id !== scorer.id ? assister.name : undefined,
          clubId: club.id,
        });
      }
    }
    return events;
  };

  const goalEvents = [
    ...pickScorers(homeClub, homeGoals),
    ...pickScorers(awayClub, awayGoals),
  ].sort((a, b) => a.minute - b.minute);

  return {
    ...fixture,
    played: true,
    homeGoals,
    awayGoals,
    homeXg: Math.round((homeLambda * (0.75 + rng() * 0.5)) * 100) / 100,
    awayXg: Math.round((awayLambda * (0.75 + rng() * 0.5)) * 100) / 100,
    goalEvents,
  };
}
