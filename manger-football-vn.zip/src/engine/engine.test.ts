import test from 'node:test';
import assert from 'node:assert/strict';
import { LEAGUE_ORDER, createInitialDatabase } from '../data/database';
import {
  createNewCareer,
  generateLeagueFixtures,
  sortStandings,
  commitUserMatchResult,
  advanceToNextSeason,
  getLeagueDef,
} from './schedule';
import { getPositionFamiliarity, calculateTeamRatings } from './tactics';
import { evaluateTransferBid, evaluateContractOffer, executeTransfer } from './transfers';
import {
  createLiveMatchState,
  stepMatchTick,
  applyHalfTimeTalk,
  applyMatchSubstitution,
} from './matchEngine';

test('multi-league database creates 6 national leagues with 10 clubs and >= 18 players each', () => {
  const { clubs, players } = createInitialDatabase();
  assert.equal(Object.keys(clubs).length, 60);

  for (const lid of LEAGUE_ORDER) {
    const leagueClubs = Object.values(clubs).filter((c) => c.leagueId === lid);
    assert.equal(leagueClubs.length, 10, `League ${lid} should have 10 clubs`);
    for (const c of leagueClubs) {
      const squad = Object.values(players).filter((p) => p.clubId === c.id);
      assert.ok(squad.length >= 18, `Club ${c.name} should have at least 18 players`);
      assert.equal(c.tactics.lineupIds.length, 11);
    }
  }
});

test('custom club starts in the lowest division (div_3) of the chosen country pyramid', () => {
  const career = createNewCareer('HLV Minh', {
    type: 'custom',
    config: {
      name: 'Saigon Titans FC',
      shortName: 'SGT',
      city: 'TP.HCM',
      stadium: 'Thống Nhất Arena',
      capacity: 15000,
      leagueId: 'vie_vleague',
      primaryColor: '#10B981',
      secondaryColor: '#0F172A',
      crestPattern: 'chevron',
      tier: 'midtable',
      formation: '4-3-3 DM',
      starPlayerName: 'Nguyễn Minh Vũ',
    },
  });

  const userClub = career.clubs[career.userClubId];
  assert.equal(userClub.name, 'Saigon Titans FC');
  assert.equal(userClub.leagueId, 'div_3');
  assert.equal(career.activeLeagueId, 'div_3');
  assert.equal(career.countryLeagueId, 'vie_vleague');
  assert.equal(getLeagueDef(career, 'div_3').name, 'Giải Hạng Nhì QG');
  assert.equal(getLeagueDef(career, 'div_2').name, 'Giải Hạng Nhất QG');
  assert.equal(career.fixturesByLeague.div_3.length, 90);
  assert.equal(career.standingsByLeague.div_3.length, 10);
  assert.equal(career.standingsByLeague.div_2.length, 10);
  assert.equal(career.standingsByLeague.vie_vleague.length, 10);

  const squad = Object.values(career.players).filter((p) => p.clubId === career.userClubId);
  assert.ok(squad.some((p) => p.name === 'Nguyễn Minh Vũ'));
});

test('end-of-season promotion moves custom club from div_3 to div_2 and div_2 to top league', () => {
  let career = createNewCareer('HLV Leo Hang', {
    type: 'custom',
    config: {
      name: 'Hanoi Dragons',
      shortName: 'HND',
      city: 'Hà Nội',
      stadium: 'Dragons Park',
      capacity: 15000,
      leagueId: 'vie_vleague',
      primaryColor: '#EF4444',
      secondaryColor: '#111827',
      crestPattern: 'stripes',
      tier: 'tycoon',
      formation: '4-3-3 DM',
      starPlayerName: 'Trần Quang Huy',
    },
  });

  // Mark all matches as played and place user's custom club #1 in div_3
  const playedDiv3 = career.fixturesByLeague.div_3.map((f) => ({
    ...f,
    played: true,
    homeGoals: f.homeClubId === career.userClubId ? 3 : 1,
    awayGoals: f.awayClubId === career.userClubId ? 3 : 0,
  }));
  const forcedStandings3 = [
    { clubId: career.userClubId, played: 18, won: 16, drawn: 2, lost: 0, gf: 45, ga: 10, gd: 35, points: 50, form: ['W', 'W', 'W', 'W', 'W'] as ('W' | 'D' | 'L')[] },
    ...career.standingsByLeague.div_3.filter((r) => r.clubId !== career.userClubId),
  ];

  career = {
    ...career,
    fixturesByLeague: { ...career.fixturesByLeague, div_3: playedDiv3 },
    standingsByLeague: { ...career.standingsByLeague, div_3: forcedStandings3 },
  };

  const season1Advance = advanceToNextSeason(career);
  assert.equal(season1Advance.preview.outcome, 'champion');
  assert.equal(season1Advance.nextState.activeLeagueId, 'div_2');
  assert.equal(season1Advance.nextState.seasonNumber, 2);
  assert.equal(season1Advance.nextState.clubs[career.userClubId].leagueId, 'div_2');
  assert.equal(season1Advance.nextState.standingsByLeague.div_2.length, 10);
  assert.equal(season1Advance.nextState.standingsByLeague.div_3.length, 10);
  assert.equal(season1Advance.nextState.fixturesByLeague.div_2.length, 90);
});

test('round-robin fixtures have no self-matches and balanced home/away counts', () => {
  const ids = ['c1', 'c2', 'c3', 'c4', 'c5', 'c6', 'c7', 'c8', 'c9', 'c10'];
  const fixtures = generateLeagueFixtures(ids, 'eng_pl');
  assert.equal(fixtures.length, 90);
  for (const f of fixtures) {
    assert.notEqual(f.homeClubId, f.awayClubId);
  }
  const homeCounts: Record<string, number> = {};
  for (const f of fixtures) {
    homeCounts[f.homeClubId] = (homeCounts[f.homeClubId] ?? 0) + 1;
  }
  for (const id of ids) {
    assert.equal(homeCounts[id], 9);
  }
});

test('tactical position familiarity rewards natural role and penalizes GK out of position', () => {
  const { clubs, players } = createInitialDatabase();
  const arsenalPlayers = Object.values(players).filter((p) => p.clubId === 'ars');
  const gk = arsenalPlayers.find((p) => p.primaryPosition === 'GK')!;
  const st = arsenalPlayers.find((p) => p.primaryPosition === 'ST')!;

  assert.equal(getPositionFamiliarity(gk, 'GK').multiplier, 1.0);
  assert.ok(getPositionFamiliarity(gk, 'ST').multiplier < 0.5);
  assert.equal(getPositionFamiliarity(st, 'ST').multiplier, 1.0);

  const ratings = calculateTeamRatings(clubs.ars, players);
  assert.ok(ratings.overall >= 70 && ratings.overall <= 95);
});

test('transfer bid evaluation and execution updates club funds and rosters', () => {
  const career = createNewCareer('HLV Test', { type: 'existing', clubId: 'mci' });
  const target = Object.values(career.players).find((p) => p.clubId === 'ars' && p.ovr >= 84)!;
  const ars = career.clubs.ars;

  const lowBid = evaluateTransferBid(target, ars, 5);
  assert.equal(lowBid.decision, 'rejected');

  const highBid = evaluateTransferBid(target, ars, target.marketValue * 1.5);
  assert.equal(highBid.decision, 'accepted');

  const contractOk = evaluateContractOffer(target, career.clubs.mci, target.weeklyWage * 2, 4, 'Đá chính');
  assert.equal(contractOk.accepted, true);

  const after = executeTransfer(career, target.id, 'mci', target.marketValue * 1.2, target.weeklyWage + 20, 4, 'Đá chính');
  assert.equal(after.players[target.id].clubId, 'mci');
  assert.ok(after.clubs.mci.finances.transferBudget < career.clubs.mci.finances.transferBudget);
});

test('live 2D match engine simulates full 90 minutes cleanly with substitutions and stats', () => {
  const career = createNewCareer('HLV Match', { type: 'existing', clubId: 'ars' });
  const fixture = career.fixturesByLeague.eng_pl[0];
  const home = career.clubs[fixture.homeClubId];
  const away = career.clubs[fixture.awayClubId];

  let match = createLiveMatchState(fixture, home, away, career.players);
  assert.equal(match.agents.length, 22);

  // Simulate first half
  let guard = 0;
  while (match.phase === 'first_half' && guard < 800) {
    match = stepMatchTick(match, home, away, career.players, () => 0.42);
    guard++;
  }
  assert.equal(match.phase, 'half_time');

  // Make a substitution & half-time talk
  const subInId = match.homeBenchIds[0];
  const outAgent = match.agents.find((a) => a.team === 'home' && a.position !== 'GK')!;
  match = applyMatchSubstitution(match, 'home', outAgent.playerId, career.players[subInId]);
  assert.equal(match.homeSubsUsed, 1);
  assert.ok(match.agents.some((a) => a.playerId === subInId));

  match = applyHalfTimeTalk(match, 'home', 'encourage');
  assert.equal(match.phase, 'second_half');

  // Simulate second half
  guard = 0;
  while (match.phase === 'second_half' && guard < 800) {
    match = stepMatchTick(match, home, away, career.players, () => 0.45);
    guard++;
  }
  assert.equal(match.phase, 'full_time');
  assert.ok(Number.isFinite(match.ball.x) && Number.isFinite(match.ball.y));
  assert.ok(match.stats.homeXg >= 0 && match.stats.awayXg >= 0);

  const afterCommit = commitUserMatchResult(career, match);
  const updatedFix = afterCommit.fixturesByLeague.eng_pl.find((f) => f.id === fixture.id)!;
  assert.equal(updatedFix.played, true);
  assert.equal(sortStandings(afterCommit.standingsByLeague.eng_pl, afterCommit.clubs).length, 10);
});
