import {
  Club,
  CrestPattern,
  CustomClubConfig,
  FormationName,
  LeagueDefinition,
  LeagueId,
  Player,
  PlayerAttributes,
  Position,
  SquadRole,
  TacticalSlot,
  TeamTactics,
} from '../types/fm';

export const LEAGUES: Record<LeagueId, LeagueDefinition> = {
  eng_pl: {
    id: 'eng_pl',
    name: 'Premier League',
    country: 'Anh',
    shortName: 'EPL',
    tierLabel: 'Giải Ngoại Hạng Anh',
    reputation: 96,
    prizeMoneyFirst: 165,
    championsSlots: 4,
    relegationSlots: 2,
    accentColor: '#38BDF8',
  },
  esp_laliga: {
    id: 'esp_laliga',
    name: 'La Liga EA Sports',
    country: 'Tây Ban Nha',
    shortName: 'LAL',
    tierLabel: 'Giải VĐQG Tây Ban Nha',
    reputation: 94,
    prizeMoneyFirst: 145,
    championsSlots: 4,
    relegationSlots: 2,
    accentColor: '#F59E0B',
  },
  ita_seriea: {
    id: 'ita_seriea',
    name: 'Serie A Enilive',
    country: 'Ý',
    shortName: 'SER',
    tierLabel: 'Giải VĐQG Ý',
    reputation: 91,
    prizeMoneyFirst: 115,
    championsSlots: 4,
    relegationSlots: 2,
    accentColor: '#60A5FA',
  },
  ger_bundesliga: {
    id: 'ger_bundesliga',
    name: 'Bundesliga',
    country: 'Đức',
    shortName: 'BUN',
    tierLabel: 'Giải VĐQG Đức',
    reputation: 91,
    prizeMoneyFirst: 120,
    championsSlots: 4,
    relegationSlots: 2,
    accentColor: '#F87171',
  },
  fra_ligue1: {
    id: 'fra_ligue1',
    name: 'Ligue 1 McDonald’s',
    country: 'Pháp',
    shortName: 'L1',
    tierLabel: 'Giải VĐQG Pháp',
    reputation: 87,
    prizeMoneyFirst: 95,
    championsSlots: 3,
    relegationSlots: 2,
    accentColor: '#34D399',
  },
  vie_vleague: {
    id: 'vie_vleague',
    name: 'LPBank V.League 1',
    country: 'Việt Nam',
    shortName: 'VL1',
    tierLabel: 'Giải VĐQG Việt Nam',
    tierLevel: 1,
    reputation: 74,
    prizeMoneyFirst: 12,
    championsSlots: 2,
    promotionSlots: 0,
    relegationSlots: 2,
    accentColor: '#EF4444',
  },
  div_2: {
    id: 'div_2',
    name: 'Giải Hạng Nhì',
    country: 'Quốc gia',
    shortName: 'H2',
    tierLabel: 'Giải Hạng 2',
    tierLevel: 2,
    reputation: 64,
    prizeMoneyFirst: 18,
    championsSlots: 0,
    promotionSlots: 2,
    relegationSlots: 2,
    accentColor: '#10B981',
  },
  div_3: {
    id: 'div_3',
    name: 'Giải Hạng Ba',
    country: 'Quốc gia',
    shortName: 'H3',
    tierLabel: 'Giải Hạng Thấp Nhất',
    tierLevel: 3,
    reputation: 52,
    prizeMoneyFirst: 6,
    championsSlots: 0,
    promotionSlots: 2,
    relegationSlots: 0,
    accentColor: '#94A3B8',
  },
};

export const LEAGUE_ORDER: LeagueId[] = [
  'eng_pl',
  'esp_laliga',
  'ita_seriea',
  'ger_bundesliga',
  'fra_ligue1',
  'vie_vleague',
];

export const FORMATIONS: Record<FormationName, TacticalSlot[]> = {
  '4-3-3 DM': [
    { slotIndex: 0, label: 'TM', position: 'GK', role: 'Thủ môn quét (SK)', duty: 'Phòng ngự', x: 50, y: 92 },
    { slotIndex: 1, label: 'HVT', position: 'LB', role: 'Hậu vệ biên tấn công (WB)', duty: 'Hỗ trợ', x: 14, y: 74 },
    { slotIndex: 2, label: 'TVT', position: 'CB', role: 'Trung vệ chơi bóng (BPD)', duty: 'Phòng ngự', x: 36, y: 77 },
    { slotIndex: 3, label: 'TVP', position: 'CB', role: 'Trung vệ dập (CD)', duty: 'Phòng ngự', x: 64, y: 77 },
    { slotIndex: 4, label: 'HVP', position: 'RB', role: 'Hậu vệ biên bó trong (IWB)', duty: 'Hỗ trợ', x: 86, y: 74 },
    { slotIndex: 5, label: 'TVPN', position: 'DM', role: 'Mỏ neo (A)', duty: 'Phòng ngự', x: 50, y: 58 },
    { slotIndex: 6, label: 'TVTT', position: 'CM', role: 'Tiền vệ con thoi (BBM)', duty: 'Hỗ trợ', x: 31, y: 45 },
    { slotIndex: 7, label: 'TVTP', position: 'CM', role: 'Mezzala (MEZ)', duty: 'Tấn công', x: 69, y: 45 },
    { slotIndex: 8, label: 'TĐCT', position: 'LW', role: 'Tiền đạo cánh nghịch chân (IW)', duty: 'Tấn công', x: 18, y: 24 },
    { slotIndex: 9, label: 'TĐCP', position: 'RW', role: 'Tiền đạo cánh bó trong (IF)', duty: 'Tấn công', x: 82, y: 24 },
    { slotIndex: 10, label: 'TĐC', position: 'ST', role: 'Tiền đạo cắm (AF)', duty: 'Tấn công', x: 50, y: 14 },
  ],
  '4-2-3-1': [
    { slotIndex: 0, label: 'TM', position: 'GK', role: 'Thủ môn quét (SK)', duty: 'Phòng ngự', x: 50, y: 92 },
    { slotIndex: 1, label: 'HVT', position: 'LB', role: 'Hậu vệ biên tấn công (WB)', duty: 'Hỗ trợ', x: 14, y: 75 },
    { slotIndex: 2, label: 'TVT', position: 'CB', role: 'Trung vệ chơi bóng (BPD)', duty: 'Phòng ngự', x: 36, y: 78 },
    { slotIndex: 3, label: 'TVP', position: 'CB', role: 'Trung vệ dập (CD)', duty: 'Phòng ngự', x: 64, y: 78 },
    { slotIndex: 4, label: 'HVP', position: 'RB', role: 'Hậu vệ biên (FB)', duty: 'Hỗ trợ', x: 86, y: 75 },
    { slotIndex: 5, label: 'TVPNT', position: 'DM', role: 'Kiến thiết lùi sâu (DLP)', duty: 'Phòng ngự', x: 36, y: 58 },
    { slotIndex: 6, label: 'TVPNP', position: 'DM', role: 'Máy quét (BWM)', duty: 'Hỗ trợ', x: 64, y: 58 },
    { slotIndex: 7, label: 'TĐCT', position: 'LW', role: 'Tiền đạo cánh nghịch chân (IW)', duty: 'Tấn công', x: 17, y: 34 },
    { slotIndex: 8, label: 'TVTC', position: 'AM', role: 'Số 10 kiến thiết (AP)', duty: 'Tấn công', x: 50, y: 34 },
    { slotIndex: 9, label: 'TĐCP', position: 'RW', role: 'Tiền đạo cánh bó trong (IF)', duty: 'Tấn công', x: 83, y: 34 },
    { slotIndex: 10, label: 'TĐC', position: 'ST', role: 'Tiền đạo toàn diện (CF)', duty: 'Tấn công', x: 50, y: 14 },
  ],
  '4-4-2': [
    { slotIndex: 0, label: 'TM', position: 'GK', role: 'Thủ môn cổ điển (GK)', duty: 'Phòng ngự', x: 50, y: 92 },
    { slotIndex: 1, label: 'HVT', position: 'LB', role: 'Hậu vệ biên (FB)', duty: 'Hỗ trợ', x: 14, y: 75 },
    { slotIndex: 2, label: 'TVT', position: 'CB', role: 'Trung vệ dập (CD)', duty: 'Phòng ngự', x: 36, y: 77 },
    { slotIndex: 3, label: 'TVP', position: 'CB', role: 'Trung vệ dập (CD)', duty: 'Phòng ngự', x: 64, y: 77 },
    { slotIndex: 4, label: 'HVP', position: 'RB', role: 'Hậu vệ biên (FB)', duty: 'Hỗ trợ', x: 86, y: 75 },
    { slotIndex: 5, label: 'TVCT', position: 'LW', role: 'Tiền vệ cánh (W)', duty: 'Hỗ trợ', x: 15, y: 47 },
    { slotIndex: 6, label: 'TVTT', position: 'CM', role: 'Kiến thiết lùi sâu (DLP)', duty: 'Hỗ trợ', x: 38, y: 50 },
    { slotIndex: 7, label: 'TVTP', position: 'CM', role: 'Tiền vệ con thoi (BBM)', duty: 'Hỗ trợ', x: 62, y: 50 },
    { slotIndex: 8, label: 'TVCP', position: 'RW', role: 'Tiền vệ cánh (W)', duty: 'Hỗ trợ', x: 85, y: 47 },
    { slotIndex: 9, label: 'TĐT', position: 'ST', role: 'Tiền đạo lùi (DLF)', duty: 'Hỗ trợ', x: 37, y: 17 },
    { slotIndex: 10, label: 'TĐP', position: 'ST', role: 'Tiền đạo cắm (AF)', duty: 'Tấn công', x: 63, y: 17 },
  ],
  '3-5-2': [
    { slotIndex: 0, label: 'TM', position: 'GK', role: 'Thủ môn quét (SK)', duty: 'Phòng ngự', x: 50, y: 92 },
    { slotIndex: 1, label: 'TVT', position: 'CB', role: 'Trung vệ lệch biên (WCB)', duty: 'Phòng ngự', x: 26, y: 76 },
    { slotIndex: 2, label: 'TVG', position: 'CB', role: 'Trung vệ chơi bóng (BPD)', duty: 'Phòng ngự', x: 50, y: 78 },
    { slotIndex: 3, label: 'TVP', position: 'CB', role: 'Trung vệ lệch biên (WCB)', duty: 'Phòng ngự', x: 74, y: 76 },
    { slotIndex: 4, label: 'CWT', position: 'LB', role: 'Wing-Back tấn công (CWB)', duty: 'Tấn công', x: 12, y: 50 },
    { slotIndex: 5, label: 'TVPN', position: 'DM', role: 'Regista (REG)', duty: 'Hỗ trợ', x: 50, y: 58 },
    { slotIndex: 6, label: 'TVTT', position: 'CM', role: 'Tiền vệ con thoi (BBM)', duty: 'Hỗ trợ', x: 33, y: 43 },
    { slotIndex: 7, label: 'TVTP', position: 'CM', role: 'Mezzala (MEZ)', duty: 'Tấn công', x: 67, y: 43 },
    { slotIndex: 8, label: 'CWP', position: 'RB', role: 'Wing-Back tấn công (CWB)', duty: 'Tấn công', x: 88, y: 50 },
    { slotIndex: 9, label: 'TĐT', position: 'ST', role: 'Tiền đạo lùi (DLF)', duty: 'Hỗ trợ', x: 37, y: 16 },
    { slotIndex: 10, label: 'TĐP', position: 'ST', role: 'Săn bàn (P)', duty: 'Tấn công', x: 63, y: 16 },
  ],
  '3-4-2-1': [
    { slotIndex: 0, label: 'TM', position: 'GK', role: 'Thủ môn quét (SK)', duty: 'Phòng ngự', x: 50, y: 92 },
    { slotIndex: 1, label: 'TVT', position: 'CB', role: 'Trung vệ lệch biên (WCB)', duty: 'Hỗ trợ', x: 26, y: 76 },
    { slotIndex: 2, label: 'TVG', position: 'CB', role: 'Trung vệ chơi bóng (BPD)', duty: 'Phòng ngự', x: 50, y: 78 },
    { slotIndex: 3, label: 'TVP', position: 'CB', role: 'Trung vệ lệch biên (WCB)', duty: 'Hỗ trợ', x: 74, y: 76 },
    { slotIndex: 4, label: 'CWT', position: 'LB', role: 'Wing-Back tấn công (CWB)', duty: 'Tấn công', x: 12, y: 53 },
    { slotIndex: 5, label: 'TVTT', position: 'CM', role: 'Kiến thiết lùi sâu (DLP)', duty: 'Hỗ trợ', x: 37, y: 54 },
    { slotIndex: 6, label: 'TVTP', position: 'CM', role: 'Tiền vệ con thoi (BBM)', duty: 'Hỗ trợ', x: 63, y: 54 },
    { slotIndex: 7, label: 'CWP', position: 'RB', role: 'Wing-Back tấn công (CWB)', duty: 'Tấn công', x: 88, y: 53 },
    { slotIndex: 8, label: 'TCT', position: 'AM', role: 'Số 10 lệch trái (AM)', duty: 'Tấn công', x: 32, y: 31 },
    { slotIndex: 9, label: 'TCP', position: 'AM', role: 'Tiền đạo ẩn (SS)', duty: 'Tấn công', x: 68, y: 31 },
    { slotIndex: 10, label: 'TĐC', position: 'ST', role: 'Tiền đạo toàn diện (CF)', duty: 'Tấn công', x: 50, y: 14 },
  ],
  '4-1-4-1': [
    { slotIndex: 0, label: 'TM', position: 'GK', role: 'Thủ môn cổ điển (GK)', duty: 'Phòng ngự', x: 50, y: 92 },
    { slotIndex: 1, label: 'HVT', position: 'LB', role: 'Hậu vệ biên (FB)', duty: 'Phòng ngự', x: 14, y: 75 },
    { slotIndex: 2, label: 'TVT', position: 'CB', role: 'Trung vệ dập (CD)', duty: 'Phòng ngự', x: 36, y: 77 },
    { slotIndex: 3, label: 'TVP', position: 'CB', role: 'Trung vệ dập (CD)', duty: 'Phòng ngự', x: 64, y: 77 },
    { slotIndex: 4, label: 'HVP', position: 'RB', role: 'Hậu vệ biên (FB)', duty: 'Phòng ngự', x: 86, y: 75 },
    { slotIndex: 5, label: 'TVPN', position: 'DM', role: 'Mỏ neo (A)', duty: 'Phòng ngự', x: 50, y: 60 },
    { slotIndex: 6, label: 'TVCT', position: 'LW', role: 'Tiền vệ cánh (W)', duty: 'Hỗ trợ', x: 15, y: 40 },
    { slotIndex: 7, label: 'TVTT', position: 'CM', role: 'Tiền vệ con thoi (BBM)', duty: 'Hỗ trợ', x: 38, y: 43 },
    { slotIndex: 8, label: 'TVTP', position: 'CM', role: 'Mezzala (MEZ)', duty: 'Tấn công', x: 62, y: 43 },
    { slotIndex: 9, label: 'TVCP', position: 'RW', role: 'Tiền vệ cánh (W)', duty: 'Hỗ trợ', x: 85, y: 40 },
    { slotIndex: 10, label: 'TĐC', position: 'ST', role: 'Tiền đạo mục tiêu (TF)', duty: 'Tấn công', x: 50, y: 15 },
  ],
  '5-3-2': [
    { slotIndex: 0, label: 'TM', position: 'GK', role: 'Thủ môn cổ điển (GK)', duty: 'Phòng ngự', x: 50, y: 92 },
    { slotIndex: 1, label: 'HVT', position: 'LB', role: 'Wing-Back (WB)', duty: 'Hỗ trợ', x: 12, y: 69 },
    { slotIndex: 2, label: 'TVT', position: 'CB', role: 'Trung vệ dập (CD)', duty: 'Phòng ngự', x: 30, y: 77 },
    { slotIndex: 3, label: 'TVG', position: 'CB', role: 'Trung vệ bọc lót (CD)', duty: 'Phòng ngự', x: 50, y: 79 },
    { slotIndex: 4, label: 'TVP', position: 'CB', role: 'Trung vệ dập (CD)', duty: 'Phòng ngự', x: 70, y: 77 },
    { slotIndex: 5, label: 'HVP', position: 'RB', role: 'Wing-Back (WB)', duty: 'Hỗ trợ', x: 88, y: 69 },
    { slotIndex: 6, label: 'TVTT', position: 'CM', role: 'Máy quét (BWM)', duty: 'Phòng ngự', x: 32, y: 48 },
    { slotIndex: 7, label: 'TVG', position: 'CM', role: 'Kiến thiết lùi sâu (DLP)', duty: 'Hỗ trợ', x: 50, y: 52 },
    { slotIndex: 8, label: 'TVTP', position: 'CM', role: 'Tiền vệ con thoi (BBM)', duty: 'Tấn công', x: 68, y: 48 },
    { slotIndex: 9, label: 'TĐT', position: 'ST', role: 'Tiền đạo lùi (DLF)', duty: 'Hỗ trợ', x: 37, y: 17 },
    { slotIndex: 10, label: 'TĐP', position: 'ST', role: 'Tiền đạo cắm (AF)', duty: 'Tấn công', x: 63, y: 17 },
  ],
};

export const ROLES_BY_POSITION: Record<Position, string[]> = {
  GK: ['Thủ môn quét (SK)', 'Thủ môn cổ điển (GK)'],
  LB: ['Hậu vệ biên tấn công (WB)', 'Hậu vệ biên (FB)', 'Wing-Back tấn công (CWB)', 'Hậu vệ biên bó trong (IWB)'],
  RB: ['Hậu vệ biên tấn công (WB)', 'Hậu vệ biên (FB)', 'Wing-Back tấn công (CWB)', 'Hậu vệ biên bó trong (IWB)'],
  CB: ['Trung vệ chơi bóng (BPD)', 'Trung vệ dập (CD)', 'Trung vệ bọc lót (CD)', 'Trung vệ lệch biên (WCB)'],
  DM: ['Mỏ neo (A)', 'Kiến thiết lùi sâu (DLP)', 'Máy quét (BWM)', 'Regista (REG)'],
  CM: ['Tiền vệ con thoi (BBM)', 'Mezzala (MEZ)', 'Kiến thiết lùi sâu (DLP)', 'Máy quét (BWM)', 'Tiền vệ trung tâm (CM)'],
  AM: ['Số 10 kiến thiết (AP)', 'Tiền đạo ẩn (SS)', 'Số 10 lệch trái (AM)', 'Enganche (ENG)'],
  LW: ['Tiền đạo cánh nghịch chân (IW)', 'Tiền đạo cánh bó trong (IF)', 'Tiền vệ cánh (W)', 'Raumdeuter (RMD)'],
  RW: ['Tiền đạo cánh bó trong (IF)', 'Tiền đạo cánh nghịch chân (IW)', 'Tiền vệ cánh (W)', 'Raumdeuter (RMD)'],
  ST: ['Tiền đạo cắm (AF)', 'Tiền đạo toàn diện (CF)', 'Tiền đạo lùi (DLF)', 'Săn bàn (P)', 'Tiền đạo mục tiêu (TF)'],
};

function clampAttr(v: number): number {
  return Math.max(1, Math.min(20, Math.round(v)));
}

function buildAttributes(pos: Position, tier: number, styleOffset = 0): PlayerAttributes {
  const base = tier;
  const o = (delta: number) => clampAttr(base + delta + ((styleOffset % 3) - 1));

  if (pos === 'GK') {
    return {
      finishing: o(-11), passing: o(-3), dribbling: o(-8), firstTouch: o(-4),
      tackling: o(-10), marking: o(-10), crossing: o(-11), technique: o(-5),
      longShots: o(-11), heading: o(-7),
      vision: o(-3), decisions: o(0), composure: o(0), positioning: o(1),
      offTheBall: o(-10), workRate: o(-3), determination: o(1), leadership: o(0),
      pace: o(-6), acceleration: o(-5), stamina: o(-4), strength: o(-1), agility: o(0),
      reflexes: o(2), handling: o(2), oneOnOnes: o(1), aerialReach: o(1),
    };
  }
  if (pos === 'CB') {
    return {
      finishing: o(-8), passing: o(-2), dribbling: o(-4), firstTouch: o(-2),
      tackling: o(2), marking: o(2), crossing: o(-6), technique: o(-3),
      longShots: o(-6), heading: o(2),
      vision: o(-3), decisions: o(1), composure: o(0), positioning: o(2),
      offTheBall: o(-6), workRate: o(0), determination: o(1), leadership: o(1),
      pace: o(-1), acceleration: o(-1), stamina: o(0), strength: o(2), agility: o(-2),
      reflexes: 2, handling: 2, oneOnOnes: 2, aerialReach: 3,
    };
  }
  if (pos === 'LB' || pos === 'RB') {
    return {
      finishing: o(-6), passing: o(0), dribbling: o(0), firstTouch: o(0),
      tackling: o(1), marking: o(0), crossing: o(2), technique: o(0),
      longShots: o(-4), heading: o(-3),
      vision: o(-1), decisions: o(0), composure: o(-1), positioning: o(0),
      offTheBall: o(0), workRate: o(2), determination: o(0), leadership: o(-2),
      pace: o(2), acceleration: o(2), stamina: o(2), strength: o(-1), agility: o(1),
      reflexes: 2, handling: 2, oneOnOnes: 2, aerialReach: 2,
    };
  }
  if (pos === 'DM') {
    return {
      finishing: o(-5), passing: o(2), dribbling: o(0), firstTouch: o(1),
      tackling: o(2), marking: o(1), crossing: o(-3), technique: o(1),
      longShots: o(0), heading: o(-2),
      vision: o(1), decisions: o(2), composure: o(2), positioning: o(2),
      offTheBall: o(-2), workRate: o(2), determination: o(1), leadership: o(1),
      pace: o(-2), acceleration: o(-1), stamina: o(2), strength: o(1), agility: o(-1),
      reflexes: 2, handling: 2, oneOnOnes: 2, aerialReach: 2,
    };
  }
  if (pos === 'CM') {
    return {
      finishing: o(-3), passing: o(2), dribbling: o(1), firstTouch: o(2),
      tackling: o(0), marking: o(-1), crossing: o(-1), technique: o(2),
      longShots: o(1), heading: o(-3),
      vision: o(2), decisions: o(1), composure: o(1), positioning: o(0),
      offTheBall: o(1), workRate: o(2), determination: o(1), leadership: o(0),
      pace: o(-1), acceleration: o(0), stamina: o(2), strength: o(-1), agility: o(1),
      reflexes: 2, handling: 2, oneOnOnes: 2, aerialReach: 2,
    };
  }
  if (pos === 'AM') {
    return {
      finishing: o(0), passing: o(2), dribbling: o(2), firstTouch: o(2),
      tackling: o(-6), marking: o(-6), crossing: o(0), technique: o(3),
      longShots: o(1), heading: o(-5),
      vision: o(3), decisions: o(1), composure: o(1), positioning: o(-4),
      offTheBall: o(2), workRate: o(0), determination: o(0), leadership: o(-1),
      pace: o(0), acceleration: o(1), stamina: o(0), strength: o(-3), agility: o(2),
      reflexes: 2, handling: 2, oneOnOnes: 2, aerialReach: 2,
    };
  }
  if (pos === 'LW' || pos === 'RW') {
    return {
      finishing: o(1), passing: o(0), dribbling: o(3), firstTouch: o(2),
      tackling: o(-7), marking: o(-7), crossing: o(1), technique: o(2),
      longShots: o(0), heading: o(-5),
      vision: o(1), decisions: o(0), composure: o(0), positioning: o(-5),
      offTheBall: o(2), workRate: o(0), determination: o(0), leadership: o(-2),
      pace: o(3), acceleration: o(3), stamina: o(1), strength: o(-3), agility: o(3),
      reflexes: 2, handling: 2, oneOnOnes: 2, aerialReach: 2,
    };
  }
  return {
    finishing: o(3), passing: o(-2), dribbling: o(1), firstTouch: o(1),
    tackling: o(-9), marking: o(-9), crossing: o(-4), technique: o(1),
    longShots: o(0), heading: o(1),
    vision: o(-1), decisions: o(0), composure: o(2), positioning: o(-6),
    offTheBall: o(3), workRate: o(0), determination: o(1), leadership: o(-1),
    pace: o(2), acceleration: o(2), stamina: o(0), strength: o(1), agility: o(1),
    reflexes: 2, handling: 2, oneOnOnes: 2, aerialReach: 2,
  };
}

export interface RawPlayerSeed {
  name: string;
  nat: string;
  age: number;
  pos: Position;
  sec: Position[];
  ovr: number;
  pa?: number;
  num: number;
  foot?: 'Phải' | 'Trái' | 'Hai chân';
  height?: number;
  role?: SquadRole;
}

export function makePlayer(
  clubId: string,
  seed: RawPlayerSeed,
  idx: number,
  leagueId: LeagueId,
  countryHint?: string
): Player {
  const ca = Math.round((seed.ovr - 40) * 3.3);
  const pa = seed.pa ? Math.round((seed.pa - 40) * 3.3) : Math.min(198, ca + (seed.age <= 22 ? 18 : 4));
  const tier = 6.5 + (seed.ovr - 56) * 0.34;
  const attrs = buildAttributes(seed.pos, tier, idx);
  const ageFactor = seed.age <= 23 ? 1.25 : seed.age <= 27 ? 1.12 : seed.age <= 30 ? 0.85 : 0.45;
  const rawValue = Math.pow(Math.max(1, seed.ovr - 53), 1.48) * 0.25 * ageFactor;
  const isVN = leagueId === 'vie_vleague' || countryHint === 'Việt Nam';
  const leagueScale = isVN
    ? leagueId === 'div_3'
      ? 0.14
      : leagueId === 'div_2'
      ? 0.22
      : 0.35
    : leagueId === 'div_3'
    ? 0.26
    : leagueId === 'div_2'
    ? 0.55
    : 1;
  const marketValue = Math.max(0.1, Math.round(rawValue * leagueScale * 10) / 10);
  const weeklyWage = Math.max(
    1,
    Math.round(Math.pow(Math.max(1, seed.ovr - 53), 1.38) * 1.15 * leagueScale)
  );

  const starThreshold = leagueId === 'div_3' ? (isVN ? 60 : 65) : leagueId === 'div_2' ? (isVN ? 66 : 73) : isVN ? 74 : 85;
  const starterThreshold = leagueId === 'div_3' ? (isVN ? 55 : 61) : leagueId === 'div_2' ? (isVN ? 62 : 69) : isVN ? 69 : 78;
  const role: SquadRole =
    seed.role ??
    (seed.ovr >= starThreshold
      ? 'Ngôi sao'
      : seed.ovr >= starterThreshold
      ? 'Đá chính'
      : seed.age <= 21
      ? 'Tài năng trẻ'
      : 'Xoay tua');

  return {
    id: `${clubId}_p${idx + 1}`,
    name: seed.name,
    nationality: seed.nat,
    age: seed.age,
    clubId,
    primaryPosition: seed.pos,
    secondaryPositions: seed.sec,
    foot: seed.foot ?? 'Phải',
    heightCm: seed.height ?? (seed.pos === 'GK' ? 190 : seed.pos === 'CB' ? 186 : 177),
    shirtNumber: seed.num,
    ca,
    pa,
    ovr: seed.ovr,
    marketValue,
    weeklyWage,
    contractUntilYear: 2027 + ((idx * 2) % 4),
    squadRole: role,
    condition: 93 + ((idx * 3) % 7),
    sharpness: 85 + ((idx * 5) % 13),
    morale: 75 + ((idx * 4) % 15),
    injuryDays: 0,
    injuryType: null,
    suspendedMatches: 0,
    yellowCardAccumulation: 0,
    transferListed: false,
    scouted: true,
    form: ['W', 'D', 'W'],
    lastFiveRatings: [7.0, 6.8, 7.2],
    attributes: attrs,
    stats: {
      appearances: 0,
      goals: 0,
      assists: 0,
      cleanSheets: 0,
      yellowCards: 0,
      redCards: 0,
      avgRating: 0,
      ratingCount: 0,
      xg: 0,
    },
  };
}

const NAME_POOLS: Record<string, { first: string[]; last: string[] }> = {
  Anh: {
    first: ['Oliver', 'Harry', 'Jack', 'George', 'Noah', 'Charlie', 'Liam', 'Mason', 'Alfie', 'Callum', 'Jude', 'Ethan'],
    last: ['Walker', 'Bennett', 'Hughes', 'Carter', 'Mitchell', 'Brooks', 'Fletcher', 'Ward', 'Palmer', 'Harrison', 'Cole', 'Cooper'],
  },
  'Tây Ban Nha': {
    first: ['Mateo', 'Lucas', 'Hugo', 'Daniel', 'Pablo', 'Alvaro', 'Carlos', 'Diego', 'Sergio', 'Iker', 'Marco', 'Raul'],
    last: ['Garcia', 'Fernandez', 'Lopez', 'Sanchez', 'Moreno', 'Navarro', 'Romero', 'Ruiz', 'Torres', 'Vidal', 'Molina', 'Soler'],
  },
  Ý: {
    first: ['Lorenzo', 'Matteo', 'Alessandro', 'Andrea', 'Francesco', 'Davide', 'Marco', 'Luca', 'Federico', 'Simone', 'Nicolo', 'Giacomo'],
    last: ['Rossi', 'Conti', 'Ricci', 'Marino', 'Moretti', 'Barbieri', 'Lombardi', 'Fontana', 'Bellini', 'Rinaldi', 'Galli', 'Caruso'],
  },
  Đức: {
    first: ['Lukas', 'Leon', 'Jonas', 'Maximilian', 'Felix', 'Tim', 'Julian', 'Niklas', 'Tobias', 'Florian', 'Jan', 'Paul'],
    last: ['Muller', 'Weber', 'Becker', 'Hoffmann', 'Schafer', 'Koch', 'Bauer', 'Richter', 'Klein', 'Wolf', 'Neumann', 'Braun'],
  },
  Pháp: {
    first: ['Lucas', 'Theo', 'Hugo', 'Enzo', 'Mathis', 'Antoine', 'Clement', 'Maxime', 'Julien', 'Romain', 'Adrien', 'Bastien'],
    last: ['Morel', 'Fournier', 'Girard', 'Mercier', 'Lefevre', 'Roux', 'Chevalier', 'Laurent', 'Gauthier', 'Perrin', 'Robin', 'Blanchard'],
  },
  'Việt Nam': {
    first: ['Nguyễn', 'Trần', 'Lê', 'Phạm', 'Hoàng', 'Vũ', 'Phan', 'Đặng', 'Bùi', 'Đỗ', 'Hồ', 'Ngô'],
    last: ['Minh Quang', 'Đức Huy', 'Văn Khánh', 'Tuấn Anh', 'Hữu Thắng', 'Quốc Việt', 'Thành Long', 'Bảo Toàn', 'Gia Hưng', 'Trung Kiên', 'Thanh Bình', 'Xuân Tiến'],
  },
};

const BACKUP_POSITIONS: Position[] = ['GK', 'CB', 'LB', 'CM', 'LW', 'ST', 'RB', 'DM'];

export function fillSquadTo18(
  clubId: string,
  formation: FormationName,
  country: string,
  baseOvr: number,
  seedPlayers: RawPlayerSeed[]
): RawPlayerSeed[] {
  const result = [...seedPlayers];
  const usedNums = new Set(result.map((p) => p.num));
  const usedNames = new Set(result.map((p) => p.name));
  const pool = NAME_POOLS[country] ?? NAME_POOLS['Anh'];

  let hash = 0;
  for (let i = 0; i < clubId.length; i++) hash = (hash * 31 + clubId.charCodeAt(i)) % 997;

  const pickUniqueName = (salt: number) => {
    for (let attempt = 0; attempt < 40; attempt++) {
      const f = pool.first[(salt + attempt) % pool.first.length];
      const l = pool.last[(salt * 7 + attempt * 3 + 1) % pool.last.length];
      const candidate = `${f} ${l}`;
      if (!usedNames.has(candidate)) {
        usedNames.add(candidate);
        return candidate;
      }
    }
    return `${pool.first[salt % pool.first.length]} ${pool.last[(salt + 3) % pool.last.length]} ${salt % 9 + 1}`;
  };

  const addGeneratedPlayer = (pos: Position, isStarter: boolean, salt: number) => {
    let num = ((salt * 3 + 12) % 45) + 1;
    while (usedNums.has(num)) num = (num % 98) + 1;
    usedNums.add(num);

    const age = isStarter ? 22 + ((salt * 5) % 8) : 19 + ((salt * 5) % 12);
    const delta = isStarter ? ((salt % 3)) : -4 + (salt % 3);
    const ovr = Math.max(48, Math.min(92, baseOvr + delta));
    const pa = age <= 22 ? Math.min(93, ovr + 8 + (salt % 6)) : undefined;

    result.push({
      name: pickUniqueName(salt),
      nat: country,
      age,
      pos,
      sec: pos === 'CB' ? ['DM'] : pos === 'LW' ? ['RW'] : pos === 'CM' ? ['DM', 'AM'] : [],
      ovr,
      pa,
      num,
      foot: pos === 'LB' ? 'Trái' : salt % 5 === 0 ? 'Trái' : 'Phải',
    });
  };

  // 1. Fill missing core starting XI positions for this club's formation first
  const formationSlots = FORMATIONS[formation];
  const claimedIndices = new Set<number>();
  for (const slot of formationSlots) {
    const exactIdx = result.findIndex(
      (p, idx) => !claimedIndices.has(idx) && p.pos === slot.position
    );
    if (exactIdx !== -1) {
      claimedIndices.add(exactIdx);
      continue;
    }
    const secIdx = result.findIndex(
      (p, idx) => !claimedIndices.has(idx) && p.sec.includes(slot.position)
    );
    if (secIdx !== -1) {
      claimedIndices.add(secIdx);
      continue;
    }
    // Missing starter position -> generate starter-tier player
    addGeneratedPlayer(slot.position, true, result.length + hash + slot.slotIndex);
    claimedIndices.add(result.length - 1);
  }

  // 2. Ensure at least 2 GKs and fill squad depth to 18
  let cursor = 0;
  while (result.length < 18) {
    const gkCount = result.filter((p) => p.pos === 'GK').length;
    const pos = gkCount < 2 ? 'GK' : BACKUP_POSITIONS[cursor % BACKUP_POSITIONS.length];
    cursor++;
    addGeneratedPlayer(pos, false, result.length + hash + cursor * 5);
  }

  return result;
}

export interface RawClubSeed {
  id: string;
  leagueId: LeagueId;
  name: string;
  shortName: string;
  country: string;
  city: string;
  stadium: string;
  capacity: number;
  reputation: number;
  baseOvr: number;
  primaryColor: string;
  secondaryColor: string;
  crestPattern: CrestPattern;
  expectation: string;
  targetPosition: number;
  balance: number;
  transferBudget: number;
  wageBudgetWeekly: number;
  formation: FormationName;
  mentality: TeamTactics['mentality'];
  pressing: TeamTactics['pressing'];
  passing: TeamTactics['passing'];
  players: RawPlayerSeed[];
}

const CLUB_SEEDS: RawClubSeed[] = [
  // ================= PREMIER LEAGUE (ANH) =================
  {
    id: 'mci', leagueId: 'eng_pl', name: 'Manchester City', shortName: 'MCI', country: 'Anh', city: 'Manchester',
    stadium: 'Etihad Stadium', capacity: 53400, reputation: 94, baseOvr: 85,
    primaryColor: '#6CABDD', secondaryColor: '#1C2C5B', crestPattern: 'sash',
    expectation: 'Vô địch Premier League', targetPosition: 1, balance: 280, transferBudget: 115, wageBudgetWeekly: 4200,
    formation: '4-3-3 DM', mentality: 'Tấn công', pressing: 'Gegenpress', passing: 'Ngắn',
    players: [
      { name: 'Ederson Moraes', nat: 'Brazil', age: 31, pos: 'GK', sec: [], ovr: 87, num: 31, foot: 'Trái' },
      { name: 'Josko Gvardiol', nat: 'Croatia', age: 23, pos: 'LB', sec: ['CB'], ovr: 86, pa: 91, num: 24, foot: 'Trái' },
      { name: 'Ruben Dias', nat: 'Bồ Đào Nha', age: 28, pos: 'CB', sec: [], ovr: 88, num: 3 },
      { name: 'John Stones', nat: 'Anh', age: 31, pos: 'CB', sec: ['DM'], ovr: 85, num: 5 },
      { name: 'Kyle Walker', nat: 'Anh', age: 34, pos: 'RB', sec: ['CB'], ovr: 82, num: 2 },
      { name: 'Rodri Hernandez', nat: 'Tây Ban Nha', age: 29, pos: 'DM', sec: ['CM'], ovr: 91, num: 16 },
      { name: 'Kevin De Bruyne', nat: 'Bỉ', age: 34, pos: 'CM', sec: ['AM'], ovr: 88, num: 17 },
      { name: 'Phil Foden', nat: 'Anh', age: 25, pos: 'AM', sec: ['RW', 'CM', 'LW'], ovr: 89, pa: 92, num: 47, foot: 'Trái' },
      { name: 'Bernardo Silva', nat: 'Bồ Đào Nha', age: 31, pos: 'RW', sec: ['CM', 'AM'], ovr: 87, num: 20, foot: 'Trái' },
      { name: 'Jeremy Doku', nat: 'Bỉ', age: 23, pos: 'LW', sec: ['RW'], ovr: 83, pa: 88, num: 11 },
      { name: 'Erling Haaland', nat: 'Na Uy', age: 25, pos: 'ST', sec: [], ovr: 92, pa: 94, num: 9, foot: 'Trái', height: 195 },
      { name: 'Omar Marmoush', nat: 'Ai Cập', age: 26, pos: 'ST', sec: ['LW'], ovr: 84, num: 7 },
    ],
  },
  {
    id: 'ars', leagueId: 'eng_pl', name: 'Arsenal', shortName: 'ARS', country: 'Anh', city: 'London',
    stadium: 'Emirates Stadium', capacity: 60704, reputation: 91, baseOvr: 84,
    primaryColor: '#EF0107', secondaryColor: '#FFFFFF', crestPattern: 'halves',
    expectation: 'Cạnh tranh ngôi vô địch', targetPosition: 2, balance: 215, transferBudget: 95, wageBudgetWeekly: 3400,
    formation: '4-3-3 DM', mentality: 'Tấn công', pressing: 'Gegenpress', passing: 'Kết hợp',
    players: [
      { name: 'David Raya', nat: 'Tây Ban Nha', age: 30, pos: 'GK', sec: [], ovr: 86, num: 22 },
      { name: 'Riccardo Calafiori', nat: 'Ý', age: 23, pos: 'LB', sec: ['CB'], ovr: 83, pa: 88, num: 33, foot: 'Trái' },
      { name: 'Gabriel Magalhaes', nat: 'Brazil', age: 27, pos: 'CB', sec: [], ovr: 87, num: 6, foot: 'Trái' },
      { name: 'William Saliba', nat: 'Pháp', age: 24, pos: 'CB', sec: [], ovr: 88, pa: 92, num: 2 },
      { name: 'Jurrien Timber', nat: 'Hà Lan', age: 24, pos: 'RB', sec: ['LB', 'CB'], ovr: 84, num: 12 },
      { name: 'Declan Rice', nat: 'Anh', age: 26, pos: 'DM', sec: ['CM'], ovr: 88, num: 41 },
      { name: 'Mikel Merino', nat: 'Tây Ban Nha', age: 29, pos: 'CM', sec: ['DM'], ovr: 83, num: 23, foot: 'Trái' },
      { name: 'Martin Odegaard', nat: 'Na Uy', age: 26, pos: 'AM', sec: ['CM'], ovr: 89, num: 8, foot: 'Trái' },
      { name: 'Gabriel Martinelli', nat: 'Brazil', age: 24, pos: 'LW', sec: ['ST'], ovr: 84, pa: 88, num: 11 },
      { name: 'Bukayo Saka', nat: 'Anh', age: 24, pos: 'RW', sec: ['LW'], ovr: 89, pa: 92, num: 7, foot: 'Trái' },
      { name: 'Kai Havertz', nat: 'Đức', age: 26, pos: 'ST', sec: ['AM'], ovr: 84, num: 29, foot: 'Trái' },
      { name: 'Ethan Nwaneri', nat: 'Anh', age: 18, pos: 'AM', sec: ['RW'], ovr: 78, pa: 90, num: 53, foot: 'Trái' },
    ],
  },
  {
    id: 'liv', leagueId: 'eng_pl', name: 'Liverpool', shortName: 'LIV', country: 'Anh', city: 'Liverpool',
    stadium: 'Anfield', capacity: 61276, reputation: 92, baseOvr: 84,
    primaryColor: '#C8102E', secondaryColor: '#F6EB61', crestPattern: 'solid',
    expectation: 'Cạnh tranh ngôi vô địch', targetPosition: 2, balance: 230, transferBudget: 90, wageBudgetWeekly: 3500,
    formation: '4-2-3-1', mentality: 'Tấn công', pressing: 'Gegenpress', passing: 'Kết hợp',
    players: [
      { name: 'Alisson Becker', nat: 'Brazil', age: 33, pos: 'GK', sec: [], ovr: 89, num: 1 },
      { name: 'Andy Robertson', nat: 'Scotland', age: 31, pos: 'LB', sec: [], ovr: 84, num: 26, foot: 'Trái' },
      { name: 'Virgil van Dijk', nat: 'Hà Lan', age: 34, pos: 'CB', sec: [], ovr: 89, num: 4, height: 195 },
      { name: 'Ibrahima Konate', nat: 'Pháp', age: 26, pos: 'CB', sec: [], ovr: 86, pa: 89, num: 5 },
      { name: 'Trent Alexander-Arnold', nat: 'Anh', age: 27, pos: 'RB', sec: ['CM'], ovr: 87, num: 66 },
      { name: 'Ryan Gravenberch', nat: 'Hà Lan', age: 23, pos: 'DM', sec: ['CM'], ovr: 85, pa: 89, num: 38 },
      { name: 'Alexis Mac Allister', nat: 'Argentina', age: 26, pos: 'CM', sec: ['DM', 'AM'], ovr: 87, num: 10 },
      { name: 'Dominik Szoboszlai', nat: 'Hungary', age: 25, pos: 'AM', sec: ['CM'], ovr: 85, pa: 88, num: 8 },
      { name: 'Luis Diaz', nat: 'Colombia', age: 28, pos: 'LW', sec: ['ST'], ovr: 86, num: 7 },
      { name: 'Mohamed Salah', nat: 'Ai Cập', age: 33, pos: 'RW', sec: ['ST'], ovr: 90, num: 11, foot: 'Trái' },
      { name: 'Diogo Jota', nat: 'Bồ Đào Nha', age: 28, pos: 'ST', sec: ['LW'], ovr: 85, num: 20, foot: 'Hai chân' },
    ],
  },
  {
    id: 'che', leagueId: 'eng_pl', name: 'Chelsea', shortName: 'CHE', country: 'Anh', city: 'London',
    stadium: 'Stamford Bridge', capacity: 40343, reputation: 88, baseOvr: 81,
    primaryColor: '#034694', secondaryColor: '#FFFFFF', crestPattern: 'solid',
    expectation: 'Top 4 Champions League', targetPosition: 4, balance: 205, transferBudget: 85, wageBudgetWeekly: 3000,
    formation: '4-2-3-1', mentality: 'Tấn công', pressing: 'Gegenpress', passing: 'Kết hợp',
    players: [
      { name: 'Robert Sanchez', nat: 'Tây Ban Nha', age: 28, pos: 'GK', sec: [], ovr: 80, num: 1 },
      { name: 'Marc Cucurella', nat: 'Tây Ban Nha', age: 27, pos: 'LB', sec: [], ovr: 83, num: 3, foot: 'Trái' },
      { name: 'Levi Colwill', nat: 'Anh', age: 22, pos: 'CB', sec: ['LB'], ovr: 83, pa: 89, num: 6, foot: 'Trái' },
      { name: 'Reece James', nat: 'Anh', age: 25, pos: 'RB', sec: ['DM'], ovr: 85, num: 24 },
      { name: 'Moises Caicedo', nat: 'Ecuador', age: 24, pos: 'DM', sec: ['CM'], ovr: 86, pa: 90, num: 25 },
      { name: 'Enzo Fernandez', nat: 'Argentina', age: 24, pos: 'CM', sec: ['DM'], ovr: 84, pa: 88, num: 8 },
      { name: 'Cole Palmer', nat: 'Anh', age: 23, pos: 'AM', sec: ['RW'], ovr: 88, pa: 92, num: 20, foot: 'Trái' },
      { name: 'Pedro Neto', nat: 'Bồ Đào Nha', age: 25, pos: 'LW', sec: ['RW'], ovr: 83, num: 7, foot: 'Trái' },
      { name: 'Nicolas Jackson', nat: 'Senegal', age: 24, pos: 'ST', sec: [], ovr: 82, pa: 87, num: 15 },
    ],
  },
  {
    id: 'mun', leagueId: 'eng_pl', name: 'Manchester United', shortName: 'MUN', country: 'Anh', city: 'Manchester',
    stadium: 'Old Trafford', capacity: 74310, reputation: 89, baseOvr: 80,
    primaryColor: '#DA291C', secondaryColor: '#FBE122', crestPattern: 'chevron',
    expectation: 'Top 4 Champions League', targetPosition: 5, balance: 195, transferBudget: 75, wageBudgetWeekly: 3200,
    formation: '3-4-2-1', mentality: 'Cân bằng', pressing: 'Trung bình', passing: 'Kết hợp',
    players: [
      { name: 'Andre Onana', nat: 'Cameroon', age: 29, pos: 'GK', sec: [], ovr: 83, num: 24 },
      { name: 'Lisandro Martinez', nat: 'Argentina', age: 27, pos: 'CB', sec: [], ovr: 84, num: 6, foot: 'Trái' },
      { name: 'Matthijs de Ligt', nat: 'Hà Lan', age: 26, pos: 'CB', sec: [], ovr: 84, num: 4 },
      { name: 'Leny Yoro', nat: 'Pháp', age: 20, pos: 'CB', sec: [], ovr: 80, pa: 90, num: 15 },
      { name: 'Diogo Dalot', nat: 'Bồ Đào Nha', age: 26, pos: 'RB', sec: ['LB'], ovr: 82, num: 20 },
      { name: 'Kobbie Mainoo', nat: 'Anh', age: 20, pos: 'CM', sec: ['DM'], ovr: 81, pa: 90, num: 37 },
      { name: 'Manuel Ugarte', nat: 'Uruguay', age: 24, pos: 'DM', sec: ['CM'], ovr: 82, num: 25 },
      { name: 'Bruno Fernandes', nat: 'Bồ Đào Nha', age: 31, pos: 'AM', sec: ['CM'], ovr: 87, num: 8 },
      { name: 'Amad Diallo', nat: 'Bờ Biển Ngà', age: 23, pos: 'RW', sec: ['AM'], ovr: 82, pa: 88, num: 16, foot: 'Trái' },
      { name: 'Alejandro Garnacho', nat: 'Argentina', age: 21, pos: 'LW', sec: ['RW'], ovr: 81, pa: 89, num: 17 },
      { name: 'Rasmus Hojlund', nat: 'Đan Mạch', age: 22, pos: 'ST', sec: [], ovr: 81, pa: 88, num: 9, foot: 'Trái' },
    ],
  },
  {
    id: 'tot', leagueId: 'eng_pl', name: 'Tottenham Hotspur', shortName: 'TOT', country: 'Anh', city: 'London',
    stadium: 'Tottenham Hotspur Stadium', capacity: 62850, reputation: 85, baseOvr: 80,
    primaryColor: '#FFFFFF', secondaryColor: '#132257', crestPattern: 'halves',
    expectation: 'Top 6 & vé Cúp châu Âu', targetPosition: 6, balance: 185, transferBudget: 65, wageBudgetWeekly: 2500,
    formation: '4-3-3 DM', mentality: 'Tấn công', pressing: 'Gegenpress', passing: 'Ngắn',
    players: [
      { name: 'Guglielmo Vicario', nat: 'Ý', age: 29, pos: 'GK', sec: [], ovr: 84, num: 1 },
      { name: 'Destiny Udogie', nat: 'Ý', age: 23, pos: 'LB', sec: [], ovr: 82, pa: 87, num: 13, foot: 'Trái' },
      { name: 'Micky van de Ven', nat: 'Hà Lan', age: 24, pos: 'CB', sec: [], ovr: 84, pa: 89, num: 37, foot: 'Trái' },
      { name: 'Cristian Romero', nat: 'Argentina', age: 27, pos: 'CB', sec: [], ovr: 85, num: 17 },
      { name: 'Pedro Porro', nat: 'Tây Ban Nha', age: 26, pos: 'RB', sec: [], ovr: 83, num: 23 },
      { name: 'James Maddison', nat: 'Anh', age: 29, pos: 'AM', sec: ['CM'], ovr: 84, num: 10 },
      { name: 'Dejan Kulusevski', nat: 'Thụy Điển', age: 25, pos: 'RW', sec: ['AM'], ovr: 84, num: 21, foot: 'Trái' },
      { name: 'Son Heung-min', nat: 'Hàn Quốc', age: 33, pos: 'LW', sec: ['ST'], ovr: 86, num: 7, foot: 'Hai chân' },
      { name: 'Dominic Solanke', nat: 'Anh', age: 28, pos: 'ST', sec: [], ovr: 82, num: 19 },
    ],
  },
  {
    id: 'new', leagueId: 'eng_pl', name: 'Newcastle United', shortName: 'NEW', country: 'Anh', city: 'Newcastle',
    stadium: 'St James Park', capacity: 52305, reputation: 84, baseOvr: 80,
    primaryColor: '#111111', secondaryColor: '#FFFFFF', crestPattern: 'stripes',
    expectation: 'Top 6 Premier League', targetPosition: 6, balance: 190, transferBudget: 70, wageBudgetWeekly: 2400,
    formation: '4-3-3 DM', mentality: 'Cân bằng', pressing: 'Gegenpress', passing: 'Kết hợp',
    players: [
      { name: 'Nick Pope', nat: 'Anh', age: 33, pos: 'GK', sec: [], ovr: 82, num: 22 },
      { name: 'Lewis Hall', nat: 'Anh', age: 21, pos: 'LB', sec: ['CM'], ovr: 80, pa: 87, num: 20, foot: 'Trái' },
      { name: 'Sven Botman', nat: 'Hà Lan', age: 25, pos: 'CB', sec: [], ovr: 83, num: 4, foot: 'Trái' },
      { name: 'Bruno Guimaraes', nat: 'Brazil', age: 28, pos: 'DM', sec: ['CM'], ovr: 86, num: 39 },
      { name: 'Sandro Tonali', nat: 'Ý', age: 25, pos: 'CM', sec: ['DM'], ovr: 84, pa: 88, num: 8 },
      { name: 'Anthony Gordon', nat: 'Anh', age: 24, pos: 'LW', sec: ['RW'], ovr: 84, pa: 88, num: 10 },
      { name: 'Alexander Isak', nat: 'Thụy Điển', age: 26, pos: 'ST', sec: [], ovr: 87, pa: 91, num: 14 },
    ],
  },
  {
    id: 'avl', leagueId: 'eng_pl', name: 'Aston Villa', shortName: 'AVL', country: 'Anh', city: 'Birmingham',
    stadium: 'Villa Park', capacity: 42657, reputation: 83, baseOvr: 79,
    primaryColor: '#670E36', secondaryColor: '#95BFE5', crestPattern: 'halves',
    expectation: 'Nửa trên BXH & Cúp châu Âu', targetPosition: 7, balance: 140, transferBudget: 50, wageBudgetWeekly: 2100,
    formation: '4-2-3-1', mentality: 'Cân bằng', pressing: 'Trung bình', passing: 'Kết hợp',
    players: [
      { name: 'Emiliano Martinez', nat: 'Argentina', age: 33, pos: 'GK', sec: [], ovr: 87, num: 23 },
      { name: 'Pau Torres', nat: 'Tây Ban Nha', age: 28, pos: 'CB', sec: [], ovr: 83, num: 14, foot: 'Trái' },
      { name: 'Amadou Onana', nat: 'Bỉ', age: 24, pos: 'DM', sec: ['CM'], ovr: 82, num: 24 },
      { name: 'Youri Tielemans', nat: 'Bỉ', age: 28, pos: 'CM', sec: ['AM'], ovr: 82, num: 8 },
      { name: 'Morgan Rogers', nat: 'Anh', age: 23, pos: 'AM', sec: ['LW'], ovr: 81, pa: 87, num: 27 },
      { name: 'Ollie Watkins', nat: 'Anh', age: 29, pos: 'ST', sec: [], ovr: 84, num: 11 },
    ],
  },
  {
    id: 'bha', leagueId: 'eng_pl', name: 'Brighton & Hove Albion', shortName: 'BHA', country: 'Anh', city: 'Brighton',
    stadium: 'Amex Stadium', capacity: 31876, reputation: 79, baseOvr: 77,
    primaryColor: '#0057B8', secondaryColor: '#FFFFFF', crestPattern: 'stripes',
    expectation: 'Top 10 & phát triển cầu thủ trẻ', targetPosition: 8, balance: 135, transferBudget: 48, wageBudgetWeekly: 1700,
    formation: '4-2-3-1', mentality: 'Tấn công', pressing: 'Gegenpress', passing: 'Ngắn',
    players: [
      { name: 'Bart Verbruggen', nat: 'Hà Lan', age: 23, pos: 'GK', sec: [], ovr: 80, pa: 86, num: 1 },
      { name: 'Carlos Baleba', nat: 'Cameroon', age: 21, pos: 'DM', sec: ['CM'], ovr: 80, pa: 88, num: 20 },
      { name: 'Kaoru Mitoma', nat: 'Nhật Bản', age: 28, pos: 'LW', sec: [], ovr: 82, num: 22 },
      { name: 'Joao Pedro', nat: 'Brazil', age: 24, pos: 'ST', sec: ['AM'], ovr: 81, pa: 86, num: 9 },
    ],
  },
  {
    id: 'whu', leagueId: 'eng_pl', name: 'West Ham United', shortName: 'WHU', country: 'Anh', city: 'London',
    stadium: 'London Stadium', capacity: 62500, reputation: 78, baseOvr: 77,
    primaryColor: '#7A263A', secondaryColor: '#1BB1E7', crestPattern: 'hoops',
    expectation: 'Trụ hạng an toàn & nửa trên', targetPosition: 9, balance: 120, transferBudget: 40, wageBudgetWeekly: 1650,
    formation: '4-2-3-1', mentality: 'Cân bằng', pressing: 'Trung bình', passing: 'Kết hợp',
    players: [
      { name: 'Lucas Paqueta', nat: 'Brazil', age: 28, pos: 'AM', sec: ['CM'], ovr: 83, num: 10, foot: 'Trái' },
      { name: 'Mohammed Kudus', nat: 'Ghana', age: 25, pos: 'RW', sec: ['AM'], ovr: 83, num: 14, foot: 'Trái' },
      { name: 'Jarrod Bowen', nat: 'Anh', age: 28, pos: 'RW', sec: ['ST'], ovr: 83, num: 20, foot: 'Trái' },
    ],
  },

  // ================= LA LIGA (TÂY BAN NHA) =================
  {
    id: 'rma', leagueId: 'esp_laliga', name: 'Real Madrid', shortName: 'RMA', country: 'Tây Ban Nha', city: 'Madrid',
    stadium: 'Santiago Bernabeu', capacity: 85000, reputation: 97, baseOvr: 86,
    primaryColor: '#FFFFFF', secondaryColor: '#D4AF37', crestPattern: 'sash',
    expectation: 'Vô địch La Liga', targetPosition: 1, balance: 360, transferBudget: 130, wageBudgetWeekly: 4600,
    formation: '4-2-3-1', mentality: 'Tấn công', pressing: 'Trung bình', passing: 'Kết hợp',
    players: [
      { name: 'Thibaut Courtois', nat: 'Bỉ', age: 33, pos: 'GK', sec: [], ovr: 90, num: 1, foot: 'Trái', height: 200 },
      { name: 'Ferland Mendy', nat: 'Pháp', age: 30, pos: 'LB', sec: [], ovr: 83, num: 23, foot: 'Trái' },
      { name: 'Antonio Rudiger', nat: 'Đức', age: 32, pos: 'CB', sec: [], ovr: 88, num: 22 },
      { name: 'Eder Militao', nat: 'Brazil', age: 27, pos: 'CB', sec: [], ovr: 86, num: 3 },
      { name: 'Dani Carvajal', nat: 'Tây Ban Nha', age: 33, pos: 'RB', sec: [], ovr: 85, num: 2 },
      { name: 'Aurelien Tchouameni', nat: 'Pháp', age: 25, pos: 'DM', sec: ['CB'], ovr: 86, pa: 89, num: 14 },
      { name: 'Federico Valverde', nat: 'Uruguay', age: 27, pos: 'CM', sec: ['RW', 'DM'], ovr: 89, num: 8 },
      { name: 'Jude Bellingham', nat: 'Anh', age: 22, pos: 'AM', sec: ['CM', 'ST'], ovr: 91, pa: 95, num: 5 },
      { name: 'Vinicius Junior', nat: 'Brazil', age: 25, pos: 'LW', sec: ['ST'], ovr: 91, pa: 94, num: 7 },
      { name: 'Rodrygo Goes', nat: 'Brazil', age: 24, pos: 'RW', sec: ['LW', 'ST'], ovr: 86, pa: 90, num: 11 },
      { name: 'Kylian Mbappe', nat: 'Pháp', age: 26, pos: 'ST', sec: ['LW'], ovr: 92, pa: 95, num: 9 },
      { name: 'Arda Guler', nat: 'Thổ Nhĩ Kỳ', age: 20, pos: 'AM', sec: ['RW'], ovr: 81, pa: 91, num: 15, foot: 'Trái' },
    ],
  },
  {
    id: 'bar', leagueId: 'esp_laliga', name: 'FC Barcelona', shortName: 'BAR', country: 'Tây Ban Nha', city: 'Barcelona',
    stadium: 'Spotify Camp Nou', capacity: 99354, reputation: 94, baseOvr: 84,
    primaryColor: '#004D98', secondaryColor: '#A50044', crestPattern: 'stripes',
    expectation: 'Vô địch La Liga', targetPosition: 2, balance: 165, transferBudget: 65, wageBudgetWeekly: 3200,
    formation: '4-2-3-1', mentality: 'Tấn công', pressing: 'Gegenpress', passing: 'Ngắn',
    players: [
      { name: 'Marc-Andre ter Stegen', nat: 'Đức', age: 33, pos: 'GK', sec: [], ovr: 87, num: 1 },
      { name: 'Alejandro Balde', nat: 'Tây Ban Nha', age: 22, pos: 'LB', sec: [], ovr: 83, pa: 89, num: 3, foot: 'Trái' },
      { name: 'Pau Cubarsi', nat: 'Tây Ban Nha', age: 18, pos: 'CB', sec: [], ovr: 83, pa: 93, num: 2 },
      { name: 'Ronald Araujo', nat: 'Uruguay', age: 26, pos: 'CB', sec: ['RB'], ovr: 86, pa: 89, num: 4 },
      { name: 'Jules Kounde', nat: 'Pháp', age: 27, pos: 'RB', sec: ['CB'], ovr: 86, num: 23 },
      { name: 'Frenkie de Jong', nat: 'Hà Lan', age: 28, pos: 'CM', sec: ['DM'], ovr: 86, num: 21 },
      { name: 'Pedri Gonzalez', nat: 'Tây Ban Nha', age: 23, pos: 'CM', sec: ['AM'], ovr: 89, pa: 93, num: 8 },
      { name: 'Gavi Paez', nat: 'Tây Ban Nha', age: 21, pos: 'CM', sec: ['AM'], ovr: 84, pa: 91, num: 6 },
      { name: 'Dani Olmo', nat: 'Tây Ban Nha', age: 27, pos: 'AM', sec: ['LW'], ovr: 85, num: 20 },
      { name: 'Raphinha', nat: 'Brazil', age: 28, pos: 'LW', sec: ['RW', 'AM'], ovr: 88, num: 11, foot: 'Trái' },
      { name: 'Lamine Yamal', nat: 'Tây Ban Nha', age: 18, pos: 'RW', sec: ['AM'], ovr: 88, pa: 96, num: 19, foot: 'Trái' },
      { name: 'Robert Lewandowski', nat: 'Ba Lan', age: 37, pos: 'ST', sec: [], ovr: 87, num: 9 },
    ],
  },
  {
    id: 'atm', leagueId: 'esp_laliga', name: 'Atletico Madrid', shortName: 'ATM', country: 'Tây Ban Nha', city: 'Madrid',
    stadium: 'Metropolitano', capacity: 70460, reputation: 88, baseOvr: 82,
    primaryColor: '#CB3524', secondaryColor: '#FFFFFF', crestPattern: 'stripes',
    expectation: 'Top 3 La Liga', targetPosition: 3, balance: 175, transferBudget: 65, wageBudgetWeekly: 2600,
    formation: '4-4-2', mentality: 'Phòng ngự', pressing: 'Trung bình', passing: 'Dài',
    players: [
      { name: 'Jan Oblak', nat: 'Slovenia', age: 32, pos: 'GK', sec: [], ovr: 88, num: 13 },
      { name: 'Jose Maria Gimenez', nat: 'Uruguay', age: 30, pos: 'CB', sec: [], ovr: 84, num: 2 },
      { name: 'Robin Le Normand', nat: 'Tây Ban Nha', age: 29, pos: 'CB', sec: [], ovr: 84, num: 24 },
      { name: 'Marcos Llorente', nat: 'Tây Ban Nha', age: 30, pos: 'RB', sec: ['CM', 'RW'], ovr: 84, num: 14 },
      { name: 'Rodrigo De Paul', nat: 'Argentina', age: 31, pos: 'CM', sec: [], ovr: 84, num: 5 },
      { name: 'Pablo Barrios', nat: 'Tây Ban Nha', age: 22, pos: 'CM', sec: ['DM'], ovr: 82, pa: 89, num: 8 },
      { name: 'Antoine Griezmann', nat: 'Pháp', age: 34, pos: 'ST', sec: ['AM'], ovr: 86, num: 7, foot: 'Trái' },
      { name: 'Julian Alvarez', nat: 'Argentina', age: 25, pos: 'ST', sec: ['AM'], ovr: 87, pa: 91, num: 19 },
    ],
  },
  {
    id: 'ath', leagueId: 'esp_laliga', name: 'Athletic Bilbao', shortName: 'ATH', country: 'Tây Ban Nha', city: 'Bilbao',
    stadium: 'San Mames', capacity: 53331, reputation: 82, baseOvr: 79,
    primaryColor: '#EE2523', secondaryColor: '#FFFFFF', crestPattern: 'stripes',
    expectation: 'Top 4 Champions League', targetPosition: 4, balance: 110, transferBudget: 40, wageBudgetWeekly: 1700,
    formation: '4-2-3-1', mentality: 'Tấn công', pressing: 'Gegenpress', passing: 'Kết hợp',
    players: [
      { name: 'Unai Simon', nat: 'Tây Ban Nha', age: 28, pos: 'GK', sec: [], ovr: 84, num: 1 },
      { name: 'Dani Vivian', nat: 'Tây Ban Nha', age: 26, pos: 'CB', sec: [], ovr: 82, num: 3 },
      { name: 'Oihan Sancet', nat: 'Tây Ban Nha', age: 25, pos: 'AM', sec: ['CM'], ovr: 83, num: 8 },
      { name: 'Nico Williams', nat: 'Tây Ban Nha', age: 23, pos: 'LW', sec: ['RW'], ovr: 86, pa: 91, num: 10 },
      { name: 'Inaki Williams', nat: 'Ghana', age: 31, pos: 'RW', sec: ['ST'], ovr: 82, num: 9 },
    ],
  },
  {
    id: 'rso', leagueId: 'esp_laliga', name: 'Real Sociedad', shortName: 'RSO', country: 'Tây Ban Nha', city: 'San Sebastian',
    stadium: 'Reale Arena', capacity: 39313, reputation: 81, baseOvr: 78,
    primaryColor: '#0067B1', secondaryColor: '#FFFFFF', crestPattern: 'stripes',
    expectation: 'Vé Cúp châu Âu', targetPosition: 5, balance: 105, transferBudget: 38, wageBudgetWeekly: 1550,
    formation: '4-3-3 DM', mentality: 'Cân bằng', pressing: 'Gegenpress', passing: 'Ngắn',
    players: [
      { name: 'Alex Remiro', nat: 'Tây Ban Nha', age: 30, pos: 'GK', sec: [], ovr: 82, num: 1 },
      { name: 'Martin Zubimendi', nat: 'Tây Ban Nha', age: 26, pos: 'DM', sec: ['CM'], ovr: 85, pa: 88, num: 4 },
      { name: 'Takefusa Kubo', nat: 'Nhật Bản', age: 24, pos: 'RW', sec: ['AM'], ovr: 83, pa: 88, num: 14, foot: 'Trái' },
      { name: 'Mikel Oyarzabal', nat: 'Tây Ban Nha', age: 28, pos: 'ST', sec: ['LW'], ovr: 83, num: 10, foot: 'Trái' },
    ],
  },
  {
    id: 'vil', leagueId: 'esp_laliga', name: 'Villarreal CF', shortName: 'VIL', country: 'Tây Ban Nha', city: 'Villarreal',
    stadium: 'Estadio de la Ceramica', capacity: 23000, reputation: 80, baseOvr: 78,
    primaryColor: '#FFE667', secondaryColor: '#005187', crestPattern: 'solid',
    expectation: 'Top 6 La Liga', targetPosition: 6, balance: 95, transferBudget: 35, wageBudgetWeekly: 1450,
    formation: '4-4-2', mentality: 'Cân bằng', pressing: 'Trung bình', passing: 'Ngắn',
    players: [
      { name: 'Alex Baena', nat: 'Tây Ban Nha', age: 24, pos: 'LW', sec: ['AM'], ovr: 84, pa: 89, num: 16 },
      { name: 'Ayoze Perez', nat: 'Tây Ban Nha', age: 32, pos: 'ST', sec: ['LW'], ovr: 81, num: 22 },
      { name: 'Gerard Moreno', nat: 'Tây Ban Nha', age: 33, pos: 'ST', sec: [], ovr: 82, num: 7, foot: 'Trái' },
    ],
  },
  {
    id: 'bet', leagueId: 'esp_laliga', name: 'Real Betis', shortName: 'BET', country: 'Tây Ban Nha', city: 'Seville',
    stadium: 'Benito Villamarin', capacity: 60721, reputation: 79, baseOvr: 77,
    primaryColor: '#0BB363', secondaryColor: '#FFFFFF', crestPattern: 'stripes',
    expectation: 'Cạnh tranh suất châu Âu', targetPosition: 7, balance: 85, transferBudget: 28, wageBudgetWeekly: 1350,
    formation: '4-2-3-1', mentality: 'Tấn công', pressing: 'Trung bình', passing: 'Ngắn',
    players: [
      { name: 'Isco Alarcon', nat: 'Tây Ban Nha', age: 33, pos: 'AM', sec: ['CM'], ovr: 83, num: 22 },
      { name: 'Giovani Lo Celso', nat: 'Argentina', age: 29, pos: 'AM', sec: ['CM'], ovr: 82, num: 20, foot: 'Trái' },
    ],
  },
  {
    id: 'gir', leagueId: 'esp_laliga', name: 'Girona FC', shortName: 'GIR', country: 'Tây Ban Nha', city: 'Girona',
    stadium: 'Montilivi', capacity: 14624, reputation: 77, baseOvr: 76,
    primaryColor: '#CD122D', secondaryColor: '#FFFFFF', crestPattern: 'stripes',
    expectation: 'Nửa trên BXH', targetPosition: 8, balance: 75, transferBudget: 25, wageBudgetWeekly: 1100,
    formation: '4-3-3 DM', mentality: 'Tấn công', pressing: 'Gegenpress', passing: 'Ngắn',
    players: [
      { name: 'Miguel Gutierrez', nat: 'Tây Ban Nha', age: 24, pos: 'LB', sec: [], ovr: 81, pa: 86, num: 3, foot: 'Trái' },
      { name: 'Viktor Tsygankov', nat: 'Ukraine', age: 28, pos: 'RW', sec: [], ovr: 81, num: 8, foot: 'Trái' },
    ],
  },
  {
    id: 'sev', leagueId: 'esp_laliga', name: 'Sevilla FC', shortName: 'SEV', country: 'Tây Ban Nha', city: 'Seville',
    stadium: 'Ramon Sanchez-Pizjuan', capacity: 43883, reputation: 79, baseOvr: 76,
    primaryColor: '#FFFFFF', secondaryColor: '#D40026', crestPattern: 'sash',
    expectation: 'Top 10 La Liga', targetPosition: 9, balance: 80, transferBudget: 22, wageBudgetWeekly: 1300,
    formation: '4-3-3 DM', mentality: 'Cân bằng', pressing: 'Trung bình', passing: 'Kết hợp',
    players: [
      { name: 'Dodi Lukebakio', nat: 'Bỉ', age: 28, pos: 'RW', sec: ['ST'], ovr: 80, num: 11, foot: 'Trái' },
    ],
  },
  {
    id: 'val', leagueId: 'esp_laliga', name: 'Valencia CF', shortName: 'VAL', country: 'Tây Ban Nha', city: 'Valencia',
    stadium: 'Mestalla', capacity: 49430, reputation: 77, baseOvr: 75,
    primaryColor: '#FFFFFF', secondaryColor: '#111111', crestPattern: 'halves',
    expectation: 'Trụ hạng vững chắc', targetPosition: 10, balance: 65, transferBudget: 18, wageBudgetWeekly: 1050,
    formation: '4-4-2', mentality: 'Phòng ngự', pressing: 'Thấp', passing: 'Dài',
    players: [
      { name: 'Giorgi Mamardashvili', nat: 'Georgia', age: 25, pos: 'GK', sec: [], ovr: 84, pa: 89, num: 25, foot: 'Trái' },
      { name: 'Javi Guerra', nat: 'Tây Ban Nha', age: 22, pos: 'CM', sec: ['DM'], ovr: 79, pa: 86, num: 8 },
    ],
  },

  // ================= SERIE A (Ý) =================
  {
    id: 'int', leagueId: 'ita_seriea', name: 'Inter Milan', shortName: 'INT', country: 'Ý', city: 'Milan',
    stadium: 'San Siro', capacity: 75817, reputation: 90, baseOvr: 84,
    primaryColor: '#0068A8', secondaryColor: '#000000', crestPattern: 'stripes',
    expectation: 'Vô địch Scudetto', targetPosition: 1, balance: 145, transferBudget: 55, wageBudgetWeekly: 2800,
    formation: '3-5-2', mentality: 'Cân bằng', pressing: 'Trung bình', passing: 'Kết hợp',
    players: [
      { name: 'Yann Sommer', nat: 'Thụy Sĩ', age: 36, pos: 'GK', sec: [], ovr: 85, num: 1 },
      { name: 'Alessandro Bastoni', nat: 'Ý', age: 26, pos: 'CB', sec: [], ovr: 88, pa: 91, num: 95, foot: 'Trái' },
      { name: 'Benjamin Pavard', nat: 'Pháp', age: 29, pos: 'CB', sec: ['RB'], ovr: 84, num: 28 },
      { name: 'Federico Dimarco', nat: 'Ý', age: 28, pos: 'LB', sec: ['LW'], ovr: 87, num: 32, foot: 'Trái' },
      { name: 'Hakan Calhanoglu', nat: 'Thổ Nhĩ Kỳ', age: 31, pos: 'DM', sec: ['CM'], ovr: 87, num: 20 },
      { name: 'Nicolo Barella', nat: 'Ý', age: 28, pos: 'CM', sec: [], ovr: 88, num: 23 },
      { name: 'Lautaro Martinez', nat: 'Argentina', age: 28, pos: 'ST', sec: [], ovr: 89, num: 10 },
      { name: 'Marcus Thuram', nat: 'Pháp', age: 28, pos: 'ST', sec: ['LW'], ovr: 86, num: 9 },
    ],
  },
  {
    id: 'juv', leagueId: 'ita_seriea', name: 'Juventus', shortName: 'JUV', country: 'Ý', city: 'Turin',
    stadium: 'Allianz Stadium', capacity: 41507, reputation: 88, baseOvr: 81,
    primaryColor: '#FFFFFF', secondaryColor: '#111111', crestPattern: 'stripes',
    expectation: 'Top 4 & tranh Scudetto', targetPosition: 2, balance: 160, transferBudget: 55, wageBudgetWeekly: 2700,
    formation: '4-2-3-1', mentality: 'Cân bằng', pressing: 'Trung bình', passing: 'Kết hợp',
    players: [
      { name: 'Michele Di Gregorio', nat: 'Ý', age: 28, pos: 'GK', sec: [], ovr: 83, num: 29 },
      { name: 'Gleison Bremer', nat: 'Brazil', age: 28, pos: 'CB', sec: [], ovr: 86, num: 3 },
      { name: 'Andrea Cambiaso', nat: 'Ý', age: 25, pos: 'LB', sec: ['RB'], ovr: 83, pa: 87, num: 27, foot: 'Hai chân' },
      { name: 'Teun Koopmeiners', nat: 'Hà Lan', age: 27, pos: 'AM', sec: ['CM'], ovr: 84, num: 8, foot: 'Trái' },
      { name: 'Kenan Yildiz', nat: 'Thổ Nhĩ Kỳ', age: 20, pos: 'LW', sec: ['AM'], ovr: 82, pa: 91, num: 10 },
      { name: 'Dusan Vlahovic', nat: 'Serbia', age: 25, pos: 'ST', sec: [], ovr: 84, pa: 88, num: 9, foot: 'Trái' },
    ],
  },
  {
    id: 'nap', leagueId: 'ita_seriea', name: 'SSC Napoli', shortName: 'NAP', country: 'Ý', city: 'Naples',
    stadium: 'Diego Armando Maradona', capacity: 54726, reputation: 86, baseOvr: 81,
    primaryColor: '#008FD7', secondaryColor: '#FFFFFF', crestPattern: 'solid',
    expectation: 'Top 4 Serie A', targetPosition: 3, balance: 135, transferBudget: 50, wageBudgetWeekly: 2200,
    formation: '4-3-3 DM', mentality: 'Cân bằng', pressing: 'Trung bình', passing: 'Kết hợp',
    players: [
      { name: 'Alessandro Buongiorno', nat: 'Ý', age: 26, pos: 'CB', sec: [], ovr: 84, pa: 88, num: 4, foot: 'Trái' },
      { name: 'Stanislav Lobotka', nat: 'Slovakia', age: 31, pos: 'DM', sec: ['CM'], ovr: 84, num: 68 },
      { name: 'Scott McTominay', nat: 'Scotland', age: 28, pos: 'CM', sec: ['AM'], ovr: 83, num: 8 },
      { name: 'Romelu Lukaku', nat: 'Bỉ', age: 32, pos: 'ST', sec: [], ovr: 83, num: 11, foot: 'Trái' },
    ],
  },
  {
    id: 'mil', leagueId: 'ita_seriea', name: 'AC Milan', shortName: 'MIL', country: 'Ý', city: 'Milan',
    stadium: 'San Siro', capacity: 75817, reputation: 87, baseOvr: 81,
    primaryColor: '#FB090B', secondaryColor: '#000000', crestPattern: 'stripes',
    expectation: 'Top 4 Serie A', targetPosition: 4, balance: 140, transferBudget: 48, wageBudgetWeekly: 2400,
    formation: '4-2-3-1', mentality: 'Tấn công', pressing: 'Trung bình', passing: 'Kết hợp',
    players: [
      { name: 'Mike Maignan', nat: 'Pháp', age: 30, pos: 'GK', sec: [], ovr: 87, num: 16 },
      { name: 'Theo Hernandez', nat: 'Pháp', age: 28, pos: 'LB', sec: [], ovr: 86, num: 19, foot: 'Trái' },
      { name: 'Tijjani Reijnders', nat: 'Hà Lan', age: 27, pos: 'CM', sec: ['AM'], ovr: 85, num: 14 },
      { name: 'Christian Pulisic', nat: 'Mỹ', age: 27, pos: 'RW', sec: ['AM', 'LW'], ovr: 85, num: 11 },
      { name: 'Rafael Leao', nat: 'Bồ Đào Nha', age: 26, pos: 'LW', sec: ['ST'], ovr: 86, pa: 89, num: 10 },
    ],
  },
  {
    id: 'ata', leagueId: 'ita_seriea', name: 'Atalanta BC', shortName: 'ATA', country: 'Ý', city: 'Bergamo',
    stadium: 'Gewiss Stadium', capacity: 24950, reputation: 83, baseOvr: 80,
    primaryColor: '#1E71B8', secondaryColor: '#000000', crestPattern: 'stripes',
    expectation: 'Top 4 Champions League', targetPosition: 5, balance: 120, transferBudget: 42, wageBudgetWeekly: 1650,
    formation: '3-4-2-1', mentality: 'Tấn công', pressing: 'Gegenpress', passing: 'Kết hợp',
    players: [
      { name: 'Ederson Lourenco', nat: 'Brazil', age: 26, pos: 'CM', sec: ['DM'], ovr: 84, pa: 88, num: 13 },
      { name: 'Charles De Ketelaere', nat: 'Bỉ', age: 24, pos: 'AM', sec: ['ST'], ovr: 83, pa: 88, num: 17, foot: 'Trái' },
      { name: 'Ademola Lookman', nat: 'Nigeria', age: 28, pos: 'LW', sec: ['ST'], ovr: 85, num: 11 },
      { name: 'Mateo Retegui', nat: 'Ý', age: 26, pos: 'ST', sec: [], ovr: 82, num: 32 },
    ],
  },
  {
    id: 'rom', leagueId: 'ita_seriea', name: 'AS Roma', shortName: 'ROM', country: 'Ý', city: 'Rome',
    stadium: 'Stadio Olimpico', capacity: 70634, reputation: 82, baseOvr: 78,
    primaryColor: '#8E1F2F', secondaryColor: '#F0BC42', crestPattern: 'halves',
    expectation: 'Vé Cúp châu Âu', targetPosition: 6, balance: 105, transferBudget: 35, wageBudgetWeekly: 1850,
    formation: '3-4-2-1', mentality: 'Cân bằng', pressing: 'Trung bình', passing: 'Kết hợp',
    players: [
      { name: 'Paulo Dybala', nat: 'Argentina', age: 32, pos: 'AM', sec: ['ST'], ovr: 85, num: 21, foot: 'Trái' },
      { name: 'Artem Dovbyk', nat: 'Ukraine', age: 28, pos: 'ST', sec: [], ovr: 82, num: 11, foot: 'Trái' },
    ],
  },
  {
    id: 'laz', leagueId: 'ita_seriea', name: 'SS Lazio', shortName: 'LAZ', country: 'Ý', city: 'Rome',
    stadium: 'Stadio Olimpico', capacity: 70634, reputation: 80, baseOvr: 78,
    primaryColor: '#87D8F7', secondaryColor: '#FFFFFF', crestPattern: 'solid',
    expectation: 'Top 6 Serie A', targetPosition: 7, balance: 95, transferBudget: 30, wageBudgetWeekly: 1550,
    formation: '4-2-3-1', mentality: 'Cân bằng', pressing: 'Trung bình', passing: 'Kết hợp',
    players: [
      { name: 'Nicolo Rovella', nat: 'Ý', age: 23, pos: 'DM', sec: ['CM'], ovr: 81, pa: 86, num: 6 },
      { name: 'Mattia Zaccagni', nat: 'Ý', age: 30, pos: 'LW', sec: [], ovr: 82, num: 10 },
    ],
  },
  {
    id: 'fio', leagueId: 'ita_seriea', name: 'ACF Fiorentina', shortName: 'FIO', country: 'Ý', city: 'Florence',
    stadium: 'Artemio Franchi', capacity: 43147, reputation: 78, baseOvr: 77,
    primaryColor: '#5B2C91', secondaryColor: '#FFFFFF', crestPattern: 'sash',
    expectation: 'Top 8 Serie A', targetPosition: 8, balance: 85, transferBudget: 28, wageBudgetWeekly: 1300,
    formation: '4-2-3-1', mentality: 'Cân bằng', pressing: 'Trung bình', passing: 'Ngắn',
    players: [
      { name: 'David de Gea', nat: 'Tây Ban Nha', age: 35, pos: 'GK', sec: [], ovr: 82, num: 43 },
      { name: 'Moise Kean', nat: 'Ý', age: 25, pos: 'ST', sec: [], ovr: 81, num: 20 },
    ],
  },
  {
    id: 'bol', leagueId: 'ita_seriea', name: 'Bologna FC', shortName: 'BOL', country: 'Ý', city: 'Bologna',
    stadium: 'Renato DallAra', capacity: 36462, reputation: 76, baseOvr: 76,
    primaryColor: '#1A2F48', secondaryColor: '#A21C26', crestPattern: 'stripes',
    expectation: 'Nửa trên BXH', targetPosition: 9, balance: 75, transferBudget: 24, wageBudgetWeekly: 1100,
    formation: '4-2-3-1', mentality: 'Cân bằng', pressing: 'Gegenpress', passing: 'Ngắn',
    players: [
      { name: 'Riccardo Orsolini', nat: 'Ý', age: 28, pos: 'RW', sec: [], ovr: 81, num: 7, foot: 'Trái' },
    ],
  },
  {
    id: 'tor', leagueId: 'ita_seriea', name: 'Torino FC', shortName: 'TOR', country: 'Ý', city: 'Turin',
    stadium: 'Olimpico Grande Torino', capacity: 28177, reputation: 74, baseOvr: 75,
    primaryColor: '#8B1D24', secondaryColor: '#FFFFFF', crestPattern: 'solid',
    expectation: 'Trụ hạng an toàn', targetPosition: 10, balance: 60, transferBudget: 18, wageBudgetWeekly: 950,
    formation: '3-5-2', mentality: 'Phòng ngự', pressing: 'Trung bình', passing: 'Kết hợp',
    players: [
      { name: 'Samuele Ricci', nat: 'Ý', age: 24, pos: 'DM', sec: ['CM'], ovr: 80, pa: 86, num: 28 },
    ],
  },

  // ================= BUNDESLIGA (ĐỨC) =================
  {
    id: 'bay', leagueId: 'ger_bundesliga', name: 'Bayern Munich', shortName: 'BAY', country: 'Đức', city: 'Munich',
    stadium: 'Allianz Arena', capacity: 75024, reputation: 93, baseOvr: 85,
    primaryColor: '#DC052D', secondaryColor: '#FFFFFF', crestPattern: 'hoops',
    expectation: 'Vô địch Bundesliga', targetPosition: 1, balance: 260, transferBudget: 100, wageBudgetWeekly: 3800,
    formation: '4-2-3-1', mentality: 'Tấn công', pressing: 'Gegenpress', passing: 'Kết hợp',
    players: [
      { name: 'Manuel Neuer', nat: 'Đức', age: 39, pos: 'GK', sec: [], ovr: 85, num: 1 },
      { name: 'Alphonso Davies', nat: 'Canada', age: 25, pos: 'LB', sec: ['LW'], ovr: 85, num: 19, foot: 'Trái' },
      { name: 'Kim Min-jae', nat: 'Hàn Quốc', age: 29, pos: 'CB', sec: [], ovr: 85, num: 3 },
      { name: 'Dayot Upamecano', nat: 'Pháp', age: 27, pos: 'CB', sec: [], ovr: 85, num: 2 },
      { name: 'Joshua Kimmich', nat: 'Đức', age: 30, pos: 'DM', sec: ['RB', 'CM'], ovr: 88, num: 6 },
      { name: 'Aleksandar Pavlovic', nat: 'Đức', age: 21, pos: 'DM', sec: ['CM'], ovr: 82, pa: 89, num: 45 },
      { name: 'Jamal Musiala', nat: 'Đức', age: 22, pos: 'AM', sec: ['LW', 'CM'], ovr: 90, pa: 95, num: 42 },
      { name: 'Michael Olise', nat: 'Pháp', age: 23, pos: 'RW', sec: ['AM'], ovr: 86, pa: 91, num: 17, foot: 'Trái' },
      { name: 'Harry Kane', nat: 'Anh', age: 32, pos: 'ST', sec: ['AM'], ovr: 91, num: 9, foot: 'Hai chân' },
    ],
  },
  {
    id: 'b04', leagueId: 'ger_bundesliga', name: 'Bayer Leverkusen', shortName: 'B04', country: 'Đức', city: 'Leverkusen',
    stadium: 'BayArena', capacity: 30210, reputation: 87, baseOvr: 82,
    primaryColor: '#E32221', secondaryColor: '#111111', crestPattern: 'chevron',
    expectation: 'Cạnh tranh đĩa bạc', targetPosition: 2, balance: 140, transferBudget: 60, wageBudgetWeekly: 2200,
    formation: '3-4-2-1', mentality: 'Tấn công', pressing: 'Gegenpress', passing: 'Ngắn',
    players: [
      { name: 'Lukas Hradecky', nat: 'Phần Lan', age: 35, pos: 'GK', sec: [], ovr: 82, num: 1 },
      { name: 'Piero Hincapie', nat: 'Ecuador', age: 23, pos: 'CB', sec: ['LB'], ovr: 84, pa: 89, num: 3, foot: 'Trái' },
      { name: 'Jonathan Tah', nat: 'Đức', age: 29, pos: 'CB', sec: [], ovr: 85, num: 4 },
      { name: 'Alejandro Grimaldo', nat: 'Tây Ban Nha', age: 30, pos: 'LB', sec: ['LW'], ovr: 86, num: 20, foot: 'Trái' },
      { name: 'Jeremie Frimpong', nat: 'Hà Lan', age: 24, pos: 'RB', sec: ['RW'], ovr: 85, pa: 88, num: 30 },
      { name: 'Granit Xhaka', nat: 'Thụy Sĩ', age: 33, pos: 'CM', sec: ['DM'], ovr: 86, num: 34, foot: 'Trái' },
      { name: 'Florian Wirtz', nat: 'Đức', age: 22, pos: 'AM', sec: ['LW'], ovr: 90, pa: 95, num: 10 },
      { name: 'Victor Boniface', nat: 'Nigeria', age: 24, pos: 'ST', sec: [], ovr: 84, pa: 88, num: 22 },
    ],
  },
  {
    id: 'bvb', leagueId: 'ger_bundesliga', name: 'Borussia Dortmund', shortName: 'BVB', country: 'Đức', city: 'Dortmund',
    stadium: 'Signal Iduna Park', capacity: 81365, reputation: 86, baseOvr: 80,
    primaryColor: '#FDE100', secondaryColor: '#000000', crestPattern: 'halves',
    expectation: 'Top 4 Bundesliga', targetPosition: 3, balance: 155, transferBudget: 50, wageBudgetWeekly: 2300,
    formation: '4-2-3-1', mentality: 'Tấn công', pressing: 'Gegenpress', passing: 'Kết hợp',
    players: [
      { name: 'Gregor Kobel', nat: 'Thụy Sĩ', age: 27, pos: 'GK', sec: [], ovr: 86, num: 1 },
      { name: 'Nico Schlotterbeck', nat: 'Đức', age: 25, pos: 'CB', sec: [], ovr: 84, num: 4, foot: 'Trái' },
      { name: 'Julian Brandt', nat: 'Đức', age: 29, pos: 'AM', sec: ['CM'], ovr: 83, num: 10 },
      { name: 'Jamie Gittens', nat: 'Anh', age: 21, pos: 'LW', sec: ['RW'], ovr: 81, pa: 88, num: 43 },
      { name: 'Serhou Guirassy', nat: 'Guinea', age: 29, pos: 'ST', sec: [], ovr: 84, num: 9 },
    ],
  },
  {
    id: 'rbl', leagueId: 'ger_bundesliga', name: 'RB Leipzig', shortName: 'RBL', country: 'Đức', city: 'Leipzig',
    stadium: 'Red Bull Arena', capacity: 47069, reputation: 83, baseOvr: 79,
    primaryColor: '#DD0741', secondaryColor: '#FFFFFF', crestPattern: 'sash',
    expectation: 'Top 4 Champions League', targetPosition: 4, balance: 145, transferBudget: 55, wageBudgetWeekly: 2000,
    formation: '4-4-2', mentality: 'Tấn công', pressing: 'Gegenpress', passing: 'Nhanh' as never,
    players: [
      { name: 'Castello Lukeba', nat: 'Pháp', age: 22, pos: 'CB', sec: [], ovr: 82, pa: 88, num: 4, foot: 'Trái' },
      { name: 'Xavi Simons', nat: 'Hà Lan', age: 22, pos: 'AM', sec: ['LW'], ovr: 85, pa: 91, num: 10 },
      { name: 'Lois Openda', nat: 'Bỉ', age: 25, pos: 'ST', sec: [], ovr: 84, pa: 88, num: 11 },
      { name: 'Benjamin Sesko', nat: 'Slovenia', age: 22, pos: 'ST', sec: [], ovr: 82, pa: 90, num: 30 },
    ],
  },
  {
    id: 'sge', leagueId: 'ger_bundesliga', name: 'Eintracht Frankfurt', shortName: 'SGE', country: 'Đức', city: 'Frankfurt',
    stadium: 'Deutsche Bank Park', capacity: 58000, reputation: 80, baseOvr: 78,
    primaryColor: '#E1000F', secondaryColor: '#000000', crestPattern: 'stripes',
    expectation: 'Top 6 Bundesliga', targetPosition: 5, balance: 110, transferBudget: 40, wageBudgetWeekly: 1500,
    formation: '3-4-2-1', mentality: 'Tấn công', pressing: 'Gegenpress', passing: 'Kết hợp',
    players: [
      { name: 'Hugo Ekitike', nat: 'Pháp', age: 23, pos: 'ST', sec: [], ovr: 81, pa: 87, num: 11 },
      { name: 'Hugo Larsson', nat: 'Thụy Điển', age: 21, pos: 'CM', sec: ['DM'], ovr: 80, pa: 87, num: 16 },
    ],
  },
  {
    id: 'vfb', leagueId: 'ger_bundesliga', name: 'VfB Stuttgart', shortName: 'VFB', country: 'Đức', city: 'Stuttgart',
    stadium: 'MHPArena', capacity: 60058, reputation: 79, baseOvr: 78,
    primaryColor: '#FFFFFF', secondaryColor: '#E32219', crestPattern: 'hoops',
    expectation: 'Vé Cúp châu Âu', targetPosition: 6, balance: 95, transferBudget: 32, wageBudgetWeekly: 1400,
    formation: '4-2-3-1', mentality: 'Tấn công', pressing: 'Gegenpress', passing: 'Ngắn',
    players: [
      { name: 'Angelo Stiller', nat: 'Đức', age: 24, pos: 'DM', sec: ['CM'], ovr: 82, pa: 87, num: 6, foot: 'Trái' },
      { name: 'Deniz Undav', nat: 'Đức', age: 29, pos: 'ST', sec: ['AM'], ovr: 81, num: 26 },
    ],
  },
  {
    id: 'scf', leagueId: 'ger_bundesliga', name: 'SC Freiburg', shortName: 'SCF', country: 'Đức', city: 'Freiburg',
    stadium: 'Europa-Park Stadion', capacity: 34700, reputation: 76, baseOvr: 76,
    primaryColor: '#E30613', secondaryColor: '#000000', crestPattern: 'stripes',
    expectation: 'Nửa trên BXH', targetPosition: 7, balance: 75, transferBudget: 24, wageBudgetWeekly: 1100,
    formation: '4-2-3-1', mentality: 'Cân bằng', pressing: 'Trung bình', passing: 'Kết hợp',
    players: [{ name: 'Vincenzo Grifo', nat: 'Ý', age: 32, pos: 'LW', sec: [], ovr: 80, num: 32 }],
  },
  {
    id: 'wob', leagueId: 'ger_bundesliga', name: 'VfL Wolfsburg', shortName: 'WOB', country: 'Đức', city: 'Wolfsburg',
    stadium: 'Volkswagen Arena', capacity: 30000, reputation: 76, baseOvr: 76,
    primaryColor: '#65B32E', secondaryColor: '#FFFFFF', crestPattern: 'solid',
    expectation: 'Top 10 Bundesliga', targetPosition: 8, balance: 90, transferBudget: 30, wageBudgetWeekly: 1250,
    formation: '4-4-2', mentality: 'Cân bằng', pressing: 'Trung bình', passing: 'Kết hợp',
    players: [{ name: 'Mohamed Amoura', nat: 'Algeria', age: 25, pos: 'ST', sec: ['LW'], ovr: 80, num: 9 }],
  },
  {
    id: 'bmg', leagueId: 'ger_bundesliga', name: 'Borussia Mönchengladbach', shortName: 'BMG', country: 'Đức', city: 'Mönchengladbach',
    stadium: 'Borussia-Park', capacity: 54042, reputation: 75, baseOvr: 75,
    primaryColor: '#FFFFFF', secondaryColor: '#000000', crestPattern: 'stripes',
    expectation: 'Nửa trên BXH', targetPosition: 9, balance: 70, transferBudget: 20, wageBudgetWeekly: 1100,
    formation: '4-2-3-1', mentality: 'Cân bằng', pressing: 'Trung bình', passing: 'Kết hợp',
    players: [{ name: 'Tim Kleindienst', nat: 'Đức', age: 30, pos: 'ST', sec: [], ovr: 79, num: 11 }],
  },
  {
    id: 'svw', leagueId: 'ger_bundesliga', name: 'Werder Bremen', shortName: 'SVW', country: 'Đức', city: 'Bremen',
    stadium: 'Weserstadion', capacity: 42100, reputation: 74, baseOvr: 74,
    primaryColor: '#1D9053', secondaryColor: '#FFFFFF', crestPattern: 'solid',
    expectation: 'Trụ hạng an toàn', targetPosition: 10, balance: 55, transferBudget: 16, wageBudgetWeekly: 900,
    formation: '3-5-2', mentality: 'Phòng ngự', pressing: 'Trung bình', passing: 'Kết hợp',
    players: [],
  },

  // ================= LIGUE 1 (PHÁP) =================
  {
    id: 'psg', leagueId: 'fra_ligue1', name: 'Paris Saint-Germain', shortName: 'PSG', country: 'Pháp', city: 'Paris',
    stadium: 'Parc des Princes', capacity: 47929, reputation: 91, baseOvr: 84,
    primaryColor: '#004170', secondaryColor: '#DA291C', crestPattern: 'chevron',
    expectation: 'Vô địch Ligue 1', targetPosition: 1, balance: 310, transferBudget: 120, wageBudgetWeekly: 3900,
    formation: '4-3-3 DM', mentality: 'Tấn công', pressing: 'Gegenpress', passing: 'Ngắn',
    players: [
      { name: 'Gianluigi Donnarumma', nat: 'Ý', age: 26, pos: 'GK', sec: [], ovr: 88, num: 1, height: 196 },
      { name: 'Nuno Mendes', nat: 'Bồ Đào Nha', age: 23, pos: 'LB', sec: [], ovr: 85, pa: 90, num: 25, foot: 'Trái' },
      { name: 'Marquinhos', nat: 'Brazil', age: 31, pos: 'CB', sec: ['DM'], ovr: 86, num: 5 },
      { name: 'Willian Pacho', nat: 'Ecuador', age: 24, pos: 'CB', sec: [], ovr: 84, pa: 88, num: 51, foot: 'Trái' },
      { name: 'Achraf Hakimi', nat: 'Ma-rốc', age: 27, pos: 'RB', sec: ['RW'], ovr: 87, num: 2 },
      { name: 'Vitinha Ferreira', nat: 'Bồ Đào Nha', age: 25, pos: 'DM', sec: ['CM'], ovr: 87, pa: 90, num: 17 },
      { name: 'Joao Neves', nat: 'Bồ Đào Nha', age: 21, pos: 'CM', sec: ['DM'], ovr: 84, pa: 91, num: 87 },
      { name: 'Warren Zaire-Emery', nat: 'Pháp', age: 19, pos: 'CM', sec: ['DM'], ovr: 83, pa: 91, num: 33 },
      { name: 'Khvicha Kvaratskhelia', nat: 'Georgia', age: 24, pos: 'LW', sec: ['RW'], ovr: 87, pa: 91, num: 7, foot: 'Hai chân' },
      { name: 'Ousmane Dembele', nat: 'Pháp', age: 28, pos: 'RW', sec: ['ST', 'LW'], ovr: 87, num: 10, foot: 'Hai chân' },
      { name: 'Bradley Barcola', nat: 'Pháp', age: 23, pos: 'LW', sec: ['RW'], ovr: 84, pa: 89, num: 29 },
      { name: 'Goncalo Ramos', nat: 'Bồ Đào Nha', age: 24, pos: 'ST', sec: [], ovr: 82, num: 9 },
    ],
  },
  {
    id: 'asm', leagueId: 'fra_ligue1', name: 'AS Monaco', shortName: 'ASM', country: 'Pháp', city: 'Monaco',
    stadium: 'Stade Louis II', capacity: 16360, reputation: 82, baseOvr: 79,
    primaryColor: '#E51B24', secondaryColor: '#FFFFFF', crestPattern: 'sash',
    expectation: 'Top 3 Champions League', targetPosition: 2, balance: 130, transferBudget: 48, wageBudgetWeekly: 1750,
    formation: '4-2-3-1', mentality: 'Tấn công', pressing: 'Gegenpress', passing: 'Kết hợp',
    players: [
      { name: 'Maghnes Akliouche', nat: 'Pháp', age: 23, pos: 'RW', sec: ['AM'], ovr: 81, pa: 88, num: 11, foot: 'Trái' },
      { name: 'Eliesse Ben Seghir', nat: 'Ma-rốc', age: 20, pos: 'AM', sec: ['LW'], ovr: 79, pa: 88, num: 7 },
    ],
  },
  {
    id: 'om', leagueId: 'fra_ligue1', name: 'Olympique Marseille', shortName: 'OM', country: 'Pháp', city: 'Marseille',
    stadium: 'Orange Velodrome', capacity: 67394, reputation: 82, baseOvr: 79,
    primaryColor: '#FFFFFF', secondaryColor: '#2FAEE0', crestPattern: 'sash',
    expectation: 'Top 3 Champions League', targetPosition: 3, balance: 120, transferBudget: 42, wageBudgetWeekly: 1800,
    formation: '3-4-2-1', mentality: 'Tấn công', pressing: 'Gegenpress', passing: 'Ngắn',
    players: [
      { name: 'Adrien Rabiot', nat: 'Pháp', age: 30, pos: 'CM', sec: ['DM'], ovr: 83, num: 25, foot: 'Trái' },
      { name: 'Mason Greenwood', nat: 'Anh', age: 24, pos: 'RW', sec: ['ST'], ovr: 83, num: 10, foot: 'Hai chân' },
    ],
  },
  {
    id: 'lil', leagueId: 'fra_ligue1', name: 'LOSC Lille', shortName: 'LIL', country: 'Pháp', city: 'Lille',
    stadium: 'Pierre-Mauroy', capacity: 50186, reputation: 80, baseOvr: 78,
    primaryColor: '#E01E13', secondaryColor: '#1B243E', crestPattern: 'chevron',
    expectation: 'Top 4 Ligue 1', targetPosition: 4, balance: 100, transferBudget: 35, wageBudgetWeekly: 1450,
    formation: '4-2-3-1', mentality: 'Cân bằng', pressing: 'Trung bình', passing: 'Kết hợp',
    players: [
      { name: 'Lucas Chevalier', nat: 'Pháp', age: 24, pos: 'GK', sec: [], ovr: 83, pa: 89, num: 30 },
      { name: 'Jonathan David', nat: 'Canada', age: 25, pos: 'ST', sec: [], ovr: 83, num: 9, foot: 'Hai chân' },
    ],
  },
  {
    id: 'ol', leagueId: 'fra_ligue1', name: 'Olympique Lyon', shortName: 'OL', country: 'Pháp', city: 'Lyon',
    stadium: 'Groupama Stadium', capacity: 59186, reputation: 80, baseOvr: 77,
    primaryColor: '#FFFFFF', secondaryColor: '#14387F', crestPattern: 'sash',
    expectation: 'Top 5 & vé châu Âu', targetPosition: 5, balance: 90, transferBudget: 28, wageBudgetWeekly: 1500,
    formation: '4-3-3 DM', mentality: 'Tấn công', pressing: 'Trung bình', passing: 'Ngắn',
    players: [
      { name: 'Rayan Cherki', nat: 'Pháp', age: 22, pos: 'AM', sec: ['RW'], ovr: 82, pa: 89, num: 18, foot: 'Hai chân' },
    ],
  },
  {
    id: 'nic', leagueId: 'fra_ligue1', name: 'OGC Nice', shortName: 'NIC', country: 'Pháp', city: 'Nice',
    stadium: 'Allianz Riviera', capacity: 36178, reputation: 77, baseOvr: 76,
    primaryColor: '#CC0000', secondaryColor: '#000000', crestPattern: 'stripes',
    expectation: 'Top 6 Ligue 1', targetPosition: 6, balance: 85, transferBudget: 26, wageBudgetWeekly: 1200,
    formation: '3-4-2-1', mentality: 'Cân bằng', pressing: 'Trung bình', passing: 'Kết hợp',
    players: [],
  },
  {
    id: 'rcl', leagueId: 'fra_ligue1', name: 'RC Lens', shortName: 'RCL', country: 'Pháp', city: 'Lens',
    stadium: 'Bollaert-Delelis', capacity: 38223, reputation: 76, baseOvr: 76,
    primaryColor: '#EC1C24', secondaryColor: '#FFDD00', crestPattern: 'stripes',
    expectation: 'Nửa trên BXH', targetPosition: 7, balance: 75, transferBudget: 22, wageBudgetWeekly: 1100,
    formation: '3-5-2', mentality: 'Cân bằng', pressing: 'Gegenpress', passing: 'Kết hợp',
    players: [],
  },
  {
    id: 'ren', leagueId: 'fra_ligue1', name: 'Stade Rennais', shortName: 'REN', country: 'Pháp', city: 'Rennes',
    stadium: 'Roazhon Park', capacity: 29778, reputation: 76, baseOvr: 75,
    primaryColor: '#E41B17', secondaryColor: '#111111', crestPattern: 'halves',
    expectation: 'Top 8 Ligue 1', targetPosition: 8, balance: 80, transferBudget: 25, wageBudgetWeekly: 1150,
    formation: '4-3-3 DM', mentality: 'Cân bằng', pressing: 'Trung bình', passing: 'Kết hợp',
    players: [],
  },
  {
    id: 'str', leagueId: 'fra_ligue1', name: 'RC Strasbourg', shortName: 'STR', country: 'Pháp', city: 'Strasbourg',
    stadium: 'Stade de la Meinau', capacity: 26109, reputation: 73, baseOvr: 74,
    primaryColor: '#009FE3', secondaryColor: '#FFFFFF', crestPattern: 'solid',
    expectation: 'Trụ hạng & trẻ hóa', targetPosition: 9, balance: 65, transferBudget: 22, wageBudgetWeekly: 900,
    formation: '3-4-2-1', mentality: 'Tấn công', pressing: 'Gegenpress', passing: 'Ngắn',
    players: [],
  },
  {
    id: 'tfc', leagueId: 'fra_ligue1', name: 'Toulouse FC', shortName: 'TFC', country: 'Pháp', city: 'Toulouse',
    stadium: 'Stadium de Toulouse', capacity: 33150, reputation: 72, baseOvr: 73,
    primaryColor: '#6F2C91', secondaryColor: '#FFFFFF', crestPattern: 'stripes',
    expectation: 'Trụ hạng an toàn', targetPosition: 10, balance: 55, transferBudget: 15, wageBudgetWeekly: 800,
    formation: '3-4-2-1', mentality: 'Phòng ngự', pressing: 'Trung bình', passing: 'Dài',
    players: [],
  },

  // ================= V.LEAGUE 1 (VIỆT NAM) =================
  {
    id: 'tnd', leagueId: 'vie_vleague', name: 'Thép Xanh Nam Định', shortName: 'NĐF', country: 'Việt Nam', city: 'Nam Định',
    stadium: 'SVĐ Thiên Trường', capacity: 30000, reputation: 76, baseOvr: 72,
    primaryColor: '#FFFFFF', secondaryColor: '#005BAC', crestPattern: 'sash',
    expectation: 'Bảo vệ ngôi vô địch V.League', targetPosition: 1, balance: 28, transferBudget: 8, wageBudgetWeekly: 320,
    formation: '4-2-3-1', mentality: 'Tấn công', pressing: 'Gegenpress', passing: 'Kết hợp',
    players: [
      { name: 'Trần Nguyên Mạnh', nat: 'Việt Nam', age: 33, pos: 'GK', sec: [], ovr: 74, num: 26 },
      { name: 'Nguyễn Phong Hồng Duy', nat: 'Việt Nam', age: 29, pos: 'LB', sec: ['LW'], ovr: 72, num: 7, foot: 'Trái' },
      { name: 'Lucas Alves', nat: 'Brazil', age: 33, pos: 'CB', sec: [], ovr: 74, num: 4 },
      { name: 'Nguyễn Tuấn Anh', nat: 'Việt Nam', age: 30, pos: 'CM', sec: ['DM'], ovr: 74, num: 11 },
      { name: 'Caio Cesar', nat: 'Brazil', age: 30, pos: 'CM', sec: ['AM'], ovr: 75, num: 77 },
      { name: 'Hendrio Araujo', nat: 'Brazil', age: 31, pos: 'AM', sec: ['RW'], ovr: 76, num: 10, foot: 'Trái' },
      { name: 'Nguyễn Văn Toàn', nat: 'Việt Nam', age: 29, pos: 'RW', sec: ['ST'], ovr: 74, num: 9 },
      { name: 'Nguyễn Xuân Son', nat: 'Việt Nam', age: 28, pos: 'ST', sec: [], ovr: 79, num: 14 },
    ],
  },
  {
    id: 'cahn', leagueId: 'vie_vleague', name: 'Công An Hà Nội', shortName: 'CAH', country: 'Việt Nam', city: 'Hà Nội',
    stadium: 'SVĐ Hàng Đẫy', capacity: 22500, reputation: 76, baseOvr: 72,
    primaryColor: '#CE1126', secondaryColor: '#FCD116', crestPattern: 'solid',
    expectation: 'Vô địch V.League 1', targetPosition: 2, balance: 30, transferBudget: 9, wageBudgetWeekly: 340,
    formation: '4-3-3 DM', mentality: 'Tấn công', pressing: 'Gegenpress', passing: 'Ngắn',
    players: [
      { name: 'Nguyễn Filip', nat: 'Việt Nam', age: 33, pos: 'GK', sec: [], ovr: 76, num: 1, height: 192 },
      { name: 'Cao Pendant Quang Vinh', nat: 'Việt Nam', age: 28, pos: 'LB', sec: [], ovr: 74, num: 7, foot: 'Trái' },
      { name: 'Bùi Hoàng Việt Anh', nat: 'Việt Nam', age: 26, pos: 'CB', sec: [], ovr: 75, num: 68, height: 186 },
      { name: 'Vũ Văn Thanh', nat: 'Việt Nam', age: 29, pos: 'RB', sec: ['RW'], ovr: 73, num: 17 },
      { name: 'Lê Phạm Thành Long', nat: 'Việt Nam', age: 29, pos: 'DM', sec: ['CM'], ovr: 73, num: 11 },
      { name: 'Nguyễn Quang Hải', nat: 'Việt Nam', age: 28, pos: 'AM', sec: ['RW', 'CM'], ovr: 77, num: 19, foot: 'Trái' },
      { name: 'Phan Văn Đức', nat: 'Việt Nam', age: 29, pos: 'LW', sec: ['RW'], ovr: 72, num: 20 },
      { name: 'Alan Grafite', nat: 'Brazil', age: 27, pos: 'ST', sec: [], ovr: 75, num: 72 },
    ],
  },
  {
    id: 'hnfc', leagueId: 'vie_vleague', name: 'Hà Nội FC', shortName: 'HAN', country: 'Việt Nam', city: 'Hà Nội',
    stadium: 'SVĐ Hàng Đẫy', capacity: 22500, reputation: 75, baseOvr: 71,
    primaryColor: '#4B2884', secondaryColor: '#FDB913', crestPattern: 'halves',
    expectation: 'Top 3 V.League 1', targetPosition: 3, balance: 24, transferBudget: 6.5, wageBudgetWeekly: 290,
    formation: '4-2-3-1', mentality: 'Tấn công', pressing: 'Trung bình', passing: 'Ngắn',
    players: [
      { name: 'Đỗ Duy Mạnh', nat: 'Việt Nam', age: 29, pos: 'CB', sec: ['DM'], ovr: 74, num: 2 },
      { name: 'Nguyễn Thành Chung', nat: 'Việt Nam', age: 28, pos: 'CB', sec: [], ovr: 74, num: 16 },
      { name: 'Đỗ Hùng Dũng', nat: 'Việt Nam', age: 32, pos: 'CM', sec: ['DM'], ovr: 75, num: 88 },
      { name: 'Nguyễn Hai Long', nat: 'Việt Nam', age: 25, pos: 'AM', sec: ['CM'], ovr: 73, num: 14 },
      { name: 'Nguyễn Văn Quyết', nat: 'Việt Nam', age: 34, pos: 'LW', sec: ['ST', 'AM'], ovr: 75, num: 10 },
      { name: 'Phạm Tuấn Hải', nat: 'Việt Nam', age: 27, pos: 'ST', sec: ['LW'], ovr: 75, num: 9 },
    ],
  },
  {
    id: 'tcv', leagueId: 'vie_vleague', name: 'Thể Công Viettel', shortName: 'TCV', country: 'Việt Nam', city: 'Hà Nội',
    stadium: 'SVĐ Mỹ Đình', capacity: 40192, reputation: 74, baseOvr: 70,
    primaryColor: '#DA251D', secondaryColor: '#FFFFFF', crestPattern: 'chevron',
    expectation: 'Top 3 V.League 1', targetPosition: 4, balance: 22, transferBudget: 6, wageBudgetWeekly: 260,
    formation: '3-5-2', mentality: 'Cân bằng', pressing: 'Trung bình', passing: 'Kết hợp',
    players: [
      { name: 'Bùi Tiến Dũng', nat: 'Việt Nam', age: 30, pos: 'CB', sec: [], ovr: 73, num: 4 },
      { name: 'Nguyễn Thanh Bình', nat: 'Việt Nam', age: 25, pos: 'CB', sec: [], ovr: 72, pa: 78, num: 3 },
      { name: 'Khuất Văn Khang', nat: 'Việt Nam', age: 22, pos: 'LW', sec: ['LB', 'AM'], ovr: 72, pa: 80, num: 11, foot: 'Trái' },
      { name: 'Nhâm Mạnh Dũng', nat: 'Việt Nam', age: 25, pos: 'ST', sec: [], ovr: 70, num: 23 },
    ],
  },
  {
    id: 'bbd', leagueId: 'vie_vleague', name: 'Becamex Bình Dương', shortName: 'BBD', country: 'Việt Nam', city: 'Thủ Dầu Một',
    stadium: 'SVĐ Gò Đậu', capacity: 18250, reputation: 72, baseOvr: 70,
    primaryColor: '#0066B3', secondaryColor: '#E31E24', crestPattern: 'stripes',
    expectation: 'Top 4 V.League 1', targetPosition: 5, balance: 20, transferBudget: 5.5, wageBudgetWeekly: 240,
    formation: '4-2-3-1', mentality: 'Cân bằng', pressing: 'Trung bình', passing: 'Kết hợp',
    players: [
      { name: 'Quế Ngọc Hải', nat: 'Việt Nam', age: 32, pos: 'CB', sec: [], ovr: 73, num: 3 },
      { name: 'Nguyễn Tiến Linh', nat: 'Việt Nam', age: 28, pos: 'ST', sec: [], ovr: 76, num: 22 },
      { name: 'Bùi Vĩ Hào', nat: 'Việt Nam', age: 22, pos: 'LW', sec: ['ST'], ovr: 72, pa: 80, num: 11 },
    ],
  },
  {
    id: 'thh', leagueId: 'vie_vleague', name: 'Đông Á Thanh Hóa', shortName: 'THH', country: 'Việt Nam', city: 'Thanh Hóa',
    stadium: 'SVĐ Thanh Hóa', capacity: 14000, reputation: 71, baseOvr: 69,
    primaryColor: '#FFD100', secondaryColor: '#111111', crestPattern: 'solid',
    expectation: 'Top 5 & chơi cống hiến', targetPosition: 6, balance: 15, transferBudget: 4, wageBudgetWeekly: 200,
    formation: '4-3-3 DM', mentality: 'Tấn công', pressing: 'Gegenpress', passing: 'Ngắn',
    players: [
      { name: 'Doãn Ngọc Tân', nat: 'Việt Nam', age: 31, pos: 'DM', sec: ['CM'], ovr: 72, num: 34 },
      { name: 'Nguyễn Thái Sơn', nat: 'Việt Nam', age: 22, pos: 'CM', sec: ['DM'], ovr: 71, pa: 79, num: 12 },
    ],
  },
  {
    id: 'hpf', leagueId: 'vie_vleague', name: 'Hải Phòng FC', shortName: 'HPF', country: 'Việt Nam', city: 'Hải Phòng',
    stadium: 'SVĐ Lạch Tray', capacity: 30000, reputation: 69, baseOvr: 68,
    primaryColor: '#D71920', secondaryColor: '#FFFFFF', crestPattern: 'halves',
    expectation: 'Nửa trên BXH', targetPosition: 7, balance: 13, transferBudget: 3.5, wageBudgetWeekly: 180,
    formation: '4-4-2', mentality: 'Cân bằng', pressing: 'Gegenpress', passing: 'Kết hợp',
    players: [{ name: 'Nguyễn Đình Triệu', nat: 'Việt Nam', age: 33, pos: 'GK', sec: [], ovr: 72, num: 1 }],
  },
  {
    id: 'hagl', leagueId: 'vie_vleague', name: 'Hoàng Anh Gia Lai', shortName: 'HAG', country: 'Việt Nam', city: 'Pleiku',
    stadium: 'SVĐ Pleiku', capacity: 12000, reputation: 70, baseOvr: 67,
    primaryColor: '#FFFFFF', secondaryColor: '#006838', crestPattern: 'sash',
    expectation: 'Trụ hạng & đào tạo trẻ', targetPosition: 8, balance: 14, transferBudget: 3, wageBudgetWeekly: 170,
    formation: '4-2-3-1', mentality: 'Cân bằng', pressing: 'Trung bình', passing: 'Ngắn',
    players: [
      { name: 'Trần Minh Vương', nat: 'Việt Nam', age: 30, pos: 'AM', sec: ['CM'], ovr: 71, num: 10 },
      { name: 'Trần Trung Kiên', nat: 'Việt Nam', age: 22, pos: 'GK', sec: [], ovr: 69, pa: 78, num: 25 },
    ],
  },
  {
    id: 'slna', leagueId: 'vie_vleague', name: 'Sông Lam Nghệ An', shortName: 'SLN', country: 'Việt Nam', city: 'Vinh',
    stadium: 'SVĐ Vinh', capacity: 18000, reputation: 68, baseOvr: 66,
    primaryColor: '#FFE100', secondaryColor: '#00519E', crestPattern: 'stripes',
    expectation: 'Trụ hạng & giữ bản sắc trẻ', targetPosition: 9, balance: 10, transferBudget: 2.2, wageBudgetWeekly: 140,
    formation: '4-4-2', mentality: 'Phòng ngự', pressing: 'Trung bình', passing: 'Dài',
    players: [],
  },
  {
    id: 'hcmc', leagueId: 'vie_vleague', name: 'CLB TP. Hồ Chí Minh', shortName: 'HCM', country: 'Việt Nam', city: 'TP.HCM',
    stadium: 'SVĐ Thống Nhất', capacity: 15000, reputation: 68, baseOvr: 66,
    primaryColor: '#E11B22', secondaryColor: '#FFFFFF', crestPattern: 'solid',
    expectation: 'Trụ hạng an toàn', targetPosition: 10, balance: 12, transferBudget: 2.5, wageBudgetWeekly: 150,
    formation: '5-3-2', mentality: 'Phòng ngự', pressing: 'Thấp', passing: 'Dài',
    players: [],
  },
];

export function autoPickBestLineup(
  clubPlayers: Player[],
  formation: FormationName
): { lineupIds: string[]; benchIds: string[] } {
  const slots = FORMATIONS[formation];
  const available = clubPlayers
    .filter((p) => p.injuryDays === 0 && p.suspendedMatches === 0)
    .sort((a, b) => b.ovr - a.ovr);

  const used = new Set<string>();
  const lineupIds: string[] = [];

  for (const slot of slots) {
    let pick = available.find((p) => !used.has(p.id) && p.primaryPosition === slot.position);
    if (!pick) {
      pick = available.find((p) => !used.has(p.id) && p.secondaryPositions.includes(slot.position));
    }
    if (!pick) {
      pick = available.find((p) => !used.has(p.id) && (slot.position === 'GK' ? true : p.primaryPosition !== 'GK'));
    }
    if (!pick) {
      pick = clubPlayers.find((p) => !used.has(p.id));
    }
    if (pick) {
      used.add(pick.id);
      lineupIds.push(pick.id);
    }
  }

  const benchIds = clubPlayers
    .filter((p) => !used.has(p.id) && p.injuryDays === 0 && p.suspendedMatches === 0)
    .sort((a, b) => b.ovr - a.ovr)
    .slice(0, 7)
    .map((p) => p.id);

  return { lineupIds, benchIds };
}

export function materializeClubSeed(seed: RawClubSeed): {
  club: Club;
  clubPlayers: Player[];
} {
  const fullSeeds = fillSquadTo18(seed.id, seed.formation, seed.country, seed.baseOvr, seed.players);
  const clubPlayers: Player[] = fullSeeds.map((p, idx) =>
    makePlayer(seed.id, p, idx, seed.leagueId, seed.country)
  );
  const { lineupIds, benchIds } = autoPickBestLineup(clubPlayers, seed.formation);
  const slots = FORMATIONS[seed.formation];
  const isVLeagueSide = seed.leagueId === 'vie_vleague' || seed.country === 'Việt Nam';

  const club: Club = {
    id: seed.id,
    leagueId: seed.leagueId,
    name: seed.name,
    shortName: seed.shortName,
    country: seed.country,
    city: seed.city,
    stadium: seed.stadium,
    capacity: seed.capacity,
    reputation: seed.reputation,
    primaryColor: seed.primaryColor,
    secondaryColor: seed.secondaryColor,
    crestPattern: seed.crestPattern,
    expectation: seed.expectation,
    targetPosition: seed.targetPosition,
    finances: {
      balance: seed.balance,
      transferBudget: seed.transferBudget,
      wageBudgetWeekly: seed.wageBudgetWeekly,
      monthlyIncomeMatchday:
        Math.round((seed.capacity / 1000) * (isVLeagueSide ? 0.028 : seed.leagueId === 'div_3' ? 0.045 : 0.14) * 10) /
        10,
      monthlyIncomeSponsor:
        Math.round(
          Math.max(0.4, (seed.reputation - 45) * (isVLeagueSide ? 0.12 : seed.leagueId === 'div_3' ? 0.15 : 0.48)) *
            10
        ) / 10,
      boardConfidence: 78,
      fanConfidence: 76,
    },
    tactics: {
      formation: seed.formation,
      mentality: seed.mentality,
      passing: seed.passing,
      tempo: 'Vừa',
      pressing: seed.pressing,
      defensiveLine: seed.mentality === 'Phòng ngự' ? 'Thấp' : 'Dâng cao',
      lineupIds,
      benchIds,
      slotRoles: slots.map((s) => s.role),
      slotDuties: slots.map((s) => s.duty),
    },
  };

  return { club, clubPlayers };
}

export function createInitialDatabase(): {
  clubs: Record<string, Club>;
  players: Record<string, Player>;
} {
  const clubs: Record<string, Club> = {};
  const players: Record<string, Player> = {};

  for (const seed of CLUB_SEEDS) {
    const { club, clubPlayers } = materializeClubSeed(seed);
    clubs[seed.id] = club;
    for (const pl of clubPlayers) {
      players[pl.id] = pl;
    }
  }

  return { clubs, players };
}

export function injectCustomClub(
  db: { clubs: Record<string, Club>; players: Record<string, Player> },
  config: CustomClubConfig
): { clubs: Record<string, Club>; players: Record<string, Player>; customClubId: string } {
  const clubs = { ...db.clubs };
  const players = { ...db.players };

  const league = LEAGUES[config.leagueId];
  // Replace lowest-reputation club in the chosen league so the league keeps 10 clubs for balanced fixtures
  const leagueClubs = Object.values(clubs)
    .filter((c) => c.leagueId === config.leagueId)
    .sort((a, b) => a.reputation - b.reputation);

  const replaced = leagueClubs[0];
  if (replaced) {
    delete clubs[replaced.id];
    for (const pid of Object.keys(players)) {
      if (players[pid].clubId === replaced.id) {
        delete players[pid];
      }
    }
  }

  const isVLeague = config.leagueId === 'vie_vleague';
  const tierSpec = {
    underdog: {
      baseOvr: isVLeague ? 67 : 75,
      rep: isVLeague ? 68 : 74,
      balance: isVLeague ? 12 : 65,
      budget: isVLeague ? 4 : 22,
      wage: isVLeague ? 160 : 1000,
      expectation: 'Trụ hạng vững chắc & xây dựng bản sắc',
      targetPos: 8,
    },
    midtable: {
      baseOvr: isVLeague ? 70 : 79,
      rep: isVLeague ? 73 : 82,
      balance: isVLeague ? 24 : 135,
      budget: isVLeague ? 7 : 52,
      wage: isVLeague ? 260 : 1900,
      expectation: 'Cạnh tranh suất Cúp châu lục / Top 4',
      targetPos: 5,
    },
    tycoon: {
      baseOvr: isVLeague ? 74 : 84,
      rep: isVLeague ? 79 : 90,
      balance: isVLeague ? 55 : 280,
      budget: isVLeague ? 16 : 120,
      wage: isVLeague ? 420 : 3600,
      expectation: 'Cạnh tranh chức vô địch ngay mùa đầu tiên',
      targetPos: 2,
    },
  }[config.tier];

  const customClubId = 'custom_fc';
  const starName = config.starPlayerName?.trim();
  const initialSeeds: RawPlayerSeed[] = starName
    ? [
        {
          name: starName,
          nat: league.country,
          age: 23,
          pos: 'ST',
          sec: ['AM', 'LW'],
          ovr: Math.min(91, tierSpec.baseOvr + 5),
          pa: Math.min(95, tierSpec.baseOvr + 9),
          num: 10,
          role: 'Ngôi sao',
        },
      ]
    : [];

  const fullSeeds = fillSquadTo18(customClubId, config.formation, league.country, tierSpec.baseOvr, initialSeeds);
  const clubPlayers = fullSeeds.map((s, idx) => makePlayer(customClubId, s, idx, config.leagueId));
  for (const pl of clubPlayers) {
    players[pl.id] = pl;
  }

  const { lineupIds, benchIds } = autoPickBestLineup(clubPlayers, config.formation);
  const slots = FORMATIONS[config.formation];

  clubs[customClubId] = {
    id: customClubId,
    leagueId: config.leagueId,
    name: config.name.trim(),
    shortName: config.shortName.trim().toUpperCase().slice(0, 3) || 'CFC',
    country: league.country,
    city: config.city.trim() || 'Thành phố Mới',
    stadium: config.stadium.trim() || 'Sân Vận Động Trung Tâm',
    capacity: config.capacity,
    reputation: tierSpec.rep,
    primaryColor: config.primaryColor,
    secondaryColor: config.secondaryColor,
    crestPattern: config.crestPattern,
    expectation: tierSpec.expectation,
    targetPosition: tierSpec.targetPos,
    isCustom: true,
    finances: {
      balance: tierSpec.balance,
      transferBudget: tierSpec.budget,
      wageBudgetWeekly: tierSpec.wage,
      monthlyIncomeMatchday: Math.round((config.capacity / 1000) * (isVLeague ? 0.03 : 0.14) * 10) / 10,
      monthlyIncomeSponsor: Math.round(Math.max(1.5, (tierSpec.rep - 64) * (isVLeague ? 0.18 : 0.65)) * 10) / 10,
      boardConfidence: 82,
      fanConfidence: 85,
    },
    tactics: {
      formation: config.formation,
      mentality: 'Cân bằng',
      passing: 'Kết hợp',
      tempo: 'Vừa',
      pressing: 'Trung bình',
      defensiveLine: 'Trung bình',
      lineupIds,
      benchIds,
      slotRoles: slots.map((s) => s.role),
      slotDuties: slots.map((s) => s.duty),
    },
  };

  return { clubs, players, customClubId };
}
