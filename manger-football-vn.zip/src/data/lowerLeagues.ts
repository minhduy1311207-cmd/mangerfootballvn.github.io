import {
  Club,
  CrestPattern,
  CustomClubConfig,
  FormationName,
  LeagueDefinition,
  LeagueId,
  Player,
} from '../types/fm';
import {
  FORMATIONS,
  LEAGUES,
  LEAGUE_ORDER,
  RawClubSeed,
  RawPlayerSeed,
  autoPickBestLineup,
  fillSquadTo18,
  makePlayer,
  materializeClubSeed,
} from './database';

interface LowerClubTemplate {
  id: string;
  name: string;
  shortName: string;
  city: string;
  stadium: string;
  capacity: number;
  primaryColor: string;
  secondaryColor: string;
  crestPattern: CrestPattern;
  formation: FormationName;
}

export interface CountryPyramidConfig {
  countryLeagueId: LeagueId;
  country: string;
  tier2: {
    name: string;
    shortName: string;
    tierLabel: string;
    reputation: number;
    prizeMoneyFirst: number;
    baseOvr: number;
    balance: number;
    transferBudget: number;
    wageBudgetWeekly: number;
    accentColor: string;
    clubs: LowerClubTemplate[];
  };
  tier3: {
    name: string;
    shortName: string;
    tierLabel: string;
    reputation: number;
    prizeMoneyFirst: number;
    baseOvr: number;
    balance: number;
    transferBudget: number;
    wageBudgetWeekly: number;
    accentColor: string;
    clubs: LowerClubTemplate[];
  };
}

export const COUNTRY_PYRAMIDS: Record<string, CountryPyramidConfig> = {
  eng_pl: {
    countryLeagueId: 'eng_pl',
    country: 'Anh',
    tier2: {
      name: 'EFL Championship',
      shortName: 'EFL2',
      tierLabel: 'Giải Hạng Nhất Anh (Hạng 2)',
      reputation: 74,
      prizeMoneyFirst: 32,
      baseOvr: 71,
      balance: 48,
      transferBudget: 16,
      wageBudgetWeekly: 680,
      accentColor: '#3B82F6',
      clubs: [
        { id: 'lee', name: 'Leeds United', shortName: 'LEE', city: 'Leeds', stadium: 'Elland Road', capacity: 37608, primaryColor: '#FFFFFF', secondaryColor: '#1D428A', crestPattern: 'solid', formation: '4-2-3-1' },
        { id: 'bur', name: 'Burnley FC', shortName: 'BUR', city: 'Burnley', stadium: 'Turf Moor', capacity: 21944, primaryColor: '#6C1D45', secondaryColor: '#99D6EA', crestPattern: 'halves', formation: '4-4-2' },
        { id: 'shu', name: 'Sheffield United', shortName: 'SHU', city: 'Sheffield', stadium: 'Bramall Lane', capacity: 32050, primaryColor: '#EE2737', secondaryColor: '#FFFFFF', crestPattern: 'stripes', formation: '4-2-3-1' },
        { id: 'sun', name: 'Sunderland AFC', shortName: 'SUN', city: 'Sunderland', stadium: 'Stadium of Light', capacity: 49000, primaryColor: '#EB172B', secondaryColor: '#FFFFFF', crestPattern: 'stripes', formation: '4-3-3 DM' },
        { id: 'mid', name: 'Middlesbrough', shortName: 'MID', city: 'Middlesbrough', stadium: 'Riverside Stadium', capacity: 34742, primaryColor: '#E11B22', secondaryColor: '#FFFFFF', crestPattern: 'hoops', formation: '4-2-3-1' },
        { id: 'cov', name: 'Coventry City', shortName: 'COV', city: 'Coventry', stadium: 'CBS Arena', capacity: 32609, primaryColor: '#27A9E1', secondaryColor: '#FFFFFF', crestPattern: 'stripes', formation: '3-5-2' },
        { id: 'wba', name: 'West Bromwich Albion', shortName: 'WBA', city: 'West Bromwich', stadium: 'The Hawthorns', capacity: 26850, primaryColor: '#122F67', secondaryColor: '#FFFFFF', crestPattern: 'stripes', formation: '4-4-2' },
        { id: 'nor', name: 'Norwich City', shortName: 'NOR', city: 'Norwich', stadium: 'Carrow Road', capacity: 27359, primaryColor: '#FFF200', secondaryColor: '#00A650', crestPattern: 'halves', formation: '4-3-3 DM' },
        { id: 'wat', name: 'Watford FC', shortName: 'WAT', city: 'Watford', stadium: 'Vicarage Road', capacity: 22200, primaryColor: '#FBEE23', secondaryColor: '#ED2127', crestPattern: 'sash', formation: '3-4-2-1' },
        { id: 'bla', name: 'Blackburn Rovers', shortName: 'BLB', city: 'Blackburn', stadium: 'Ewood Park', capacity: 31367, primaryColor: '#009EE0', secondaryColor: '#FFFFFF', crestPattern: 'halves', formation: '4-2-3-1' },
      ],
    },
    tier3: {
      name: 'EFL League Two',
      shortName: 'EFL4',
      tierLabel: 'Giải Hạng Thấp Nhất Anh (Hạng 3)',
      reputation: 58,
      prizeMoneyFirst: 8,
      baseOvr: 62,
      balance: 10,
      transferBudget: 3,
      wageBudgetWeekly: 140,
      accentColor: '#94A3B8',
      clubs: [
        { id: 'wrx', name: 'Wrexham AFC', shortName: 'WRX', city: 'Wrexham', stadium: 'Racecourse Ground', capacity: 12600, primaryColor: '#D91A21', secondaryColor: '#FFFFFF', crestPattern: 'solid', formation: '3-5-2' },
        { id: 'bra', name: 'Bradford City', shortName: 'BRA', city: 'Bradford', stadium: 'Valley Parade', capacity: 24840, primaryColor: '#7A263A', secondaryColor: '#F59E0B', crestPattern: 'stripes', formation: '4-4-2' },
        { id: 'not', name: 'Notts County', shortName: 'NOT', city: 'Nottingham', stadium: 'Meadow Lane', capacity: 19841, primaryColor: '#111827', secondaryColor: '#FFFFFF', crestPattern: 'stripes', formation: '3-4-2-1' },
        { id: 'wim', name: 'AFC Wimbledon', shortName: 'WIM', city: 'London', stadium: 'Plough Lane', capacity: 9215, primaryColor: '#004A99', secondaryColor: '#FFD100', crestPattern: 'solid', formation: '4-4-2' },
        { id: 'mkd', name: 'MK Dons', shortName: 'MKD', city: 'Milton Keynes', stadium: 'Stadium MK', capacity: 30500, primaryColor: '#FFFFFF', secondaryColor: '#111827', crestPattern: 'sash', formation: '4-2-3-1' },
        { id: 'don', name: 'Doncaster Rovers', shortName: 'DON', city: 'Doncaster', stadium: 'Eco-Power Stadium', capacity: 15231, primaryColor: '#E11B22', secondaryColor: '#FFFFFF', crestPattern: 'hoops', formation: '4-3-3 DM' },
        { id: 'pva', name: 'Port Vale', shortName: 'PVA', city: 'Stoke-on-Trent', stadium: 'Vale Park', capacity: 15695, primaryColor: '#FFFFFF', secondaryColor: '#111827', crestPattern: 'chevron', formation: '4-4-2' },
        { id: 'wal', name: 'Walsall FC', shortName: 'WAL', city: 'Walsall', stadium: 'Bescot Stadium', capacity: 11300, primaryColor: '#D21F26', secondaryColor: '#FFFFFF', crestPattern: 'solid', formation: '5-3-2' },
        { id: 'chs', name: 'Chesterfield FC', shortName: 'CHS', city: 'Chesterfield', stadium: 'SMH Group Stadium', capacity: 10504, primaryColor: '#0057B8', secondaryColor: '#FFFFFF', crestPattern: 'solid', formation: '4-2-3-1' },
        { id: 'cre', name: 'Crewe Alexandra', shortName: 'CRE', city: 'Crewe', stadium: 'Mornflake Stadium', capacity: 10153, primaryColor: '#E11B22', secondaryColor: '#FFFFFF', crestPattern: 'sash', formation: '4-3-3 DM' },
      ],
    },
  },
  esp_laliga: {
    countryLeagueId: 'esp_laliga',
    country: 'Tây Ban Nha',
    tier2: {
      name: 'LaLiga Hypermotion',
      shortName: 'LL2',
      tierLabel: 'Giải Hạng Nhì Tây Ban Nha (Hạng 2)',
      reputation: 72,
      prizeMoneyFirst: 24,
      baseOvr: 70,
      balance: 36,
      transferBudget: 12,
      wageBudgetWeekly: 520,
      accentColor: '#F59E0B',
      clubs: [
        { id: 'lev', name: 'Levante UD', shortName: 'LEV', city: 'Valencia', stadium: 'Ciutat de Valencia', capacity: 26354, primaryColor: '#004D98', secondaryColor: '#A50044', crestPattern: 'stripes', formation: '4-2-3-1' },
        { id: 'rac', name: 'Racing Santander', shortName: 'RAC', city: 'Santander', stadium: 'El Sardinero', capacity: 22222, primaryColor: '#009A44', secondaryColor: '#FFFFFF', crestPattern: 'solid', formation: '4-2-3-1' },
        { id: 'elc', name: 'Elche CF', shortName: 'ELC', city: 'Elche', stadium: 'Martinez Valero', capacity: 31388, primaryColor: '#FFFFFF', secondaryColor: '#00843D', crestPattern: 'hoops', formation: '4-3-3 DM' },
        { id: 'ovi', name: 'Real Oviedo', shortName: 'OVI', city: 'Oviedo', stadium: 'Carlos Tartiere', capacity: 30500, primaryColor: '#0055A4', secondaryColor: '#FFFFFF', crestPattern: 'solid', formation: '4-4-2' },
        { id: 'spo', name: 'Sporting Gijon', shortName: 'SPG', city: 'Gijon', stadium: 'El Molinon', capacity: 30000, primaryColor: '#E11B22', secondaryColor: '#FFFFFF', crestPattern: 'stripes', formation: '4-4-2' },
        { id: 'gra', name: 'Granada CF', shortName: 'GRA', city: 'Granada', stadium: 'Nuevo Los Carmenes', capacity: 19189, primaryColor: '#E11B22', secondaryColor: '#FFFFFF', crestPattern: 'hoops', formation: '4-2-3-1' },
        { id: 'alm', name: 'UD Almeria', shortName: 'ALM', city: 'Almeria', stadium: 'UD Almeria Stadium', capacity: 18331, primaryColor: '#E11B22', secondaryColor: '#FFFFFF', crestPattern: 'stripes', formation: '4-2-3-1' },
        { id: 'cad', name: 'Cadiz CF', shortName: 'CAD', city: 'Cadiz', stadium: 'Nuevo Mirandilla', capacity: 20724, primaryColor: '#FFDD00', secondaryColor: '#004D98', crestPattern: 'solid', formation: '4-4-2' },
        { id: 'zar', name: 'Real Zaragoza', shortName: 'ZAR', city: 'Zaragoza', stadium: 'La Romareda', capacity: 33608, primaryColor: '#FFFFFF', secondaryColor: '#005BAC', crestPattern: 'solid', formation: '4-3-3 DM' },
        { id: 'mal', name: 'Malaga CF', shortName: 'MAL', city: 'Malaga', stadium: 'La Rosaleda', capacity: 30044, primaryColor: '#009FE3', secondaryColor: '#FFFFFF', crestPattern: 'stripes', formation: '4-2-3-1' },
      ],
    },
    tier3: {
      name: 'Primera Federación',
      shortName: '1RFEF',
      tierLabel: 'Giải Hạng Thấp Nhất TBN (Hạng 3)',
      reputation: 56,
      prizeMoneyFirst: 6,
      baseOvr: 61,
      balance: 8,
      transferBudget: 2.5,
      wageBudgetWeekly: 120,
      accentColor: '#94A3B8',
      clubs: [
        { id: 'mur', name: 'Real Murcia', shortName: 'MUR', city: 'Murcia', stadium: 'Enrique Roca', capacity: 31179, primaryColor: '#D21F26', secondaryColor: '#FFFFFF', crestPattern: 'solid', formation: '4-3-3 DM' },
        { id: 'her', name: 'Hercules CF', shortName: 'HER', city: 'Alicante', stadium: 'Jose Rico Perez', capacity: 29500, primaryColor: '#0055A4', secondaryColor: '#FFFFFF', crestPattern: 'stripes', formation: '4-2-3-1' },
        { id: 'nas', name: 'Gimnastic Tarragona', shortName: 'NAS', city: 'Tarragona', stadium: 'Nou Estadi', capacity: 14591, primaryColor: '#CC0000', secondaryColor: '#FFFFFF', crestPattern: 'solid', formation: '4-4-2' },
        { id: 'cul', name: 'Cultural Leonesa', shortName: 'CUL', city: 'Leon', stadium: 'Reino de Leon', capacity: 13346, primaryColor: '#FFFFFF', secondaryColor: '#8B1D24', crestPattern: 'solid', formation: '4-2-3-1' },
        { id: 'pon', name: 'SD Ponferradina', shortName: 'PON', city: 'Ponferrada', stadium: 'El Toralin', capacity: 8400, primaryColor: '#0055A4', secondaryColor: '#FFFFFF', crestPattern: 'stripes', formation: '4-4-2' },
        { id: 'ibi', name: 'UD Ibiza', shortName: 'IBI', city: 'Ibiza', stadium: 'Can Misses', capacity: 6500, primaryColor: '#56C2F0', secondaryColor: '#FFFFFF', crestPattern: 'solid', formation: '4-3-3 DM' },
        { id: 'ceu', name: 'AD Ceuta FC', shortName: 'CEU', city: 'Ceuta', stadium: 'Alfonso Murube', capacity: 6500, primaryColor: '#FFFFFF', secondaryColor: '#111827', crestPattern: 'halves', formation: '4-2-3-1' },
        { id: 'lug', name: 'CD Lugo', shortName: 'LUG', city: 'Lugo', stadium: 'Anxo Carro', capacity: 7114, primaryColor: '#E11B22', secondaryColor: '#FFFFFF', crestPattern: 'stripes', formation: '5-3-2' },
        { id: 'rec', name: 'Recreativo Huelva', shortName: 'REC', city: 'Huelva', stadium: 'Nuevo Colombino', capacity: 21670, primaryColor: '#0055A4', secondaryColor: '#FFFFFF', crestPattern: 'stripes', formation: '4-4-2' },
        { id: 'sab', name: 'CE Sabadell', shortName: 'SAB', city: 'Sabadell', stadium: 'Nova Creu Alta', capacity: 11908, primaryColor: '#0055A4', secondaryColor: '#FFFFFF', crestPattern: 'halves', formation: '4-3-3 DM' },
      ],
    },
  },
  ita_seriea: {
    countryLeagueId: 'ita_seriea',
    country: 'Ý',
    tier2: {
      name: 'Serie BKT',
      shortName: 'SERB',
      tierLabel: 'Giải Hạng Nhì Ý (Hạng 2)',
      reputation: 70,
      prizeMoneyFirst: 22,
      baseOvr: 69,
      balance: 34,
      transferBudget: 11,
      wageBudgetWeekly: 490,
      accentColor: '#60A5FA',
      clubs: [
        { id: 'sas', name: 'US Sassuolo', shortName: 'SAS', city: 'Sassuolo', stadium: 'Mapei Stadium', capacity: 21525, primaryColor: '#00A859', secondaryColor: '#111111', crestPattern: 'stripes', formation: '4-3-3 DM' },
        { id: 'pis', name: 'Pisa SC', shortName: 'PIS', city: 'Pisa', stadium: 'Arena Garibaldi', capacity: 14869, primaryColor: '#0055A4', secondaryColor: '#111111', crestPattern: 'stripes', formation: '3-4-2-1' },
        { id: 'spe', name: 'Spezia Calcio', shortName: 'SPE', city: 'La Spezia', stadium: 'Alberto Picco', capacity: 11968, primaryColor: '#FFFFFF', secondaryColor: '#111111', crestPattern: 'solid', formation: '3-5-2' },
        { id: 'crem', name: 'US Cremonese', shortName: 'CRE', city: 'Cremona', stadium: 'Giovanni Zini', capacity: 16003, primaryColor: '#999999', secondaryColor: '#CC0000', crestPattern: 'stripes', formation: '3-5-2' },
        { id: 'pal', name: 'Palermo FC', shortName: 'PAL', city: 'Palermo', stadium: 'Renzo Barbera', capacity: 36365, primaryColor: '#F49AC1', secondaryColor: '#111111', crestPattern: 'solid', formation: '4-3-3 DM' },
        { id: 'sam', name: 'UC Sampdoria', shortName: 'SAM', city: 'Genoa', stadium: 'Luigi Ferraris', capacity: 33205, primaryColor: '#0055A4', secondaryColor: '#FFFFFF', crestPattern: 'hoops', formation: '3-5-2' },
        { id: 'bar', name: 'SSC Bari', shortName: 'BAR', city: 'Bari', stadium: 'San Nicola', capacity: 58270, primaryColor: '#FFFFFF', secondaryColor: '#E11B22', crestPattern: 'sash', formation: '3-5-2' },
        { id: 'bre', name: 'Brescia Calcio', shortName: 'BRE', city: 'Brescia', stadium: 'Mario Rigamonti', capacity: 19550, primaryColor: '#0055A4', secondaryColor: '#FFFFFF', crestPattern: 'chevron', formation: '4-3-3 DM' },
        { id: 'mod', name: 'Modena FC', shortName: 'MOD', city: 'Modena', stadium: 'Alberto Braglia', capacity: 21092, primaryColor: '#FFD100', secondaryColor: '#0038A8', crestPattern: 'solid', formation: '3-4-2-1' },
        { id: 'sal', name: 'US Salernitana', shortName: 'SAL', city: 'Salerno', stadium: 'Arechi', capacity: 31300, primaryColor: '#8B1D24', secondaryColor: '#FFFFFF', crestPattern: 'solid', formation: '4-2-3-1' },
      ],
    },
    tier3: {
      name: 'Serie C NOW',
      shortName: 'SERC',
      tierLabel: 'Giải Hạng Thấp Nhất Ý (Hạng 3)',
      reputation: 55,
      prizeMoneyFirst: 5,
      baseOvr: 60,
      balance: 7,
      transferBudget: 2.2,
      wageBudgetWeekly: 110,
      accentColor: '#94A3B8',
      clubs: [
        { id: 'vic', name: 'LR Vicenza', shortName: 'VIC', city: 'Vicenza', stadium: 'Romeo Menti', capacity: 13173, primaryColor: '#E11B22', secondaryColor: '#FFFFFF', crestPattern: 'stripes', formation: '3-5-2' },
        { id: 'pad', name: 'Calcio Padova', shortName: 'PAD', city: 'Padua', stadium: 'Euganeo', capacity: 32420, primaryColor: '#FFFFFF', secondaryColor: '#E11B22', crestPattern: 'solid', formation: '3-4-2-1' },
        { id: 'ave', name: 'US Avellino', shortName: 'AVE', city: 'Avellino', stadium: 'Partenio-Lombardi', capacity: 10215, primaryColor: '#00843D', secondaryColor: '#FFFFFF', crestPattern: 'solid', formation: '4-3-3 DM' },
        { id: 'ben', name: 'Benevento Calcio', shortName: 'BEN', city: 'Benevento', stadium: 'Ciro Vigorito', capacity: 16867, primaryColor: '#FFDD00', secondaryColor: '#D21F26', crestPattern: 'stripes', formation: '4-2-3-1' },
        { id: 'cat', name: 'Catania FC', shortName: 'CAT', city: 'Catania', stadium: 'Angelo Massimino', capacity: 20204, primaryColor: '#E11B22', secondaryColor: '#009FE3', crestPattern: 'stripes', formation: '3-5-2' },
        { id: 'ter', name: 'Ternana Calcio', shortName: 'TER', city: 'Terni', stadium: 'Libero Liberati', capacity: 17460, primaryColor: '#00843D', secondaryColor: '#E11B22', crestPattern: 'stripes', formation: '4-2-3-1' },
        { id: 'pes', name: 'Pescara Calcio', shortName: 'PES', city: 'Pescara', stadium: 'Adriatico', capacity: 20515, primaryColor: '#009FE3', secondaryColor: '#FFFFFF', crestPattern: 'stripes', formation: '4-3-3 DM' },
        { id: 'tor3', name: 'Torres Sassari', shortName: 'TOR', city: 'Sassari', stadium: 'Vanni Sanna', capacity: 7480, primaryColor: '#004D98', secondaryColor: '#CC0000', crestPattern: 'stripes', formation: '3-4-2-1' },
        { id: 'tri', name: 'US Triestina', shortName: 'TRI', city: 'Trieste', stadium: 'Nereo Rocco', capacity: 26500, primaryColor: '#CC0000', secondaryColor: '#FFFFFF', crestPattern: 'solid', formation: '4-4-2' },
        { id: 'per', name: 'AC Perugia', shortName: 'PER', city: 'Perugia', stadium: 'Renato Curi', capacity: 23625, primaryColor: '#CC0000', secondaryColor: '#FFFFFF', crestPattern: 'solid', formation: '4-2-3-1' },
      ],
    },
  },
  ger_bundesliga: {
    countryLeagueId: 'ger_bundesliga',
    country: 'Đức',
    tier2: {
      name: '2. Bundesliga',
      shortName: '2BUN',
      tierLabel: 'Giải Hạng Nhì Đức (Hạng 2)',
      reputation: 72,
      prizeMoneyFirst: 26,
      baseOvr: 70,
      balance: 40,
      transferBudget: 13,
      wageBudgetWeekly: 550,
      accentColor: '#F87171',
      clubs: [
        { id: 'hsv', name: 'Hamburger SV', shortName: 'HSV', city: 'Hamburg', stadium: 'Volksparkstadion', capacity: 57000, primaryColor: '#005CA9', secondaryColor: '#FFFFFF', crestPattern: 'solid', formation: '4-3-3 DM' },
        { id: 'koe', name: '1. FC Koln', shortName: 'KOE', city: 'Cologne', stadium: 'RheinEnergieStadion', capacity: 50000, primaryColor: '#FFFFFF', secondaryColor: '#ED1C24', crestPattern: 'sash', formation: '4-2-3-1' },
        { id: 'f95', name: 'Fortuna Dusseldorf', shortName: 'F95', city: 'Dusseldorf', stadium: 'Merkur Spiel-Arena', capacity: 54600, primaryColor: '#E30613', secondaryColor: '#FFFFFF', crestPattern: 'solid', formation: '4-2-3-1' },
        { id: 'h96', name: 'Hannover 96', shortName: 'H96', city: 'Hannover', stadium: 'Heinz von Heiden Arena', capacity: 49000, primaryColor: '#1E823C', secondaryColor: '#111111', crestPattern: 'solid', formation: '3-5-2' },
        { id: 'bsc', name: 'Hertha BSC', shortName: 'BSC', city: 'Berlin', stadium: 'Olympiastadion', capacity: 74475, primaryColor: '#005CA9', secondaryColor: '#FFFFFF', crestPattern: 'stripes', formation: '4-2-3-1' },
        { id: 's04', name: 'FC Schalke 04', shortName: 'S04', city: 'Gelsenkirchen', stadium: 'Veltins-Arena', capacity: 62271, primaryColor: '#004D9D', secondaryColor: '#FFFFFF', crestPattern: 'solid', formation: '4-4-2' },
        { id: 'fck', name: '1. FC Kaiserslautern', shortName: 'FCK', city: 'Kaiserslautern', stadium: 'Fritz-Walter-Stadion', capacity: 49327, primaryColor: '#E30613', secondaryColor: '#FFFFFF', crestPattern: 'solid', formation: '3-4-2-1' },
        { id: 'ksc', name: 'Karlsruher SC', shortName: 'KSC', city: 'Karlsruhe', stadium: 'BBBank Wildpark', capacity: 34302, primaryColor: '#005CA9', secondaryColor: '#FFFFFF', crestPattern: 'stripes', formation: '4-4-2' },
        { id: 'scp', name: 'SC Paderborn 07', shortName: 'SCP', city: 'Paderborn', stadium: 'Home Deluxe Arena', capacity: 15000, primaryColor: '#005CA9', secondaryColor: '#111111', crestPattern: 'stripes', formation: '3-4-2-1' },
        { id: 'sge2', name: 'SpVgg Greuther Furth', shortName: 'SGF', city: 'Furth', stadium: 'Sportpark Ronhof', capacity: 16626, primaryColor: '#FFFFFF', secondaryColor: '#00843D', crestPattern: 'hoops', formation: '3-5-2' },
      ],
    },
    tier3: {
      name: '3. Liga',
      shortName: '3LIG',
      tierLabel: 'Giải Hạng Thấp Nhất Đức (Hạng 3)',
      reputation: 57,
      prizeMoneyFirst: 7,
      baseOvr: 61,
      balance: 9,
      transferBudget: 2.8,
      wageBudgetWeekly: 130,
      accentColor: '#94A3B8',
      clubs: [
        { id: 'sgd', name: 'Dynamo Dresden', shortName: 'SGD', city: 'Dresden', stadium: 'Rudolf-Harbig-Stadion', capacity: 32066, primaryColor: '#FFD100', secondaryColor: '#111111', crestPattern: 'solid', formation: '4-3-3 DM' },
        { id: 'dsc', name: 'Arminia Bielefeld', shortName: 'DSC', city: 'Bielefeld', stadium: 'SchucoArena', capacity: 27332, primaryColor: '#004E98', secondaryColor: '#111111', crestPattern: 'solid', formation: '4-3-3 DM' },
        { id: 'm60', name: 'TSV 1860 Munich', shortName: 'M60', city: 'Munich', stadium: 'Grunwalder Stadion', capacity: 15000, primaryColor: '#87D8F7', secondaryColor: '#FFFFFF', crestPattern: 'solid', formation: '4-2-3-1' },
        { id: 'fce', name: 'Energie Cottbus', shortName: 'FCE', city: 'Cottbus', stadium: 'LEAG Energie Stadion', capacity: 22528, primaryColor: '#E30613', secondaryColor: '#FFFFFF', crestPattern: 'solid', formation: '4-3-3 DM' },
        { id: 'fch', name: 'Hansa Rostock', shortName: 'FCH', city: 'Rostock', stadium: 'Ostseestadion', capacity: 29000, primaryColor: '#004E98', secondaryColor: '#FFFFFF', crestPattern: 'solid', formation: '3-5-2' },
        { id: 'fcs', name: '1. FC Saarbrucken', shortName: 'FCS', city: 'Saarbrucken', stadium: 'Ludwigsparkstadion', capacity: 16003, primaryColor: '#004E98', secondaryColor: '#111111', crestPattern: 'stripes', formation: '3-5-2' },
        { id: 'rwe', name: 'Rot-Weiss Essen', shortName: 'RWE', city: 'Essen', stadium: 'Stadion an der Hafenstrasse', capacity: 19962, primaryColor: '#E30613', secondaryColor: '#FFFFFF', crestPattern: 'solid', formation: '4-2-3-1' },
        { id: 'svw3', name: 'Waldhof Mannheim', shortName: 'WMA', city: 'Mannheim', stadium: 'Carl-Benz-Stadion', capacity: 24302, primaryColor: '#005CA9', secondaryColor: '#111111', crestPattern: 'stripes', formation: '4-2-3-1' },
        { id: 'vfl', name: 'VfL Osnabruck', shortName: 'OSN', city: 'Osnabruck', stadium: 'Bremer Brucke', capacity: 15741, primaryColor: '#6F2C91', secondaryColor: '#FFFFFF', crestPattern: 'solid', formation: '4-4-2' },
        { id: 'ing', name: 'FC Ingolstadt 04', shortName: 'FCI', city: 'Ingolstadt', stadium: 'Audi Sportpark', capacity: 15200, primaryColor: '#111111', secondaryColor: '#E30613', crestPattern: 'stripes', formation: '4-4-2' },
      ],
    },
  },
  fra_ligue1: {
    countryLeagueId: 'fra_ligue1',
    country: 'Pháp',
    tier2: {
      name: 'Ligue 2 BKT',
      shortName: 'L2',
      tierLabel: 'Giải Hạng Nhì Pháp (Hạng 2)',
      reputation: 69,
      prizeMoneyFirst: 18,
      baseOvr: 68,
      balance: 28,
      transferBudget: 9,
      wageBudgetWeekly: 420,
      accentColor: '#34D399',
      clubs: [
        { id: 'lor', name: 'FC Lorient', shortName: 'LOR', city: 'Lorient', stadium: 'Stade du Moustoir', capacity: 18110, primaryColor: '#F36F21', secondaryColor: '#111111', crestPattern: 'solid', formation: '4-2-3-1' },
        { id: 'met', name: 'FC Metz', shortName: 'MET', city: 'Metz', stadium: 'Saint-Symphorien', capacity: 28786, primaryColor: '#7A1C2E', secondaryColor: '#FFFFFF', crestPattern: 'solid', formation: '4-2-3-1' },
        { id: 'pfc', name: 'Paris FC', shortName: 'PFC', city: 'Paris', stadium: 'Stade Charlety', capacity: 19151, primaryColor: '#003366', secondaryColor: '#FFFFFF', crestPattern: 'solid', formation: '4-3-3 DM' },
        { id: 'eag', name: 'EA Guingamp', shortName: 'EAG', city: 'Guingamp', stadium: 'Roudourou', capacity: 19060, primaryColor: '#E11B22', secondaryColor: '#111111', crestPattern: 'halves', formation: '4-4-2' },
        { id: 'dun', name: 'USL Dunkerque', shortName: 'DUN', city: 'Dunkirk', stadium: 'Marcel-Tribut', capacity: 5000, primaryColor: '#009FE3', secondaryColor: '#FFFFFF', crestPattern: 'stripes', formation: '4-3-3 DM' },
        { id: 'scb', name: 'SC Bastia', shortName: 'SCB', city: 'Bastia', stadium: 'Armand Cesari', capacity: 16048, primaryColor: '#0055A4', secondaryColor: '#FFFFFF', crestPattern: 'solid', formation: '4-2-3-1' },
        { id: 'smc', name: 'SM Caen', shortName: 'SMC', city: 'Caen', stadium: 'Michel dOrnano', capacity: 20300, primaryColor: '#004D98', secondaryColor: '#D21F26', crestPattern: 'stripes', formation: '4-4-2' },
        { id: 'est', name: 'ESTAC Troyes', shortName: 'EST', city: 'Troyes', stadium: 'Stade de lAube', capacity: 20400, primaryColor: '#005BAC', secondaryColor: '#FFFFFF', crestPattern: 'solid', formation: '4-3-3 DM' },
        { id: 'gf38', name: 'Grenoble Foot 38', shortName: 'GF3', city: 'Grenoble', stadium: 'Stade des Alpes', capacity: 20068, primaryColor: '#0055A4', secondaryColor: '#FFFFFF', crestPattern: 'solid', formation: '5-3-2' },
        { id: 'ami', name: 'Amiens SC', shortName: 'AMI', city: 'Amiens', stadium: 'Credit Agricole la Licorne', capacity: 12999, primaryColor: '#FFFFFF', secondaryColor: '#111111', crestPattern: 'solid', formation: '4-2-3-1' },
      ],
    },
    tier3: {
      name: 'Championnat National',
      shortName: 'NAT',
      tierLabel: 'Giải Hạng Thấp Nhất Pháp (Hạng 3)',
      reputation: 54,
      prizeMoneyFirst: 5,
      baseOvr: 59,
      balance: 6,
      transferBudget: 2,
      wageBudgetWeekly: 95,
      accentColor: '#94A3B8',
      clubs: [
        { id: 'nan', name: 'AS Nancy Lorraine', shortName: 'NAN', city: 'Nancy', stadium: 'Marcel Picot', capacity: 20087, primaryColor: '#FFFFFF', secondaryColor: '#E11B22', crestPattern: 'chevron', formation: '3-4-2-1' },
        { id: 'lem', name: 'Le Mans FC', shortName: 'LEM', city: 'Le Mans', stadium: 'Marie-Marvingt', capacity: 25064, primaryColor: '#E11B22', secondaryColor: '#FFD100', crestPattern: 'halves', formation: '3-5-2' },
        { id: 'soc', name: 'FC Sochaux', shortName: 'SOC', city: 'Montbeliard', stadium: 'Auguste Bonal', capacity: 20005, primaryColor: '#FFD100', secondaryColor: '#0038A8', crestPattern: 'solid', formation: '4-3-3 DM' },
        { id: 'dij', name: 'Dijon FCO', shortName: 'DIJ', city: 'Dijon', stadium: 'Gaston Gerard', capacity: 15459, primaryColor: '#E11B22', secondaryColor: '#111111', crestPattern: 'solid', formation: '4-2-3-1' },
        { id: 'val3', name: 'Valenciennes FC', shortName: 'VAFC', city: 'Valenciennes', stadium: 'Stade du Hainaut', capacity: 25172, primaryColor: '#E11B22', secondaryColor: '#FFFFFF', crestPattern: 'solid', formation: '4-4-2' },
        { id: 'bou', name: 'US Boulogne', shortName: 'BOU', city: 'Boulogne', stadium: 'Liberation', capacity: 15204, primaryColor: '#E11B22', secondaryColor: '#111111', crestPattern: 'stripes', formation: '4-2-3-1' },
        { id: 'que', name: 'Quevilly-Rouen', shortName: 'QRM', city: 'Rouen', stadium: 'Robert Diochon', capacity: 8372, primaryColor: '#FFD100', secondaryColor: '#E11B22', crestPattern: 'halves', formation: '4-3-3 DM' },
        { id: 'orl', name: 'US Orleans', shortName: 'ORL', city: 'Orleans', stadium: 'Stade de la Source', capacity: 7533, primaryColor: '#FFD100', secondaryColor: '#E11B22', crestPattern: 'solid', formation: '4-4-2' },
        { id: 'cha', name: 'LB Chateauroux', shortName: 'CHA', city: 'Chateauroux', stadium: 'Gaston Petit', capacity: 17072, primaryColor: '#E11B22', secondaryColor: '#0055A4', crestPattern: 'stripes', formation: '5-3-2' },
        { id: 'rou', name: 'FC Rouen', shortName: 'ROU', city: 'Rouen', stadium: 'Robert Diochon', capacity: 8372, primaryColor: '#E11B22', secondaryColor: '#FFFFFF', crestPattern: 'solid', formation: '3-4-2-1' },
      ],
    },
  },
  vie_vleague: {
    countryLeagueId: 'vie_vleague',
    country: 'Việt Nam',
    tier2: {
      name: 'Giải Hạng Nhất QG',
      shortName: 'VL2',
      tierLabel: 'Gold Star V.League 2 (Hạng 2)',
      reputation: 60,
      prizeMoneyFirst: 5,
      baseOvr: 62,
      balance: 8,
      transferBudget: 2.2,
      wageBudgetWeekly: 105,
      accentColor: '#F59E0B',
      clubs: [
        { id: 'pdnb', name: 'Phù Đổng Ninh Bình', shortName: 'NBI', city: 'Ninh Bình', stadium: 'SVĐ Ninh Bình', capacity: 22000, primaryColor: '#0055A4', secondaryColor: '#F59E0B', crestPattern: 'solid', formation: '4-2-3-1' },
        { id: 'ttbp', name: 'Trường Tươi Bình Phước', shortName: 'BPH', city: 'Đồng Xoài', stadium: 'SVĐ Bình Phước', capacity: 10000, primaryColor: '#0072BC', secondaryColor: '#FFFFFF', crestPattern: 'chevron', formation: '4-3-3 DM' },
        { id: 'pvf', name: 'PVF-CAND', shortName: 'PVF', city: 'Hưng Yên', stadium: 'SVĐ PVF', capacity: 4500, primaryColor: '#D71920', secondaryColor: '#111827', crestPattern: 'sash', formation: '4-3-3 DM' },
        { id: 'shb', name: 'SHB Đà Nẵng', shortName: 'SHB', city: 'Đà Nẵng', stadium: 'SVĐ Hòa Xuân', capacity: 20000, primaryColor: '#F36F21', secondaryColor: '#FFFFFF', crestPattern: 'solid', formation: '4-2-3-1' },
        { id: 'khh', name: 'Khánh Hòa FC', shortName: 'KHA', city: 'Nha Trang', stadium: 'SVĐ 19/8 Nha Trang', capacity: 18000, primaryColor: '#005BAC', secondaryColor: '#FFFFFF', crestPattern: 'stripes', formation: '4-4-2' },
        { id: 'lan', name: 'Long An FC', shortName: 'LAN', city: 'Tân An', stadium: 'SVĐ Long An', capacity: 19975, primaryColor: '#E11B22', secondaryColor: '#FFFFFF', crestPattern: 'solid', formation: '4-4-2' },
        { id: 'hue', name: 'CLB Bóng đá Huế', shortName: 'HUE', city: 'Huế', stadium: 'SVĐ Tự Do', capacity: 20000, primaryColor: '#6F2C91', secondaryColor: '#FFFFFF', crestPattern: 'solid', formation: '5-3-2' },
        { id: 'brvt', name: 'Bà Rịa Vũng Tàu', shortName: 'BRV', city: 'Bà Rịa', stadium: 'SVĐ Bà Rịa', capacity: 10000, primaryColor: '#006838', secondaryColor: '#FFD100', crestPattern: 'halves', formation: '4-2-3-1' },
        { id: 'dtp', name: 'Đồng Tháp FC', shortName: 'DTH', city: 'Cao Lãnh', stadium: 'SVĐ Cao Lãnh', capacity: 23000, primaryColor: '#FFD100', secondaryColor: '#006838', crestPattern: 'stripes', formation: '4-4-2' },
        { id: 'hbi', name: 'Hòa Bình FC', shortName: 'HBI', city: 'Hòa Bình', stadium: 'SVĐ Hòa Bình', capacity: 10000, primaryColor: '#00843D', secondaryColor: '#FFFFFF', crestPattern: 'sash', formation: '4-4-2' },
      ],
    },
    tier3: {
      name: 'Giải Hạng Nhì QG',
      shortName: 'HN2',
      tierLabel: 'Giải Hạng Thấp Nhất VN (Hạng 3)',
      reputation: 48,
      prizeMoneyFirst: 1.5,
      baseOvr: 54,
      balance: 3,
      transferBudget: 0.8,
      wageBudgetWeekly: 45,
      accentColor: '#94A3B8',
      clubs: [
        { id: 'bni', name: 'Bắc Ninh FC', shortName: 'BNI', city: 'Bắc Ninh', stadium: 'SVĐ Từ Sơn', capacity: 8000, primaryColor: '#F59E0B', secondaryColor: '#111827', crestPattern: 'chevron', formation: '4-3-3 DM' },
        { id: 'ldo', name: 'Lâm Đồng FC', shortName: 'LDO', city: 'Đà Lạt', stadium: 'SVĐ Đà Lạt', capacity: 20000, primaryColor: '#00843D', secondaryColor: '#FFFFFF', crestPattern: 'solid', formation: '4-4-2' },
        { id: 'ktu', name: 'Kon Tum FC', shortName: 'KTU', city: 'Kon Tum', stadium: 'SVĐ Kon Tum', capacity: 11000, primaryColor: '#E11B22', secondaryColor: '#FFFFFF', crestPattern: 'stripes', formation: '4-2-3-1' },
        { id: 'tre', name: 'Trẻ TP. Hồ Chí Minh', shortName: 'TRE', city: 'TP.HCM', stadium: 'SVĐ Thống Nhất', capacity: 15000, primaryColor: '#0055A4', secondaryColor: '#E11B22', crestPattern: 'halves', formation: '4-3-3 DM' },
        { id: 'dla', name: 'Đắk Lắk FC', shortName: 'DLA', city: 'Buôn Ma Thuột', stadium: 'SVĐ Buôn Ma Thuột', capacity: 20000, primaryColor: '#E11B22', secondaryColor: '#FFD100', crestPattern: 'solid', formation: '4-4-2' },
        { id: 'tni', name: 'Tây Ninh FC', shortName: 'TNI', city: 'Tây Ninh', stadium: 'SVĐ Tây Ninh', capacity: 15500, primaryColor: '#006838', secondaryColor: '#FFFFFF', crestPattern: 'sash', formation: '5-3-2' },
        { id: 'vlo', name: 'Vĩnh Long FC', shortName: 'VLO', city: 'Vĩnh Long', stadium: 'SVĐ Vĩnh Long', capacity: 10000, primaryColor: '#009FE3', secondaryColor: '#FFFFFF', crestPattern: 'solid', formation: '4-4-2' },
        { id: 'pth', name: 'Phú Thọ FC', shortName: 'PTH', city: 'Việt Trì', stadium: 'SVĐ Việt Trì', capacity: 20000, primaryColor: '#8B1D24', secondaryColor: '#FFD100', crestPattern: 'solid', formation: '4-2-3-1' },
        { id: 'gdi', name: 'Gia Định FC', shortName: 'GDI', city: 'TP.HCM', stadium: 'SVĐ Quân Khu 7', capacity: 18000, primaryColor: '#111827', secondaryColor: '#10B981', crestPattern: 'sash', formation: '4-3-3 DM' },
        { id: 'tnu', name: 'Tiền Giang FC', shortName: 'TGI', city: 'Mỹ Tho', stadium: 'SVĐ Tiền Giang', capacity: 12000, primaryColor: '#0055A4', secondaryColor: '#FFFFFF', crestPattern: 'stripes', formation: '4-4-2' },
      ],
    },
  },
};

export function buildPyramidLeagueDefs(countryLeagueId: LeagueId): Record<string, LeagueDefinition> {
  const pyr = COUNTRY_PYRAMIDS[countryLeagueId] ?? COUNTRY_PYRAMIDS.vie_vleague;
  const top = LEAGUES[countryLeagueId];
  const defs: Record<string, LeagueDefinition> = {};

  for (const lid of LEAGUE_ORDER) {
    const base = LEAGUES[lid];
    defs[lid] = {
      ...base,
      tierLevel: 1,
      promotionSlots: 0,
      relegationSlots: lid === countryLeagueId ? 2 : base.relegationSlots,
      relegatedToLeagueId: lid === countryLeagueId ? 'div_2' : undefined,
    };
  }

  defs.div_2 = {
    id: 'div_2',
    name: pyr.tier2.name,
    country: pyr.country,
    shortName: pyr.tier2.shortName,
    tierLabel: pyr.tier2.tierLabel,
    tierLevel: 2,
    reputation: pyr.tier2.reputation,
    prizeMoneyFirst: pyr.tier2.prizeMoneyFirst,
    championsSlots: 0,
    promotionSlots: 2,
    relegationSlots: 2,
    promotedToLeagueId: top.id,
    relegatedToLeagueId: 'div_3',
    accentColor: pyr.tier2.accentColor,
  };

  defs.div_3 = {
    id: 'div_3',
    name: pyr.tier3.name,
    country: pyr.country,
    shortName: pyr.tier3.shortName,
    tierLabel: pyr.tier3.tierLabel,
    tierLevel: 3,
    reputation: pyr.tier3.reputation,
    prizeMoneyFirst: pyr.tier3.prizeMoneyFirst,
    championsSlots: 0,
    promotionSlots: 2,
    relegationSlots: 0,
    promotedToLeagueId: 'div_2',
    accentColor: pyr.tier3.accentColor,
  };

  return defs;
}

export function getCareerLeagueOrder(countryLeagueId: LeagueId): LeagueId[] {
  const others = LEAGUE_ORDER.filter((lid) => lid !== countryLeagueId);
  return ['div_3', 'div_2', countryLeagueId, ...others];
}

function buildSeedFromTemplate(
  tpl: LowerClubTemplate,
  leagueId: LeagueId,
  country: string,
  meta: CountryPyramidConfig['tier2'],
  index: number
): RawClubSeed {
  return {
    id: tpl.id,
    leagueId,
    name: tpl.name,
    shortName: tpl.shortName,
    country,
    city: tpl.city,
    stadium: tpl.stadium,
    capacity: tpl.capacity,
    reputation: Math.max(40, meta.reputation - Math.floor(index / 2)),
    baseOvr: Math.max(50, meta.baseOvr - Math.floor(index / 3)),
    primaryColor: tpl.primaryColor,
    secondaryColor: tpl.secondaryColor,
    crestPattern: tpl.crestPattern,
    expectation: index < 3 ? 'Cạnh tranh suất thăng hạng' : 'Ổn định vị trí trên BXH',
    targetPosition: index + 1,
    balance: Math.max(1.5, Math.round((meta.balance - index * 0.4) * 10) / 10),
    transferBudget: Math.max(0.4, Math.round((meta.transferBudget - index * 0.15) * 10) / 10),
    wageBudgetWeekly: Math.max(25, meta.wageBudgetWeekly - index * 5),
    formation: tpl.formation,
    mentality: index < 3 ? 'Tấn công' : index > 7 ? 'Phòng ngự' : 'Cân bằng',
    pressing: index < 4 ? 'Gegenpress' : 'Trung bình',
    passing: index % 2 === 0 ? 'Kết hợp' : 'Ngắn',
    players: [],
  };
}

export function attachCountryPyramid(
  db: { clubs: Record<string, Club>; players: Record<string, Player> },
  countryLeagueId: LeagueId,
  customConfig?: CustomClubConfig
): {
  clubs: Record<string, Club>;
  players: Record<string, Player>;
  leagues: Record<string, LeagueDefinition>;
  leagueOrder: LeagueId[];
  customClubId?: string;
} {
  const clubs = { ...db.clubs };
  const players = { ...db.players };
  const pyr = COUNTRY_PYRAMIDS[countryLeagueId] ?? COUNTRY_PYRAMIDS.vie_vleague;
  const leagues = buildPyramidLeagueDefs(countryLeagueId);
  const leagueOrder = getCareerLeagueOrder(countryLeagueId);

  // Add all 10 Tier-2 clubs
  pyr.tier2.clubs.forEach((tpl, idx) => {
    const seed = buildSeedFromTemplate(tpl, 'div_2', pyr.country, pyr.tier2, idx);
    const { club, clubPlayers } = materializeClubSeed(seed);
    clubs[club.id] = club;
    for (const pl of clubPlayers) players[pl.id] = pl;
  });

  // Add Tier-3 clubs: 9 rivals + custom club (if custom mode), or all 10 if existing mode
  const tier3Templates = customConfig ? pyr.tier3.clubs.slice(0, 9) : pyr.tier3.clubs;
  tier3Templates.forEach((tpl, idx) => {
    const seed = buildSeedFromTemplate(tpl, 'div_3', pyr.country, pyr.tier3, idx);
    const { club, clubPlayers } = materializeClubSeed(seed);
    clubs[club.id] = club;
    for (const pl of clubPlayers) players[pl.id] = pl;
  });

  if (!customConfig) {
    return { clubs, players, leagues, leagueOrder };
  }

  // Create user's Custom Club in the lowest tier (div_3)
  const isVN = countryLeagueId === 'vie_vleague';
  const baseDiv3Ovr = pyr.tier3.baseOvr;
  const tierSpec = {
    underdog: {
      baseOvr: baseDiv3Ovr - 1,
      rep: pyr.tier3.reputation - 3,
      balance: isVN ? 2.5 : 6.0,
      budget: isVN ? 0.6 : 1.8,
      wage: isVN ? 35 : 95,
      expectation: `Tích lũy kinh nghiệm & bứt phá khỏi ${pyr.tier3.name}`,
      targetPos: 6,
    },
    midtable: {
      baseOvr: baseDiv3Ovr + 1,
      rep: pyr.tier3.reputation,
      balance: isVN ? 4.5 : 11.0,
      budget: isVN ? 1.4 : 4.2,
      wage: isVN ? 55 : 155,
      expectation: `Giành Top 2 thăng hạng lên ${pyr.tier2.name}`,
      targetPos: 2,
    },
    tycoon: {
      baseOvr: baseDiv3Ovr + 4,
      rep: pyr.tier3.reputation + 5,
      balance: isVN ? 12.0 : 32.0,
      budget: isVN ? 4.5 : 14.0,
      wage: isVN ? 110 : 320,
      expectation: `Vô địch ${pyr.tier3.name} & thăng hạng thần tốc`,
      targetPos: 1,
    },
  }[customConfig.tier];

  const customClubId = 'custom_fc';
  const starName = customConfig.starPlayerName?.trim();
  const initialSeeds: RawPlayerSeed[] = starName
    ? [
        {
          name: starName,
          nat: pyr.country,
          age: 22,
          pos: 'ST',
          sec: ['AM', 'LW'],
          ovr: Math.min(78, tierSpec.baseOvr + 5),
          pa: Math.min(92, tierSpec.baseOvr + 24),
          num: 10,
          role: 'Ngôi sao',
        },
      ]
    : [];

  const fullSeeds = fillSquadTo18(
    customClubId,
    customConfig.formation,
    pyr.country,
    tierSpec.baseOvr,
    initialSeeds
  );
  const clubPlayers = fullSeeds.map((s, idx) =>
    makePlayer(customClubId, s, idx, 'div_3', pyr.country)
  );
  for (const pl of clubPlayers) {
    players[pl.id] = pl;
  }

  const { lineupIds, benchIds } = autoPickBestLineup(clubPlayers, customConfig.formation);
  const slots = FORMATIONS[customConfig.formation];

  clubs[customClubId] = {
    id: customClubId,
    leagueId: 'div_3',
    name: customConfig.name.trim(),
    shortName: customConfig.shortName.trim().toUpperCase().slice(0, 3) || 'CFC',
    country: pyr.country,
    city: customConfig.city.trim() || 'Thành phố Mới',
    stadium: customConfig.stadium.trim() || 'Sân Vận Động Trung Tâm',
    capacity: customConfig.capacity,
    reputation: tierSpec.rep,
    primaryColor: customConfig.primaryColor,
    secondaryColor: customConfig.secondaryColor,
    crestPattern: customConfig.crestPattern,
    expectation: tierSpec.expectation,
    targetPosition: tierSpec.targetPos,
    isCustom: true,
    finances: {
      balance: tierSpec.balance,
      transferBudget: tierSpec.budget,
      wageBudgetWeekly: tierSpec.wage,
      monthlyIncomeMatchday:
        Math.round((customConfig.capacity / 1000) * (isVN ? 0.025 : 0.05) * 10) / 10,
      monthlyIncomeSponsor:
        Math.round(Math.max(0.4, (tierSpec.rep - 42) * (isVN ? 0.1 : 0.18)) * 10) / 10,
      boardConfidence: 82,
      fanConfidence: 88,
    },
    tactics: {
      formation: customConfig.formation,
      mentality: 'Cân bằng',
      passing: 'Kết hợp',
      tempo: 'Vừa',
      pressing: 'Trung bình',
      defensiveLine: 'Trung bình',
      lineupIds,
      benchIds,
      slotRoles: slots.map((s) => s.role),
      slotDuties: slots.map((s) => s.duty),
    },
  };

  return { clubs, players, leagues, leagueOrder, customClubId };
}
