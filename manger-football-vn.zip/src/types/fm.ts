export type Position =
  | 'GK'
  | 'LB'
  | 'CB'
  | 'RB'
  | 'DM'
  | 'CM'
  | 'AM'
  | 'LW'
  | 'RW'
  | 'ST';

export type Foot = 'Phải' | 'Trái' | 'Hai chân';

export type SquadRole = 'Ngôi sao' | 'Đá chính' | 'Xoay tua' | 'Dự bị' | 'Tài năng trẻ';

export type LeagueId =
  | 'eng_pl'
  | 'esp_laliga'
  | 'ita_seriea'
  | 'ger_bundesliga'
  | 'fra_ligue1'
  | 'vie_vleague'
  | 'div_2'
  | 'div_3';

export interface LeagueDefinition {
  id: LeagueId;
  name: string;
  country: string;
  shortName: string;
  tierLabel: string;
  tierLevel?: 1 | 2 | 3;
  reputation: number;
  prizeMoneyFirst: number; // EUR millions
  championsSlots: number;
  promotionSlots?: number;
  relegationSlots: number;
  promotedToLeagueId?: LeagueId;
  relegatedToLeagueId?: LeagueId;
  accentColor: string;
}

export interface PlayerAttributes {
  // Technical (1-20)
  finishing: number;
  passing: number;
  dribbling: number;
  firstTouch: number;
  tackling: number;
  marking: number;
  crossing: number;
  technique: number;
  longShots: number;
  heading: number;
  // Mental (1-20)
  vision: number;
  decisions: number;
  composure: number;
  positioning: number;
  offTheBall: number;
  workRate: number;
  determination: number;
  leadership: number;
  // Physical (1-20)
  pace: number;
  acceleration: number;
  stamina: number;
  strength: number;
  agility: number;
  // Goalkeeping (1-20)
  reflexes: number;
  handling: number;
  oneOnOnes: number;
  aerialReach: number;
}

export interface PlayerSeasonStats {
  appearances: number;
  goals: number;
  assists: number;
  cleanSheets: number;
  yellowCards: number;
  redCards: number;
  avgRating: number;
  ratingCount: number;
  xg: number;
}

export interface Player {
  id: string;
  name: string;
  nationality: string;
  age: number;
  clubId: string;
  primaryPosition: Position;
  secondaryPositions: Position[];
  foot: Foot;
  heightCm: number;
  shirtNumber: number;
  ca: number; // Current Ability 1-200
  pa: number; // Potential Ability 1-200
  ovr: number; // Derived 1-99 display rating
  marketValue: number; // in EUR millions
  weeklyWage: number; // in EUR thousands
  contractUntilYear: number;
  squadRole: SquadRole;
  condition: number; // 0-100%
  sharpness: number; // 0-100%
  morale: number; // 1-100
  injuryDays: number;
  injuryType: string | null;
  suspendedMatches: number;
  yellowCardAccumulation: number;
  transferListed: boolean;
  scouted: boolean;
  form: ('W' | 'D' | 'L')[];
  lastFiveRatings: number[];
  attributes: PlayerAttributes;
  stats: PlayerSeasonStats;
}

export type CrestPattern = 'stripes' | 'halves' | 'sash' | 'hoops' | 'solid' | 'chevron';

export type TacticalMentality =
  | 'Rất phòng ngự'
  | 'Phòng ngự'
  | 'Cân bằng'
  | 'Tấn công'
  | 'Tổng lực';

export type PassingStyle = 'Ngắn' | 'Kết hợp' | 'Dài';
export type TempoStyle = 'Chậm' | 'Vừa' | 'Nhanh';
export type PressingIntensity = 'Thấp' | 'Trung bình' | 'Gegenpress';
export type DefensiveLine = 'Thấp' | 'Trung bình' | 'Dâng cao';

export type FormationName =
  | '4-3-3 DM'
  | '4-2-3-1'
  | '4-4-2'
  | '3-5-2'
  | '3-4-2-1'
  | '4-1-4-1'
  | '5-3-2';

export interface TacticalSlot {
  slotIndex: number;
  label: string;
  position: Position;
  role: string;
  duty: 'Phòng ngự' | 'Hỗ trợ' | 'Tấn công';
  x: number;
  y: number;
}

export interface TeamTactics {
  formation: FormationName;
  mentality: TacticalMentality;
  passing: PassingStyle;
  tempo: TempoStyle;
  pressing: PressingIntensity;
  defensiveLine: DefensiveLine;
  lineupIds: (string | null)[];
  benchIds: string[];
  slotRoles: string[];
  slotDuties: ('Phòng ngự' | 'Hỗ trợ' | 'Tấn công')[];
}

export interface ClubFinances {
  balance: number; // EUR millions
  transferBudget: number; // EUR millions
  wageBudgetWeekly: number; // EUR thousands
  monthlyIncomeMatchday: number; // EUR millions
  monthlyIncomeSponsor: number; // EUR millions
  boardConfidence: number; // 0-100
  fanConfidence: number; // 0-100
}

export interface Club {
  id: string;
  leagueId: LeagueId;
  name: string;
  shortName: string;
  country: string;
  city: string;
  stadium: string;
  capacity: number;
  reputation: number; // 1-100
  primaryColor: string;
  secondaryColor: string;
  crestPattern: CrestPattern;
  expectation: string;
  targetPosition: number;
  isCustom?: boolean;
  finances: ClubFinances;
  tactics: TeamTactics;
}

export type CustomClubTier = 'underdog' | 'midtable' | 'tycoon';

export interface CustomClubConfig {
  name: string;
  shortName: string;
  city: string;
  stadium: string;
  capacity: number;
  leagueId: LeagueId;
  primaryColor: string;
  secondaryColor: string;
  crestPattern: CrestPattern;
  tier: CustomClubTier;
  formation: FormationName;
  starPlayerName?: string;
}

export interface LeagueStandingRow {
  clubId: string;
  played: number;
  won: number;
  drawn: number;
  lost: number;
  gf: number;
  ga: number;
  gd: number;
  points: number;
  form: ('W' | 'D' | 'L')[];
}

export interface Fixture {
  id: string;
  leagueId: LeagueId;
  round: number;
  dateISO: string;
  homeClubId: string;
  awayClubId: string;
  played: boolean;
  homeGoals: number | null;
  awayGoals: number | null;
  homeXg?: number;
  awayXg?: number;
  goalEvents?: {
    minute: number;
    playerId: string;
    playerName: string;
    assistPlayerName?: string;
    clubId: string;
  }[];
}

export type TrainingFocus =
  | 'Cân bằng tổng hợp'
  | 'Chiến thuật & Kiểm soát bóng'
  | 'Dứt điểm & Phối hợp tấn công'
  | 'Phòng ngự & Kèm người'
  | 'Thể lực & Pressing'
  | 'Hồi phục nhẹ';

export type TrainingIntensity = 'Nhẹ' | 'Trung bình' | 'Cao';

export interface TransferBid {
  id: string;
  playerId: string;
  fromClubId: string;
  toClubId: string;
  fee: number; // EUR millions
  status: 'pending' | 'accepted' | 'rejected' | 'countered' | 'completed';
  counterFee?: number;
  dateISO: string;
}

export interface InboxMessage {
  id: string;
  dateISO: string;
  category: 'Ban lãnh đạo' | 'Trinh sát' | 'Chuyển nhượng' | 'Y tế' | 'Trận đấu';
  sender: string;
  subject: string;
  body: string;
  read: boolean;
  actionType?: 'incoming_bid' | 'next_match' | 'none';
  relatedBidId?: string;
  relatedFixtureId?: string;
}

export type GameScreen = 'title' | 'workspace' | 'match';

export type WorkspaceTab =
  | 'inbox'
  | 'squad'
  | 'tactics'
  | 'competitions'
  | 'transfers'
  | 'training'
  | 'board';

export interface MatchAgent {
  playerId: string;
  name: string;
  shirtNumber: number;
  team: 'home' | 'away';
  position: Position;
  role: string;
  duty: 'Phòng ngự' | 'Hỗ trợ' | 'Tấn công';
  ovr: number;
  x: number;
  y: number;
  vx: number;
  vy: number;
  baseX: number;
  baseY: number;
  stamina: number;
  yellowCard: boolean;
  redCard: boolean;
  goals: number;
  assists: number;
  shots: number;
  passesCompleted: number;
  passesAttempted: number;
  tackles: number;
  rating: number;
}

export interface MatchBall {
  x: number;
  y: number;
  z: number;
  vx: number;
  vy: number;
  vz: number;
  ownerId: string | null;
  lastTouchTeam: 'home' | 'away' | null;
  lastTouchPlayerId: string | null;
  assistCandidateId: string | null;
  trail: { x: number; y: number }[];
}

export type MatchEventType =
  | 'kickoff'
  | 'goal'
  | 'shot_saved'
  | 'shot_missed'
  | 'post'
  | 'yellow_card'
  | 'red_card'
  | 'corner'
  | 'foul'
  | 'substitution'
  | 'halftime'
  | 'fulltime';

export interface MatchEvent {
  id: string;
  minute: number;
  type: MatchEventType;
  team: 'home' | 'away' | 'neutral';
  text: string;
  playerId?: string;
  xg?: number;
}

export interface MatchStats {
  homePossessionTicks: number;
  awayPossessionTicks: number;
  homeShots: number;
  awayShots: number;
  homeShotsOnTarget: number;
  awayShotsOnTarget: number;
  homeXg: number;
  awayXg: number;
  homeCorners: number;
  awayCorners: number;
  homeFouls: number;
  awayFouls: number;
  homePasses: number;
  awayPasses: number;
}

export interface LiveMatchState {
  fixtureId: string;
  homeClubId: string;
  awayClubId: string;
  phase: 'pre_match' | 'first_half' | 'half_time' | 'second_half' | 'full_time';
  minute: number;
  tick: number;
  addedTimeFirst: number;
  addedTimeSecond: number;
  homeScore: number;
  awayScore: number;
  homeSubsUsed: number;
  awaySubsUsed: number;
  homeBenchIds: string[];
  awayBenchIds: string[];
  agents: MatchAgent[];
  ball: MatchBall;
  stats: MatchStats;
  events: MatchEvent[];
  goalBanner: {
    team: 'home' | 'away';
    scorerName: string;
    minute: number;
    ticksLeft: number;
  } | null;
  halfTimeTalkDone: boolean;
  userShoutCooldown: number;
  activeShout: string | null;
}

export interface SeasonRecord {
  seasonNumber: number;
  leagueId: LeagueId;
  leagueName: string;
  position: number;
  totalTeams: number;
  played: number;
  won: number;
  drawn: number;
  lost: number;
  gf: number;
  ga: number;
  points: number;
  outcome: 'champion' | 'promoted' | 'stayed' | 'relegated';
  prizeMoney: number;
}

export interface CareerState {
  managerName: string;
  userClubId: string;
  activeLeagueId: LeagueId;
  countryLeagueId: LeagueId;
  leagueOrder: LeagueId[];
  leagues: Record<string, LeagueDefinition>;
  seasonNumber: number;
  currentDateISO: string;
  clubs: Record<string, Club>;
  players: Record<string, Player>;
  fixturesByLeague: Record<string, Fixture[]>;
  standingsByLeague: Record<string, LeagueStandingRow[]>;
  inbox: InboxMessage[];
  bids: TransferBid[];
  shortlistIds: string[];
  trainingFocus: TrainingFocus;
  trainingIntensity: TrainingIntensity;
  seasonHistory: SeasonRecord[];
  history: {
    playedMatches: number;
    wins: number;
    draws: number;
    losses: number;
  };
}
